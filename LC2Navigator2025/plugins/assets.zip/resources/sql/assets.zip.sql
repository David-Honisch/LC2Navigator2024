SELECT '<h1>SQL assets SCRIPT IS RUNNING</h1>';
SELECT '<h5>Init import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Clear','Clear','echo .');
SELECT '<h4>INSERT assets to applications</h4>';
-- INSERT OR REPLACE INTO application (first_name,name,url) 
-- values ('assets','start .\\resources\\app\\sqlite\\assets.exe','start .\\resources\\app\\sqlite\\assets.exe');
-- 
-- INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('assets Plugin v.1.12a','assets Plugin v.1.2b','','','','','execCMD(''exec .\\resources\\plugins\\assets\\index.bat .\\resources\\plugins\\assets\\csv\\default.csv'', ''out'');');
INSERT OR REPLACE INTO importscripts(name, first_name, description, zipcode, city, street, url)VALUES('assets Plugin v.1.3.14.05.2025','assets Plugin v.1.3.14.05.2025','','','','','execPluginCMD(''out'',''assets'');');  
-- INSERT OR REPLACE INTO plugins VALUES('All Plugins Downloader v.1.1 Final (install requirements)','all.zip all.zip Download',NULL,NULL,NULL,NULL,'exec .\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip all.zip all.zip');

-- 
SELECT '<h5>INSERT PLUGINS DONE v.0.001</h5>';
SELECT '<h4>'||(SELECT COUNT(*) FROM application)||' plugin added...</h4>';
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';