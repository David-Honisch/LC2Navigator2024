alert('main running...');
var XLSX;
var $ = $;

var electron;
if (path === undefined) {
    var path;
}
var xlsxj;
var fs;
var cDg;
var convert;

try {
    $ = window.nodeRequire('jquery');
    electron = window.nodeRequire('electron').remote;
    path = window.nodeRequire('path');
    fs = window.nodeRequire('fs');
    XLSX = window.nodeRequire('xlsx');
} catch (e) {
    eMsg(e);
}
try {
    convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
    xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
    XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
} catch (e) {
    eMsg(e);
}
try {
    convert = XLSX;
    // XLSX = new XLSX();
} catch (e) {
    eMsg(e);
}

var xLSXUtils = new XLSXUtils(XLSX);
/* <input type="submit" value="Import to SQLite" id="dbimport" onclick="export_db();" disabled="false"></input> */
$("#xlsxport").on("click", function (e) {
    alert('Debug');
    e.preventDefault();
    e.stopPropagation();
    xLSXUtils.export_all();
});
$("#csvxport").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    xLSXUtils.export_csv();
});
$("#xmlxport").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    xLSXUtils.export_xml();
});
$("#jsonxport").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    xLSXUtils.export_json();
});
$("#btngraburls").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    // alert('Debug');
    xLSXUtils.grab_urls();
});
$("#dbimport").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    // alert('Debug');
    xLSXUtils.export_db();
});
$("#wsxport").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    // alert('Debug');
    xLSXUtils.export_ws();
});
$("#runserver").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    try {
        // alert('Debug');
        execCMD('.\\resources\\plugins\\graburls\\runserver.bat', 'outcnt');
        // alert('Debug');
    } catch (error) {
        alert(error);
        alert(error.stack);
    }
});



// var httprequest = new HttpRequest();
// httprequest.getFullList();

function eMsg(v) {
    console.error(v);
    alert(v)
    if (v.stack)
        console.error(v.stack);
}