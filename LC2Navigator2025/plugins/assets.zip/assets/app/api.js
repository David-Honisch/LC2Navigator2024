var hostName = "http://localhost:5000";

function fixSlash(links) {
    return links.replace("\\", "\\\\");
}

function utf8_encode(s) {
    return unescape(encodeURIComponent(s));
}

function utf8_decodee(s) {
    return decodeURIComponent(escape(s));
}

function utf8_decode(s) {
    var result;
    try {
        result = decodeURIComponent(escape(s));
    } catch (e) {
        // console.log(e);
    }
    result = (result !== null && result !== undefined && result.length > 0) ? result : s;
    return result;
}

function HttpRequest() {
    this.token = '';
    this.anonymous = "anonymous";
    this.NotLoggedInText = "Invalid login. Please try again with different credentials.<br/>Result:";
    this.url = hostName + '/';
}
HttpRequest.prototype.fixSlash = function(links) {
    return links.replace("\\", "\\\\");
}
HttpRequest.prototype.getExtFile = function(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("Loading" + url);
    childWindow.loadURL(url);
}
HttpRequest.prototype.getExtFile = function(url, w, h) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow({
        width: w,
        height: h
    });
    console.log("Loading" + url);
    childWindow.loadURL(url);
}
HttpRequest.prototype.getLocalFile = function(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);
}
HttpRequest.prototype.execCMD = function(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById("error").innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log('OUT:' + stdout);
        document.getElementById(id).innerHTML = stdout;
        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
HttpRequest.prototype.extExecCMD = function(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('\"' + text+"\"", (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log('OUT:' + stdout);
        document.getElementById(id).innerHTML = stdout;
        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
HttpRequest.prototype.evalCMD = function(text) {
    const {
        exec
    } = window.nodeRequire('child_process');
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            return;
        }
        console.log('OUT:' + stdout);
        // document.getElementById(id).innerHTML = stdout;
        eval(stdout);
    });
}
HttpRequest.prototype.execFile = function(text, params, id) {
    const {
        execFile
    } = window.nodeRequire('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    execFile('' + text, params, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById("error").innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log(stdout);
        document.getElementById(id).innerHTML = stdout;
    });
}
HttpRequest.prototype._execCMD = function(text, id) {
    this.__execCMD(text, [], id)

}
HttpRequest.prototype.__execCMD = function(text, params, id) {
    var result = '';
    const { spawn } = require('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    const ls = spawn('' + text, params);
    ls.stdout.on('data', (data) => {
        // console.log(`${data}`);
        document.getElementById(id).innerHTML += data;
    });
    ls.stderr.on('data', (data) => {
        document.getElementById(id).innerHTML = data;
        console.error(`stderr: ${data}`);
    });
    ls.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
    });

}
HttpRequest.prototype.__execCMD = function(text, id) {
    const {
        exec
    } = require('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById("error").innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log(stdout);
        document.getElementById(id).innerHTML = stdout;
    });
}
HttpRequest.prototype.printHTML = function(id, text) {
    document.getElementById(id).innerHTML = text;
}
HttpRequest.prototype.getIndex = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/indextools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#out\" onclick=\"new HttpRequest().execCMD('" + s + "','homecnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("homeresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getCheck = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/check';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                if (s.includes("check") || s.includes("verify"))
                    result += "<a href=\"#checkcnt\" onclick=\"new HttpRequest().execCMD('" + s + "','checkcnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("out").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getSearch = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/index';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body[0]) {
                result += "<a href=\"#\" target=\"_blank\">" + utf8_decode(body[0][v]) + "</a><br/>";
            }
            document.getElementById("searchresult").innerHTML += "" + result;
        }
    })
}
HttpRequest.prototype.getTools = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/tools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscnt\" onclick=\"new HttpRequest().execCMD('" + s + "','toolscnt')\" target=\"_parent\">" + s + "</a><br/>";
                // result += "<a href=\"cmd " + s + "\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("toolsresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getImport = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/importtools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','importcnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("importresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getDocs = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/docs';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','toolscontent')\" target=\"_parent\">x</a>|";
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','importcnt')\" target=\"_parent\">s</a>|";
                result += "<a href=\"javascript:alert('" + s + "');javascript:createChild('" + s + "');\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("docsresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getFaq = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/faq';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#faqcontent\" onclick=\"new HttpRequest().execCMD('" + s + "','faqcontent')\" target=\"_parent\">x</a>|";
                result += "<a href=\"#faqscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','faqcnt')\" target=\"_parent\">s</a>|";
                result += "<a href=\"javascript:createChild('" + s + "');\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("faqresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.extractHTML = function(id) {
    var request = window.nodeRequire("request");
    var url = hostName + '/';
    request({
        url: url,
        json: true
    }, function(error, response, body) {
        if (!error && response.statusCode === 200) {
            var Extrator = window.nodeRequire("html-extractor");
            var myExtrator = new Extrator();
            var result = '';
            myExtrator.extract(body, function(err, data) {
                if (err) {
                    throw (err)
                } else {
                    console.log(JSON.stringify(data));
                    document.getElementById(id).innerHTML = "" + utf8_decode(data.body);
                }
            });



        }
    })
}

function ifExists(obj) {
    return (obj !== "N/A" ? obj : "");
}

function toggle_visibility(className) {
    $('.' + className).toggle();
}