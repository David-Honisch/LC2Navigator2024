var installDirectories = [
    // 'lcwebclient_final_lib',
    // 'org.letztechance.domain.web.GrabUrls',
    // 'org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',
    'resources\\bin',
    'resources\\plugins\\bin',
    'resources\\plugins\\libs',
    'resources\\plugins\\libs\\sqlite.win.core.plugin',

];
var downloadUrls = [
    {
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2023/plugins/",
        file: "apache-ant.zip",
    }

];
var corelibs = [
    'http-errors',
    'jquery',
    'fs',
    'request',
    'runtime-npm-install',
    'extract-zip',
    'JSZip-sync',
    '​unzipper​',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];
const rlibs = corelibs;