// $(function () {
//     showcaseMenu("#showcase");
// })
function showcaseMenu(sc) {
    var showcase = $(sc);
    showcase.Cloud9Carousel({
        yPos: 42,
        yRadius: 48,
        mirrorOptions: {
            gap: 12,
            height: 0.2
        },
        buttonLeft: $(".cnav > .left"),
        buttonRight: $(".cnav > .right"),
        autoPlay: true,
        bringToFront: true,
        // onRendered: showcaseUpdated,
        onLoaded: function () {
            showcase.css('visibility', 'visible')
            showcase.css('display', 'none')
            showcase.fadeIn(1500)
        }
    });
    addshowcaseMenuHandler();
}
function showcaseMenuFromFile(sc, fileName) {
    //$('#showcase').load('..\\..\\resources\\plugins\\' + pluginName + '\\menu.html');
    var showcase = $(sc);
    //console.log(fileName);
    showcase.load(fileName, function () {
        // console.log("Load " + fileName + " was performed.");
        showcase.Cloud9Carousel({
            yPos: 42,
            yRadius: 48,
            mirrorOptions: {
                gap: 12,
                height: 0.2
            },
            buttonLeft: $(".cnav > .left"),
            buttonRight: $(".cnav > .right"),
            autoPlay: true,
            bringToFront: true,
            onRendered: showcaseUpdated,
            onLoaded: function () {
                showcase.css('visibility', 'visible')
                showcase.css('display', 'none')
                showcase.fadeIn(1500)
            }
        });
    });
    addshowcaseMenuHandler();
}
function addshowcaseMenuHandler() {
    $('.cnav > button').on("click", function () {
        console.log("clicked.")
        var b = $(e.target).addClass('down')
        setTimeout(function () {
            b.removeClass('down')
        }, 80);
    })
    $(document).on("keydown", function (e) {
        console.log(JSON.stringify(e));
        switch (e.keyCode) {
            /* left arrow */
            case 37:
                $('.cnav > .left').trigger("click");
                break

            /* right arrow */
            case 39:
                $('.cnav > .right').trigger("click");
        }
    })
}
function showcaseUpdated(showcase) {
    var title = $('#item-title').html(
        $(showcase.nearestItem()).attr('alt')
    )
    var c = Math.cos((showcase.floatIndex() % 1) * 2 * Math.PI)
    title.css('opacity', 0.5 + (0.5 * c))
}