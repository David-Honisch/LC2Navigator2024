// alert('TEST2');
function pluginINIT(){
	var remote = window.nodeRequire('electron').remote;
	arguments = remote.getGlobal('sharedObject').prop1;
	console.log(arguments);
// var argparts = arguments.split(' ');
// var i = 0;
// var query = "";
// for (var s in argparts)
// {
    // console.log(s);
    // if (s == "--query"){
        // query = argparts[i+1]
    // }
    // i++;
// }
// alert(query);
// document.getElementById("app_cnt").innerHTML += arguments;
// document.getElementById("inputKey").value =inputKey
// alert(arguments);
// alert(arguments["arg1"]);
// alert(arguments["--query"]);
}
pluginINIT();
// $('title').html(pluginName);
// $('#plugintitle').html(pluginName)
// execCMD('exec .\\resources\\plugins\\'+pluginName+'\\test.bat .\\resources\\plugins\\'+pluginName+'\\menu.csv', pluginName+'out')
// function getFileContent(url) {
//     $('#sql_cnt').html(get_FileData(url))
// }
// try {
// document.getElementById("appcnt").innerHTML = "";
// document.getElementById("modcnt").innerHTML = "";
// for (var v in installDirectories) {
// createDir(installDirectories[v]);
// }
// var opath = window.nodeRequire('path');
// var resDir = opath.join(__dirname, '../../resources/');
// var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
// var downloadDir = opath.join(__dirname, '../../');
// console.log(resDir);
// console.log(pluginDir);
// console.log(downloadDir);
// InstallModules(resDir);


// doDownload(downloadUrls, pluginDir);
// execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'mvncnt');

// doUnzip(downloadUrls, targetDir);
// } catch (e) {
// alert(e.stack);
// }