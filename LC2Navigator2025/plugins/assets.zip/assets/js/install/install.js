function dobaseInstallation() {
    const APPCFG = "application.config.json";
    try {
        const fs = window.nodeRequire("fs");
        var installcnt = document.getElementById("checkapp_main");
        var installmodcnt = document.getElementById("checkapp_mod");
        var installdlcnt = document.getElementById("checkapp_dls");
        var installmvncnt = document.getElementById("checkapp_mvn");

        var isDBRunning = document.getElementById("isDBRunning");
        var isServerRunning = document.getElementById("isServerRunning");
        var isBackendRunning = document.getElementById("isBackendRunning");       

        // installcnt.innerHTML = "";
        // installmodcnt.innerHTML = "";
        // installdlcnt.innerHTML = "";
        // installmvncnt.innerHTML = "";

        if (fs.existsSync(APPCFG)) {
            console.log(APPCFG + ' exists.\nReading Configuration:\n');
            appConfig = getAppConfig(APPCFG);
        }

        // execCMD("echo call java -version", "java_version", false, false);        
        execCMD(appConfig.check.javacmd, "checkapp_java_version", true, false);
        setTimeout(() => {
            execCMD(appConfig.check.viewjava, "checkapp_java_version", true, false);
        }, 1000);
        // execCMD("echo f java -version", "java_version", true, false);
        //execCMD("java -jar  .\\org.letztechance.domain.app.JarLoader-0.0.1-SNAPSHOT.jar home", "isJavaInstalled", false, false);
        execCMD(appConfig.check.execjar, "checkapp_java_cnt", true, false);

        for (var v in installDirectories) {
            createDir(installDirectories[v], 'checkapp_main_cnt');
        }
        var opath = window.nodeRequire('path');
        var resDir = opath.join(__dirname, '../../resources/');
        var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
        var downloadDir = opath.join(__dirname, '../../');
        console.log("Install:Dir:" + resDir + " pluginDir:" + pluginDir + " dlDir:" + downloadDir);
        const NODEAPI = window.nodeRequire(path.join(__dirname, '..', '..', 'assets', 'js', 'api', 'nodeapi.js'));
        console.log(downloadDir);
        


        // InstallModules(resDir);
        //doDownload(downloadUrls, pluginDir,'installcnt');
        try {            
            Install_Modules(corelibs, resDir, 'checkapp_mods_cnt');
        } catch (error) {
            console.error("Error installing corelibs: " + error);
            console.error(error.stack);
            $("#checkapp_mods_cnt").append("<p class=\"alert\">Error installing corelibs: " + error + "<p>"+JSON.stringify(corelibs)+" - "+resDir+"</p>");
        }
        
        for (var v in downloadUrls) {
            var file = downloadUrls[v].file;
            if (!isFileExisting(file)) {
                console.log("downloading:" + JSON.stringify(downloadUrls[v]));
                installdlcnt.innerHTML += "" + JSON.stringify(downloadUrls[v]);
                doDownload([downloadUrls[v]], pluginDir, 'checkapp_dls');
            }
            else {
                console.log(file + " already exits");
                installdlcnt.innerHTML += "" + file + " already exits<br/>";
            }
        }        
        setTimeout(() => {
            //execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'checkapp_mvn', true, false);
            // execCMD('.\\mvn install', 'checkapp_mvn', true, false);
        }, 3000);


        // doUnzip(downloadUrls, targetDir);
    } catch (e) {
        console.error(e);
        console.error(e.stack);
        alert(e.stack);
    }
}
function checkServer() {
    const APPCFG = "application.config.json";
    try {
        const fs = window.nodeRequire("fs");
        var isDBRunning = document.getElementById("isDBRunning");
        var isServerRunning = document.getElementById("isServerRunning");
        var isBackendRunning = document.getElementById("isBackendRunning");

        if (fs.existsSync(APPCFG)) {
            console.log(APPCFG + ' exists.\nReading Configuration:\n');
            appConfig = getAppConfig(APPCFG);
        }        
        var pDB = isPortOpen(3306);
        pDB.then(function (isDBInUse) {
            if (isDBInUse == true) {
                isDBRunning.value = "The container is NOT running on port:3306.";
                isDBRunning.classList.remove('btn-default');
                isDBRunning.classList.add('btn-warning');
                // isDBRunning.setAttribute("onclick", "execCMD('" + appConfig.server.launchcontainerNode + "','import');");
                isDBRunning.setAttribute("onclick", "execCMD('" + appConfig.server.launchcontainer.replaceAll("\\","\\\\") + "','import');");
                
            }
            else {
                isDBRunning.value = "The container is running on port:3306.";
                isDBRunning.classList.remove('btn-default');
                isDBRunning.classList.add('btn-success');
                isDBRunning.setAttribute("onclick", "execCMD('" + appConfig.server.stopcontainer + "','import');");
            }
        })
        var pB2 = isPortOpen(8084);
        pB2.then(function (isDBInUse) {
            if (isDBInUse == true) {
                isServerRunning.value = "The server is NOT running on port:8084.";
                isServerRunning.classList.remove('btn-default');
                isServerRunning.classList.add('btn-warning');
                isServerRunning.setAttribute("onclick", "execCMD('" + appConfig.cmd + " " + appConfig.params + " " + appConfig.server.jar + "','import');");
            }
            else {
                isServerRunning.value = "The server is running on port:8084.";
                isServerRunning.classList.remove('btn-default');
                isServerRunning.classList.add('btn-success');

                isServerRunning.setAttribute("onclick", "execCMD('start http://localhost:8084/?actuator/shutdown','import');");

            }
        })
        var pB3 = isPortOpen(8085);
        pB3.then(function (isDBInUse) {
            if (isDBInUse == true) {
                isBackendRunning.value = "The backend is NOT running on port:8085.";
                isBackendRunning.classList.remove('btn-default');
                isBackendRunning.classList.add('btn-warning');
                isBackendRunning.setAttribute("onclick", "execCMD('" + appConfig.cmd + " " + appConfig.params + " " + appConfig.server.jar + "','import');");
            }
            else {
                isBackendRunning.value = "The backend is running on port:8085.";
                isBackendRunning.classList.remove('btn-default');
                isBackendRunning.classList.add('btn-success');

                isBackendRunning.setAttribute("onclick", "execCMD('start http://localhost:8085/actuator/shutdown','import');");

            }
        })
        setTimeout(() => {
            //execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'checkapp_mvn', true, false);
            // execCMD('.\\mvn install', 'checkapp_mvn', true, false);
        }, 3000);


        // doUnzip(downloadUrls, targetDir);
    } catch (e) {
        console.error(e);
        console.error(e.stack);
        alert(e.stack);
    }
}