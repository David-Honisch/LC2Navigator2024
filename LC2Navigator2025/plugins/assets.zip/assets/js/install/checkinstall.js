$(document).ready(function () {
    check_install()
});
