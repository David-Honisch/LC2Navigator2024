$(document).ready(function () {
    console.log("LC2Navigator Check install ready.");
    dobaseInstallation();
    
    getListDrives().then(function (files) {
        var out = printListOptionsDrives(files, "menudrives");
        var drivesout = document.getElementById("installdrivescnt");
        drivesout.innerHTML = out;
    })
});