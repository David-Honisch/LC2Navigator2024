$(document).ready(function () {
    var allowedExt = ["exe","bin","iso"];
    console.log("LC2Navigator Check install ready.");
    getXML("resources\\xml\\checkapp.xml", "resources\\xml\\checkapp.xslt", "checkapp", true, false);
    setTimeout(() => {
        set_DragOver('checkappmaindrop', 'newdb', "checkapphtmlout", "checkappoutFile", allowedExt);
        console.log("set_DragOver done.");
        execCMD("resources\\cmd\\register.config.bat", "checkapp_main_cnt", true, false);
        execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\cmd\\csv\\check.csv", "checkapp_installcnt", true, false);
    }, 3000);
    dobaseInstallation();
    checkServer();
    
    getListDrives().then(function (files) {
        try {
            var out = printListOptionsDrives(files, "checkapp_drives");
            var drivesout = document.getElementById("checkapp_drivescnt");
            drivesout.innerHTML = out;            
        } catch (error) {
            console.error(error);
            console.error(error.stack);
        }
    })
});