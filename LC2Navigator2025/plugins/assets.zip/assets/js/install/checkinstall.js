$(document).ready(function () {
    var allowedExt = ["exe","bin","iso"];
    console.log("LC2Navigator Check install ready.");
    getXML("resources\\xml\\checkapp.xml", "resources\\xml\\checkapp.xslt", "checkapp", true, false);
    setTimeout(() => {
        set_DragOver('checkappmaindrop', 'newdb', "checkapphtmlout", "checkappoutFile", allowedExt);
        console.log("set_DragOver done.");
        execCMD("resources\\cmd\\register.config.bat", "checkapp_main", true, false);
        execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\cmd\\csv\\check.csv", "checkapp_main", true, false);
    }, 3000);
    dobaseInstallation();
    
    getListDrives().then(function (files) {
        var out = printListOptionsDrives(files, "checkapp_drives");
        var drivesout = document.getElementById("checkapp_drivescnt");
        drivesout.innerHTML = out;
    })
});