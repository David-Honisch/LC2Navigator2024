var cpage;
// $('#gout').append('RUNNING DONE.');
window._PAGE_ = {
    cpage: ""
};
try {
    window.nodeRequire = require;
    window.nodeExports = window.exports;
    window.nodeModule = window.module;
    delete window.require;
    delete window.exports;
    delete window.module;
} catch (error) {
    console.error(error);
    console.error(error.stack);
}

// function test(id, t) {
//     $(id).html(t);
// }
// $('#golegend').html('Preloading...');
// window._PAGE_ = {
//     cpage: " ",
//     jQuery: function() {
//         return $;
//     }
// };