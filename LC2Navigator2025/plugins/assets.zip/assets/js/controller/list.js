// getURLParam = function(name) {
//         var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
//         if (results == null) {
//             return null;
//         }
//         return decodeURI(results[1]) || 0;
//     }
//     //angular
// const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
var app = angular.module('app', ['ui.bootstrap']);

// const APPCFG = "application.config.json";
const path = window.nodeRequire('path');
const jQuery = window._PAGE_.jQuery;
const { readFileSync, fs } = window.nodeRequire('fs');
// const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
const cfg = window.nodeRequire(path.join(__dirname, '..', '..', 'config.json'));
const model = window.nodeRequire(path.join(__dirname, '..', '..', 'assets', 'js', 'app', 'model.js'));
const cpath = path.join(__dirname);
const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
const gelectron = window.nodeRequire('electron');
const shell = gelectron.shell;
const OPEN_LINK = "https://www.letztechance.org/openlink?";
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    top: 140,
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};


function ListController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    const path = window.nodeRequire('path');
    // default values for pagination and filtering
    $scope.pageSize = 10;
    $scope.maxSize = 10;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    //$scope.currentTable = (getURLParam('table') !== null && getURLParam('table') !== undefined) ? getURLParam('table') : "systables";
    $scope.currentSite = getURLParam('q') !== null && getURLParam('q') !== undefined ? getURLParam('q') : "home";
    $scope.currentTable = getURLParam('table') !== undefined ? getURLParam('table') : "systables";
    $scope.currentDB = getURLParam('db') !== null && getURLParam('db') !== undefined ? path.join(__dirname, '..', getURLParam('db') + '.db') : dbPath;
    $scope.data = [];
    $scope.security = [];
    $scope.query = { browser: "" };
    $scope.index = [];
    $scope.news = [];
    $scope.menu = [];
    $scope.person = [];
    $scope.log = [];

    // get the data
    // $http.get('assets/js/data/mainmenu.json')
    //     .success(function(data) {
    //         $scope.menu = data;
    //     });
    // console.log(APPCFG);
    $scope.cfg = getAppConfig(APPCFG);
    $scope.menu = $scope.cfg.topmenu;

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    console.log("resdir:" + resDir);

    getXML("lists.xml", "lists.xslt", "appplugins",true,false);
    setTimeout(() => {
        set_DragOver('maindrop','inputFile',"htmlout" );        
    }, 3000);
    get_Download_File(dlPath, "app.xml", resDir + "app.xml", resDir, "out_cnt");
    get_Download_File(dlPath, "app.xslt", resDir + "app.xslt", resDir, "out_cnt");
    console.log("Download to resdir:" + resDir + " done.");


    $http.get($scope.cfg.apiexternal[0].url)
        .success(function (data) {
            $scope.index = data.list;
        });

    $http.get($scope.cfg.apiexternal[1].url)
        .success(function (data) {
            $scope.news = data.row;
        });

    $http.get($scope.cfg.apiexternal[2].url)
        .success(function (data) {
            $scope.security = data.row;
        });
    $http.get($scope.cfg.apiexternal[5].url)
        .success(function (data) {
            $scope.person = data.row;
        });
    $http.get($scope.cfg.apiexternal[6].url)
        .success(function (data) {
            $scope.log = data;
        });
    $http.get($scope.cfg.apiexternal[11].url)
        .success(function (data) {
            $scope.alerts = data.row;
        });

    console.log('List DB:' + $scope.currentDB);
    console.log('Base DB:' + dbPath);
    console.log('Table:' + $scope.currentTable);
    $scope.dataplugins = getSQLQuery('select * from plugins order by person_id asc, name asc', dbPath);
    $scope.dropdowns = getSQLQuery('select * from dropdowns order by person_id asc, name asc', dbPath);
    console.log("Table:" + $scope.currentTable);
    $scope.data = getSQLQuery('select * from  ' + $scope.currentTable + ' order by person_id asc, name asc  limit 100000', $scope.currentDB);

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    console.log("resdir:" + resDir)
    // get_DownloadFile(dlPath, "app.xml", resDir + "app.xml", resDir, "_app");
    // get_DownloadFile(dlPath, "util.xslt", resDir + "util.xslt", resDir, "_app");
    document.getElementById('appplugins').innerHTML += '<input type="button" value="Get Update" onclick="getXML(\'app.xml\', \'app.xslt\');"></input>';


    if (getURLParam('table') !== undefined) {
        console.log(getURLParam('table') + " exists.");
        var item = readItem($scope.currentTable, getURLParam('id'));
        console.log(item);
        if (item[0] !== undefined && item[0]['name'] !== undefined) {
            $('#name').val(item[0]['name']);
            $('#first_name').val(item[0]['first_name']);
            $('#last_name').val(item[0]['last_name']);
            $('#city').val(item[0]['city']);
            $('#street').val(item[0]['street']);
            $('#zipcode').val(item[0]['zipcode']);
            $('#description').val(item[0]['description']);
            $('#url').val(item[0]['url']);
        }


    } else {
        console.error(tableName + " does not exists.");

        //  setAppConfig(APPCFG, appConfig);
    }
    // setTimeout(() => {
    getXML("app.xml", "app.xslt", 'out_cnt');
    // }, 1000);
    console.log("Checking if is online or not:");
    const updateOnlineStatus = () => {
        console.log(navigator.onLine ? 'online' : 'offline');
        $('.cm-footer').find('.pull-left').html(("Anonymous, not logged in and "+ (navigator.onLine ? 'online' : 'offline'))+"");
    }
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();
    console.log('DONE.');

    try {
        getListDrives().then(function (drives) {
            drives.pop();
            $scope.drives = drives;
        });
    } catch (error) {
        console.error(error);
    }



    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function (data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function () {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });

    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function (page) {
        console.log('currentPage' + page);
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function (items, old) {
        console.log('filteredItems');
        $scope.currentPage = 0;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function (items) {
        console.log('startItems');
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 0) * $scope.pageSize + $scope.pagedItems.length;
    });
    // set the pagination for the filtered items
    function setPage() {
        console.log('setPage');
        $scope.start = ($scope.currentPage - 0) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 0);
    }
}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function (e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function () {
    return function (input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});