var remote = window.nodeRequire('electron').remote;
//arguments = remote.getGlobal('sharedObject').prop1;
//console.log(arguments);
//alert(arguments);
//LC2Navigator 2022
var app = angular.module('app', ['ui.bootstrap']);

// const APPCFG = "application.config.json";
const path = window.nodeRequire('path');
const jQuery = window._PAGE_.jQuery;
const { readFileSync, fs } = window.nodeRequire('fs');
const cfg = window.nodeRequire(path.join(__dirname, '..', '..', 'config.json'));
//const model = window.nodeRequire(path.join(__dirname, '..', 'assets', 'js', 'app', 'model.js'));
const model = window.nodeRequire(path.join(__dirname, '..', '..', 'assets', 'js', 'app', 'model.js'));
const cpath = path.join(__dirname);
const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
const gelectron = window.nodeRequire('electron');
const shell = gelectron.shell;
// const OPEN_LINK = "https://www.letztechance.org/openlink?";
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    top: 140,
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};

function AppController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    const path = window.nodeRequire('path');
    // default values for pagination and filtering    
    $scope.title = "LC2Navigator2025 - HOME";
    $scope.allowedExt = ["exe","bin","iso"]
    $scope.cfg = [];
    $scope.pageSize = 10;
    $scope.maxSize = 15;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    $scope.currentTable = getURLParam('table') !== undefined ? getURLParam('table') : "systables";
    $scope.currentDB = getURLParam('db') !== null && getURLParam('db') !== undefined ? getURLParam('db') : dbPath;
    $scope.currentSite = getURLParam('q') !== null && getURLParam('q') !== undefined ? getURLParam('q') : "home";
    $scope.data = [];
    $scope.dataplugins = [];
    $scope.query = { name: "" };
    $scope.index = [];
    $scope.drives = [];
    $scope.files = [];
    $scope.news = [];
    $scope.security = [];
    $scope.menu = [];
    $scope.log = [];
    $scope.person = [];
    $scope.onlineplugindownloads = [];
    $scope.alerts = [];

    $scope.regDays = [];

    $scope.downloads = [];
    $scope.otherdownloads = [];

    // console.log(APPCFG);
    $scope.cfg = getAppConfig(APPCFG);
    $scope.menu = $scope.cfg.topmenu;

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    // console.log("Download to resdir:" + resDir + " done.");
    var currentSite = $scope.currentSite;
    document.title = $scope.cfg.productname;
    var head = getHeader(cfg.local);
    // console.log(JSON.stringify(head));    
    $('#head').html(head);
    $('#ptitle').html($scope.title);
    //eof head
    getXML("resources\\xml\\index.xml", "resources\\xml\\index.xslt", "appplugins", true, false);
    setTimeout(() => {
        set_DragOver('maindrop', 'newdb', "htmlout", "outFile", $scope.allowedExt);
        execCMD("resources\\cmd\\register.config.bat", "_app", true, false);
        execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\cmd\\csv\\check.csv", "_app", true, false);
    }, 3000);
    // get_Download_File(dlPath, "app.xml", resDir + "app.xml", resDir, "out_cnt");
    // get_Download_File(dlPath, "app.xslt", resDir + "app.xslt", resDir, "out_cnt");

    // alert($scope.cfg.apiexternal[0].url);
    $http.get($scope.cfg.apiexternal[0].url)
        .success(function (data) {
            $scope.index = data.list;
        });

    $http.get($scope.cfg.apiexternal[1].url)
        .success(function (data) {
            $scope.news = data.row;
        });

    $http.get($scope.cfg.apiexternal[2].url)
        .success(function (data) {
            $scope.security = data.row;
        });

    $http.get($scope.cfg.apiexternal[3].url)
        .success(function (data) {
            $scope.downloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[4].url)
        .success(function (data) {
            $scope.otherdownloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[5].url)
        .success(function (data) {
            $scope.person = data.row;
        });
    $http.get($scope.cfg.apiexternal[6].url)
        .success(function (data) {
            $scope.onlineplugindownloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[7].url)
        .success(function (data) {
            // console.log("log");
            $scope.log = data;
        });
    $http.get($scope.cfg.apiexternal[11].url)
        .success(function (data) {
            $scope.alerts = data.row;
        });
    // alert($scope.cfg.apiexternal[7].url);
    var scDate = (new Date().toISOString() + "").substring(0, 10);
    var surl = ($scope.cfg.apiexternal[8].url).replace("cdate=2024-04-26", "cdate=" + scDate);
    // console.log("URL:"+surl);
    $http.get(surl)
        .success(function (data) {
            $scope.regDays = data;

        });
    // console.log("LISTING DRIVES !!!");

    // model.initDb('' + webRoot, //app.getPath('userData'),
    //     // Load a DOM stub here. See renderer.js for the fully composed DOM.
    //     //mainWindow.loadURL(`file:${__dirname}/app/html/index.html`)
    //     console.log('Init Database')
    // );
    $scope.data = getSQLQuery('select * from systables order by person_id asc, name asc', $scope.currentDB);
    $scope.other = getSQLQuery('select * from other order by person_id asc, name asc', $scope.currentDB);
    $scope.dataplugins = getSQLQuery('select * from plugins order by person_id asc, name asc', $scope.currentDB);
    $scope.dropdowns = getSQLQuery('select * from dropdowns order by person_id asc, name asc', $scope.currentDB);
    // console.log(JSON.stringify(remote.getGlobal('sharedObject').get('query')));
    // var query;
    // if (remote !== undefined && remote.getGlobal !== undefined && remote.getGlobal('sharedObject') !== undefined) {
    //     query = remote.getGlobal('sharedObject').query;
    //     console.log('query fond:'+query);
    // }

    var query = getSQLQuery('select first_name from params order by person_id asc, name asc', $scope.currentDB);
    query = JSON.parse(JSON.stringify(query));
    query = query["0"]["first_name"]
    // console.log('Parameter:' + JSON.stringify(query));
    $scope.loadedplugin = getSQLQuery('select * from application where first_name like \'%' + query + '%\' or name like \'%' + query + '%\' order by person_id asc, name asc limit 1', $scope.currentDB);
    if ($scope.loadedplugin !== undefined && $scope.loadedplugin["0"] !== undefined && $scope.loadedplugin["0"]["url"] !== undefined) {
        // console.log(JSON.stringify($scope.loadedplugin));
        eval($scope.loadedplugin["0"]["url"]);
    } else {
        console.log('No plugin found.');
    }
    console.log("Site:" + currentSite);
    switch (currentSite) {
        case "search":
            // console.log("Site:" + currentSite);
            getXML("search.xml", "search.xslt", "out_cnt", true, false);
            break;

        default:
            console.log("default Site:" + currentSite);
            document.getElementById('appplugins').innerHTML += '<input type="button" value="Load news" onclick="getXML(\'resources\\xml\\app.xml\', \'resources\\xml\\app.xslt\',\'out_cnt\');"></input>';
            getXML("app.xml", "app.xslt", "appplugins", true, false);

            document.getElementById('out').innerHTML += '<input type="button" value="Load menu" onclick="getXML(\'resources\\xml\\menu.xml\', \'resources\\xml\\menu.xslt\',\'out\');"></input>';
            getOpenDialog('#importGUI_cnt', '.\\assets\\html\\dialog\\install.html', 'Check Installation and Configuration', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 300, height: 600 });



            // console.log('Intro loading...');
            //getload_File('file:///./resources/plugins/LC2Intro/v.1.3/index.html',"resizable=true,toolbar=false,status=true,menubar=false,frame=true,nodeIntegration=true,top=10, left=200,innerWidth=700, width=700,innerHeight=960, height=960");
            if ($scope.cfg.isIntroLoaded == true) {
                getExtFile('https://www.letztechance.org/LC2Intro.v.4.0/index.html', 'intro', 'top=500,left=200,width=640,height=960,frame=true,nodeIntegration=no');
            }
            if ($scope.cfg.isServerLoaded == true) {
                //getExtFile('http://localhost:8085', 'backend', 'top=500,left=100,width=640,height=480,frame=true,nodeIntegration=yes');
                // getExtFile('http://localhost:8085', 'backend', 'top=500,left=100,width=640,height=480,frame=true,nodeIntegration=yes');
                // getload_File('file:///./assets/html/dialog/server.html',"resizable=true,toolbar=false,status=true,menubar=false,frame=true,nodeIntegration=true,top=10, left=200,innerWidth=300, width=300,innerHeight=400, height=400");
                // getExtFile('file:///./assets/html/dialog/server.html', 'serverlauncher', 'top=50,left=50,width=340,height=260,frame=true,nodeIntegration=yes');
                getExtFile('http://localhost:8084', 'serverlauncher', 'top=50,left=50,width=340,height=460,frame=true,nodeIntegration=yes');
            }
            //openBrowser('https://www.letztechance.org/LC2Intro.v.4.0/index.html');
            console.log('Intro loading done.');
            break;
    }
    //getOpenDialog('#alertcnt','.\\resources\\html\\intro.html','Intro',{ top: 100,minWidth: 250, margin:0,  minHeight: 600, width: 640, height:600});    
    // loadFile('file:///./resources/plugins/LC2Intro/v.1.3/index.html', { width: 800, height: 600 });
    // loadFileContent('#carouselpanel','./carousel.html');
    try {
        getListDrives().then(function (drives) {
            drives.pop();
            $scope.drives = drives;
            // printDirectory(drives[0], 'files', false, false);
            // printDirectory(drives[0], 'localfiles', false, false);
        });
    } catch (error) {
        console.error(error);
    }
    // printDirectory('.', 'localfiles', true, false);
    console.log("Checking if is online or not:");
    const updateOnlineStatus = () => {
        console.log(navigator.onLine ? 'online' : 'offline');
        $('.cm-footer').find('.pull-left').html(("Anonymous, not logged in and " + (navigator.onLine ? 'online' : 'offline')) + "");
    }
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();


    setTimeout(() => {
        $('#out_cal').load('../../assets/html/calendar.html');
    }, 4000);
    setTimeout(() => {
        initScheduler();
    }, 5000);


    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function (data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function () {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });


    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function (page) {
        console.log('currentPage');
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function (items, old) {
        console.log('filteredItems');
        $scope.currentPage = 0;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function (items) {
        console.log('startItems');
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 0) * $scope.pageSize + $scope.pagedItems.length;
    });
    //functions
    // set the pagination for the filtered items
    function setPage() {
        console.log('setPage');
        $scope.start = ($scope.currentPage - 0) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 0);
    }

    function getAppConfig(appConfigFileName) {
        const fs = window.nodeRequire('fs');
        let rawdata = fs.readFileSync(appConfigFileName);
        let appConfig = JSON.parse(rawdata);
        // console.log(appConfig);
        return appConfig;
    }
    function initScheduler() {
        // window.addEventListener("DOMContentLoaded", function () {
        console.log('scheduler running...');
        scheduler.plugins({
            recurring: true,
            minical: true
        });

        scheduler.config.multi_day = true;
        scheduler.config.event_duration = 35;
        scheduler.config.occurrence_timestamp_in_utc = true;
        scheduler.config.include_end_by = true;
        scheduler.config.repeat_precise = true;
        scheduler.config.repeat_date = "%d-%m-%Y";
        scheduler.attachEvent("onclick", function (event) {
            console.log(JSON.stringify(this._events[event]["url"]));
            openBrowser("https://www.letztechance.org/" + this._events[event]["url"]);
        });
        scheduler.attachEvent("onLightbox", function () {
            var lightbox_form = scheduler.getLightbox(); // this will generate lightbox form
            var inputs = lightbox_form.getElementsByTagName('input');
            var date_of_end = null;
            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i].name == "date_of_end") {
                    date_of_end = inputs[i];
                    break;
                }
            }

            var repeat_end_date_format = scheduler.date.date_to_str(scheduler.config.repeat_date);
            var show_minical = function () {
                if (scheduler.isCalendarVisible())
                    scheduler.destroyCalendar();
                else {
                    scheduler.renderCalendar({
                        position: date_of_end,
                        date: scheduler.getState().date,
                        navigation: true,
                        handler: function (date, calendar) {
                            date_of_end.value = repeat_end_date_format(date);
                            getSQLQuery('UPDATE `OTHER` (NAME, FIRST_NAME, URL  ) VALUES ( "Menu v.1.0", "Menu v.1.0","test");', dbPath);
                            scheduler.destroyCalendar();
                        }
                    });
                }
            };
            date_of_end.onclick = show_minical;
            console.log('scheduler done.');
        });

        scheduler.config.lightbox.sections = [
            { name: "description", height: 50, map_to: "text", type: "textarea", focus: true },
            { name: "recurring", type: "recurring", map_to: "rec_type", button: "recurring" },
            { name: "time", height: 72, type: "calendar_time", map_to: "auto" }
        ];
        scheduler.init('lc2scheduler', new Date(), "day");
        var result = '{ "data": [';
        result += '{ "id": "10000", "start_date": "2000-01-10 00:00:00", "end_date": "2030-12-31 00:00:00", "text": "Welcome to LC", "details": "LetzteChance.Org Siegburg, DE", "allDays": "true"},';
        result += concatTableToJSON($scope.data, 0);
        result += concatTableToJSON($scope.loadedplugin, 15);
        result += concatTableToJSON($scope.other, 41);
        var count = 0;
        var regDays = $scope.regDays;
        // console.log("JSON:"+JSON.stringify(regDays));
        for (var s in regDays) {
            try {
                // console.log("Value:"+JSON.stringify(regDays));
                var ID = +(regDays[s]["id"]);
                var name = (regDays[s]["title"] !== undefined) ? (regDays[s]["title"]).replace(/"/g, '&quot;') : (regDays[s]["id"]) + "-NA";
                var desc = name;
                try {
                    var desc = regDays[s]["url"].replace(/"/g, '&quot;');
                } catch (error) { }
                var created = ("" + regDays[s]["start"]).substring(0, 13) + ":00:01";
                var enddate = ("" + regDays[s]["end"]).substring(0, 11) + "23:59:59";
                var line = '{ "id": "' + ID + '", "start_date": "' + created + '", "end_date": "' + enddate + '", "text": "' + name + '", "details": "' + name + '-' + desc + '", "url": "' + desc + '"},';
                // console.log(line);
                result += line;
                count++;
                if (count == 4000) break;
            } catch (error) {
                console.error(error);
            }

        }

        result += '{ "id": "1002", "start_date": "2021-01-10 23:00:00", "end_date": "2300-01-16 23:00:00", "text": "Welcome to LC\\n(c)by David Honisch", "details": "LetzteChance.Org Siegburg, DE"}';
        result += "]  }";

        // console.log("Result:\n"+result);
        var eventsFile = "../../assets/js/events.json";
        var eventsOutFile = "./assets/js/events.json";
        var fs = window.nodeRequire('fs');
        fs.writeFileSync(eventsOutFile, result);
        scheduler.load(eventsFile, function () {
            // scheduler.showLightbox(10000);
        });

        // });

    }
    function concatTableToJSON(table, add) {
        var result = "";
        for (var s in table) {
            var ID = +(table[s]["id"]) + add;
            var name = table[s]["name"];
            var desc = table[s]["description"];
            var created = ("" + table[s]["created"]).substring(0, 13) + ":00:00";
            var enddate = ("" + table[s]["enddate"]).substring(0, 13) + ":30:00";
            //console.log(""+ID+"-"+name + "=" + created + "=" + enddate);
            result += '{ "id": "' + ID + '", "start_date": "' + created + '", "end_date": "' + enddate + '", "text": "' + name + '", "details": "' + name + " Descripion:" + desc + '"},';

        }
        return result;

    }



}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function (e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function () {
    return function (input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});