console.log('File extension loading:');
function fileExt_JS(file) {
    try {


        var extFileName = $("#extFileName");
        var extFileNamePath = $("#extFileNamePath");
        extFileName.val(file);
        var id = "editorext";
        var out = $("#editorextCNT");
        const { webUtils } = window.nodeRequire('electron');
        // const file = files[0];
        // console.log("file:" + file);
        var fileSize = getFileSize(file);
        var fileExt = getFileExtension(file);
        var fileName = file.replaceAll("\\", "\\\\");
        var onlyPath = window.nodeRequire('path').dirname(file);
        var htmlPath = "assets\\html\\ext";
        // const fileData2 = constructFileFromLocalFileData(file)    
        // console.log("path:" + file + " fileExt:" + fileExt + " size:" + fileSize + " MB");
        //outFile.val((fileFullPath).replace("\\", "\\\\") + files[0].name);

        $("#extFileName" + fileExt + "").val("" + file);
        extFileNamePath.val("" + extractFilePath(file));

        var final_template = path.join("..", "..", htmlPath, "default.html");
        var fileList = get_DirectoryFiles(htmlPath);
        var templateFileName = path.join("..", "..", htmlPath, "default.html");
        showFile(out, fileExt, fileName, templateFileName, htmlPath);
        const saveButton = document.getElementById('extsaveButton');
        /**
         * Toggle read-only button
         */
        const toggleReadOnlyButton = document.getElementById('toggleReadOnlyButton');
        const readOnlyIndicator = document.getElementById('readonly-state');
        /**
         * Saving
         */
        saveButton.addEventListener('click', function () {
            createZipFromFile(file, _readBinaryFile(file));
        });
        /**
         * Toggle read-only example
         */
        toggleReadOnlyButton.addEventListener('click', async () => {
            // const readOnlyState = await editor.readOnly.toggle();
            readOnlyIndicator.textContent = readOnlyState ? 'On' : 'Off';
        });
        console.log('File extension loaded.');
    } catch (error) {
        console.error('Error in fileExt_JS:', error);
        $("#fileview").html("Error loading file: " + error.message);
    }

}
function showFile(out, fileExt, fileName, templateFileName, htmlPath) {
    switch (fileExt) {
        case "avi":
            showVideoFile(out, fileExt, fileName, templateFileName);
            break;
        case "bat":
            showDefaultFile(out, fileExt, fileName, templateFileName);
            break;
        case "exe":
            execCMD('call "' + fileName + '"', id);
            break;
        case "cmd":
            showDefaultFile(out, fileExt, fileName, templateFileName);
            break;
        case "gif":
            showPictureFile(out, fileExt, fileName, templateFileName);
            break;

        case "js":
            out.html(file);
            _fileExtEditor(fileName, fileExt);
            break;
        case "json":
            templateFileName = getTemplateFile(fileName, "package.json", htmlPath);
            showDefaultFile(out, fileExt, fileName, templateFileName);
            break;
        case "mp4":
            showVideoFile(out, fileExt, fileName, templateFileName);
            break;
        case "mkv":
            showVideoFile(out, fileExt, fileName, templateFileName);
            break;
        case "jpeg":
            showPictureFile(out, fileExt, fileName, templateFileName);
            break;
        case "jpg":
            showPictureFile(out, fileExt, fileName, templateFileName);
            break;
        case "png":
            showPictureFile(out, fileExt, fileName, templateFileName);
            break;
        case "svg":
            showPictureFile(out, fileExt, fileName, templateFileName);
            break;
        case "tif":
            showPictureFile(out, fileExt, fileName, templateFileName);
            break;
        case "xml":
            templateFileName = getTemplateFile(fileName, "pom.xml", htmlPath);
            showDefaultFile(out, fileExt, fileName, templateFileName);
            break;
        case "xls":
            // $("#" + id).html(_readFile(file));
            // //$("#editorext").html("" + cnt);
            // _fileExtEditor(fileName, fileExt);
            showDefaultFile(out, fileExt, fileName, templateFileName);
            break;
        case "xlsx":
            // if (+fileSize > 1.0) {
            //     if (getConfirmation('Do you realy want to start ' + fileName + ' now? It´s about ' + fileSize + " big.")) {
            //         _fileExtEditor(fileName, fileExt);
            //     } else {
            //         $("#" + id).html(fileName + " not processed.");
            //     }
            // } else {
            //     _fileExtEditor(fileName, fileExt);
            // }
            showDefaultFile(out, fileExt, fileName, templateFileName);
            break;
        default:
            showDefaultFile(out, fileExt, fileName, templateFileName);
            break;
    }
}
function showDefaultFile(out, fileExt, fileName, templateFileName) {
    console.log("showDefaultFile:" + fileName + " fileExt:" + fileExt + " templateFileName:" + templateFileName);
    $("#fileview").html("Loading now:" + fileName + " fileExt:" + fileExt + " templateFileName:" + fileName + " fileExt:" + fileExt + " templateFileName:" + templateFileName);
    $("#fileview").load(templateFileName);
    if (getConfirmation("Do you realy want to start " + fileName + " now?")) {
        out.html(_readFile(fileName));
        $("#fileview").html("Template found. Loading now:" + templateFileName);
        _fileExtEditor(fileName, fileExt);
    }
}
function getTemplateFile(fileName, pattern, htmlPath) {
    if (fileName.endsWith(pattern)) {
        templateFileName = path.join("..", "..", htmlPath, pattern + ".html");
        // alert("" + pattern + " Extension found." + path.join("..", "..", htmlPath, pattern+".html"));
    }
    else {
        $("#fileview").html(pattern + " Template NOT found. Loading now:" + templateFileName);
    }
    return templateFileName;
}
function showPictureFile(out, fileExt, fileName, templateFileName) {
    try {
        templateFileName = templateFileName.replace("default.html", "picture.html");
        if (getConfirmation('Start ' + fileName + ' externally now?')) {
            window.open(fileName, fileName);
        }
        else {
            //execCMD('exec "' + fileName + '"', id);
            $("#fileview").html("Loading now:" + fileName);
            $("#fileview").append("<a onclick=\"window.open('" + fileName + "', '" + fileName + "');\"><img src=\"" + fileName + "\" alt=\"file:" + fileName + "\" style=\"min-width:200;min-height:200;width:auto;height:auto\"></a>");
        }
    } catch (error) {
        console.error(error);
    }

}
function showVideoFile(out, fileExt, fileName, templateFileName) {
    try {
        templateFileName = templateFileName.replace("default.html", "video.html");
        if (getConfirmation('Start ' + fileName + ' externally now?')) {
            window.open(fileName, fileName);
            //execCMD('exec "' + fileName + '"', id);            
            execCMD('exec "' + fileName + '"', id);
        }
        else {
            subTemplateFileName = templateFileName.replace("video.html", "\\video\\index.html");
            $("#fileview").html("Temploate found. Loading now:" + templateFileName);
            $("#fileview").load(subTemplateFileName);
            //$("#fileview").append("<a onclick=\"window.open('"+fileName+"', '"+fileName+"');\"><img src=\"" + fileName + "\" alt=\"file:" + fileName + "\" style=\"min-width:200;min-height:200;width:auto;height:auto\"></a>");
            //out.htmp("<a onclick=\"window.open('"+fileName+"', '"+fileName+"');\"><img src=\"" + fileName + "\" alt=\"file:" + fileName + "\" style=\"min-width:200;min-height:200;width:auto;height:auto\"></a>");
            window.open(fileName, fileName);
        }
    } catch (error) {
        console.error(error);
    }

}

// function createZipFromFile(file, savedData) {
//     var zip = new JSZip();
//     var img = zip.folder(".");
//     // var path = require('path');
//     var filename = path.basename(file);
//     console.log(filename);
//     zip.file(filename, savedData);
//     zip.file(filename + ".json", JSON.stringify(savedData));
//     zip.file("article.html", "Welcome to LetzteChance.Org\n\nTitle:" + file + "\n\n");
//     zip.file(filename + ".url", "url:file:////" + file);
//     zip.file("lc.url", "[InternetShortcut]\nURL=https://www.letztechance.org\nHotKey=\nIconFile=\nIconIndex=\nShowCommand=\nModified=\nRoamed=\nIDList=\nAuthor=David Honisch\nWhatsNew=https://www.letztechance.org\nComment=https://www.letztechance.org\nDesc=https://www.letztechance.org\n");
//     //var img = zip.folder("data");
//     var img = zip.folder("letztechance.org");
//     var img = zip.folder("von David Honisch");
//     var img = zip.folder("img");
//     imgData = "R0lGODdhBQAFAIACAAAAAP/eACwAAAAABQAFAAACCIwPkWerClIBADs=";
//     img.file("smile.gif", imgData, { base64: true });
//     var content = zip.generate({ type: "blob" });
//     // see FileSaver.js
//     saveAs(content, file + "-saved.zip");
// }

// function _fileExtEditor(file, fileExt) {
//     $("#extFileName").val(file);
//     const { webUtils } = window.nodeRequire('electron');
//     // const file = files[0];
//     console.log("file:" + file);
//     const cnt = _readFile(file);    // Within browser code
//     var fileSize = getFileSize(file);
//     //outFile.val((fileFullPath).replace("\\", "\\\\") + files[0].name);
//     const cnts = cnt.split("\n");
//     var blocks = [{
//         "type": "header",
//         "data": {
//             "text": "LetzteChance.Org",
//             "level": 3
//         },
//     },
//     {
//         type: 'delimiter',
//         data: {}
//     }
//         // {
//         //     type: 'paragraph',
//         //     data: {
//         //         text: cnt
//         //     }
//         // }
//     ];
//     for (var v in cnts) {

//         var p = {
//             type: 'paragraph',
//             data: {
//                 text: cnts[v]
//             }
//         };
//         blocks.push(p);
//     }
//     var data = {
//         "blocks": blocks
//     }

//     $("#jsFileName" + fileExt + "").val("" + file);
//     $("#editor" + fileExt + "").html("" + cnt);
//     //  $("#editor" + fileExt + "CNT").html("<h1>OUT:<h1>" + cnt);
//     const editor = new EditorJS({
//         /**
//          * Id of Element that should contain the Editor
//          */
//         holder: 'editorext',
//         /**
//          * Available Tools list.
//          * Pass Tool's class or Settings object for each Tool you want to use
//          */
//         // tools: {
//         //   header: {
//         //     class: Header,
//         //     inlineToolbar: ['link']
//         //   },
//         //   list: {
//         //     class: List,
//         //     inlineToolbar: true
//         //   }
//         // },
//         data: {
//             blocks: blocks

//             // {
//             //     type: 'image',
//             //     data: {
//             //         url: 'assets/codex2x.png',
//             //         caption: '',
//             //         stretched: false,
//             //         withBorder: true,
//             //         withBackground: false,
//             //     }
//             // },
//             // ]
//         },
//         onReady: function () {
//             // saveButton.click();
//         },
//         onChange: function (api, event) {
//             console.log('something changed', event);
//         }
//     });
//     const saveButton = document.getElementById('extsaveButton');
//     /**
//      * Toggle read-only button
//      */
//     const toggleReadOnlyButton = document.getElementById('toggleReadOnlyButton');
//     const readOnlyIndicator = document.getElementById('readonly-state');
//     /**
//      * Saving example
//      */
//     saveButton.addEventListener('click', function () {
//         editor.save()
//             .then((savedData) => {
//                 //
//                 createZipFromFile(file, savedData);
//                 //
//                 cPreview.show(savedData, document.getElementById("editorjsCNT"));
//             })
//             .catch((error) => {
//                 console.error('Saving error', error);
//             });
//     });

//     /**
//      * Toggle read-only example
//      */
//     toggleReadOnlyButton.addEventListener('click', async () => {
//         const readOnlyState = await editor.readOnly.toggle();
//         readOnlyIndicator.textContent = readOnlyState ? 'On' : 'Off';
//     });

// }

