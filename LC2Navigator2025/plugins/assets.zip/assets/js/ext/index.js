console.log('File extension loading:');
function fileExt_JS(file) {
    var extFileName = $("#extFileName");
    extFileName.val(file);
    var id = "editorext";
    var out = $("#editorextCNT");
    const { webUtils } = window.nodeRequire('electron');
    // const file = files[0];
    // console.log("file:" + file);
    var fileSize = getFileSize(file);
    var fileExt = getFileExtension(file);
    var fileName = file.replaceAll("\\", "\\\\");
    // const fileData2 = constructFileFromLocalFileData(file)    
    // console.log("path:" + file + " fileExt:" + fileExt + " size:" + fileSize + " MB");
    //outFile.val((fileFullPath).replace("\\", "\\\\") + files[0].name);

    $("#extFileName" + fileExt + "").val("" + file);

    //  $("#editor" + fileExt + "CNT").html("<h1>OUT:<h1>" + cnt);
    switch (fileExt) {
        case "avi":
            if (getConfirmation('Start ' + fileName + 'externally now?')) {
                execCMD('exec "' + fileName + '"', id);
            }
            else {
                window.open(file, fileName);
            }
            break;
        case "bat":
            // $("#editorext").html("" + cnt);
            out.html(file);
            _fileExtEditor(file, fileExt);
            // $("#"+id).html(_readFile(file));
            // execCMD('call "' + file + '"', id);
            break;
        case "exe":
            execCMD('call "' + file + '"', id);
            break;
        case "cmd":
            out.html(file);
            _fileExtEditor(file, fileExt);
            break;
        case "gif":
            if (getConfirmation('Start ' + fileName + ' externally now?')) {
                execCMD('exec "' + fileName + '"', id);
            }
            else {
                window.open(file, fileName);
            }
            break;
        case "png":
            if (getConfirmation('Start ' + fileName + ' externally now?')) {
                execCMD('exec "' + fileName + '"', id);
            }
            else {
                window.open(file, fileName);
            }
            break;
        case "jpeg":
            if (getConfirmation('Start ' + fileName + ' externally now?')) {
                execCMD('exec "' + fileName + '"', id);
            }
            else {
                window.open(file, fileName);
            }
            break;
        case "jpg":
            console.log('exec "' + fileName + '" id:' + id);
            if (getConfirmation('Start ' + fileName + ' externally now?')) {
                execCMD('exec "' + fileName + '"', id);
            }
            else {
                window.open(file, fileName);
            }
            break;
        case "tif":
            if (getConfirmation('Start ' + fileName + ' externally now?')) {
                window.open(file, fileName);
            }
            else {
                execCMD('exec "' + fileName + '"', id);
            }
            break;
        case "svg":
            if (getConfirmation('Start ' + fileName + ' externally now?')) {
                window.open(file, fileName);
            }
            else {
                execCMD('exec "' + fileName + '"', id);
            }
            break;
        case "js":
            out.html(file);
            _fileExtEditor(file, fileExt);
            break;
        case "json":
            out.html(_readFile(file));
            _fileExtEditor(file, fileExt);
            break;
        case "mp4":
            if (getConfirmation('Start ' + file + ' externally now?')) {
                execCMD('exec "' + fileName + '"', id);            }
            else {
                window.open(file, fileName);
            }
            break;
        case "mkv":
            if (getConfirmation('Start ' + fileName + ' externally now?')) {
                window.open(file, fileName);
            }
            else {
                execCMD('exec "' + fileName + '"', id);
            }
            break;
        case "xml":
            _fileExtEditor(file, fileExt);
            break;
        case "xls":
            $("#" + id).html(_readFile(file));
            //$("#editorext").html("" + cnt);
            _fileExtEditor(file, fileExt);
            break;
        case "xlsx":
            if (fileSize > 1) {
                if (getConfirmation('Do you realy want to start ' + file + ' now? It´s about ' + fileSize + " big.")) {
                    _fileExtEditor(file, fileExt);
                } else {
                    $("#" + id).html(file + " not processed.");
                }
            } else {
                _fileExtEditor(file, fileExt);
            }


            break;
        default:
            out.html(_readFile(file));
            _fileExtEditor(file, fileExt);
            break;
    }

    const saveButton = document.getElementById('extsaveButton');
    /**
     * Toggle read-only button
     */
    const toggleReadOnlyButton = document.getElementById('toggleReadOnlyButton');
    const readOnlyIndicator = document.getElementById('readonly-state');
    /**
     * Saving
     */
    saveButton.addEventListener('click', function () {
        createZipFromFile(file, _readBinaryFile(file));
    });

    /**
     * Toggle read-only example
     */
    toggleReadOnlyButton.addEventListener('click', async () => {
        // const readOnlyState = await editor.readOnly.toggle();
        readOnlyIndicator.textContent = readOnlyState ? 'On' : 'Off';
    });
    console.log('File extension loaded.');
}
function createZipFromFile(file, savedData) {
    var zip = new JSZip();
    var img = zip.folder(".");
    // var path = require('path');
    var filename = path.basename(file);
    console.log(filename);
    zip.file(filename, savedData);
    zip.file(filename + ".json", JSON.stringify(savedData));
    zip.file("article.html", "Welcome to LetzteChance.Org\n\nTitle:" + file + "\n\n");
    zip.file(filename + ".url", "url:file:////" + file);
    zip.file("lc.url", "[InternetShortcut]\nURL=https://www.letztechance.org\nHotKey=\nIconFile=\nIconIndex=\nShowCommand=\nModified=\nRoamed=\nIDList=\nAuthor=David Honisch\nWhatsNew=https://www.letztechance.org\nComment=https://www.letztechance.org\nDesc=https://www.letztechance.org\n");
    //var img = zip.folder("data");
    var img = zip.folder("letztechance.org");
    var img = zip.folder("von David Honisch");
    var img = zip.folder("img");
    imgData = "R0lGODdhBQAFAIACAAAAAP/eACwAAAAABQAFAAACCIwPkWerClIBADs=";
    img.file("smile.gif", imgData, { base64: true });
    var content = zip.generate({ type: "blob" });
    // see FileSaver.js
    saveAs(content, file + "-saved.zip");
}

function _fileExtEditor(file, fileExt) {
    $("#extFileName").val(file);
    const { webUtils } = window.nodeRequire('electron');
    // const file = files[0];
    console.log("file:" + file);
    const cnt = _readFile(file);    // Within browser code
    var fileSize = getFileSize(file);
    //outFile.val((fileFullPath).replace("\\", "\\\\") + files[0].name);
    const cnts = cnt.split("\n");
    var blocks = [{
        "type": "header",
        "data": {
            "text": "LetzteChance.Org",
            "level": 3
        },
    },
    {
        type: 'delimiter',
        data: {}
    }
        // {
        //     type: 'paragraph',
        //     data: {
        //         text: cnt
        //     }
        // }
    ];
    for (var v in cnts) {

        var p = {
            type: 'paragraph',
            data: {
                text: cnts[v]
            }
        };
        blocks.push(p);
    }
    var data = {
        "blocks": blocks
    }

    $("#jsFileName" + fileExt + "").val("" + file);
    $("#editor" + fileExt + "").html("" + cnt);
    //  $("#editor" + fileExt + "CNT").html("<h1>OUT:<h1>" + cnt);    
    const editor = new EditorJS({
        /** 
         * Id of Element that should contain the Editor 
         */
        holder: 'editorext',
        /** 
         * Available Tools list. 
         * Pass Tool's class or Settings object for each Tool you want to use 
         */
        // tools: { 
        //   header: {
        //     class: Header, 
        //     inlineToolbar: ['link'] 
        //   }, 
        //   list: { 
        //     class: List, 
        //     inlineToolbar: true 
        //   } 
        // }, 
        data: {
            blocks: blocks

            // {
            //     type: 'image',
            //     data: {
            //         url: 'assets/codex2x.png',
            //         caption: '',
            //         stretched: false,
            //         withBorder: true,
            //         withBackground: false,
            //     }
            // },
            // ]
        },
        onReady: function () {
            // saveButton.click();
        },
        onChange: function (api, event) {
            console.log('something changed', event);
        }
    });
    const saveButton = document.getElementById('extsaveButton');
    /**
     * Toggle read-only button
     */
    const toggleReadOnlyButton = document.getElementById('toggleReadOnlyButton');
    const readOnlyIndicator = document.getElementById('readonly-state');
    /**
     * Saving example
     */
    saveButton.addEventListener('click', function () {
        editor.save()
            .then((savedData) => {
                //
                createZipFromFile(file, savedData);
                //
                cPreview.show(savedData, document.getElementById("editorjsCNT"));
            })
            .catch((error) => {
                console.error('Saving error', error);
            });
    });

    /**
     * Toggle read-only example
     */
    toggleReadOnlyButton.addEventListener('click', async () => {
        const readOnlyState = await editor.readOnly.toggle();
        readOnlyIndicator.textContent = readOnlyState ? 'On' : 'Off';
    });

}

