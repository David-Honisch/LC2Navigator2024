//const checker = new CookieStartChecker();
// class CookieStartChecker {
//     constructor() {
//         this.isStarted = false;
//         this.startCookie = document.cookie;
//         if (!this.isStarted) {
//             this.start();
//         }
//     }
//     start() {
//         if (!this.isStarted) {
//             this.isStarted = true;
//             // Check the start of the function via cookie
//             if (this.startCookie && this.startCookie.split(";")[0].includes("function")) {
//                 console.log("Function started via cookie");
//                 // Add your function here
//                 function startMyFunction() {
//                     console.log("My function is running!");
//                 }
//                 startMyFunction();
//             } else {
//                 console.log("Function started via cookie, but not via cookie");
//             }
//         }
//     }
// }
function set_Cookie(url, name, value) {
    const { session } = window.nodeRequire('electron');
    // Query all cookies.
    session.defaultSession.cookies.get({})
        .then((cookies) => {
            console.log(cookies)
        }).catch((error) => {
            console.log(error)
        })

    // Query all cookies associated with a specific url.
    session.defaultSession.cookies.get({ url: url })
        .then((cookies) => {
            console.log(cookies)
        }).catch((error) => {
            console.log(error)
        })

    // Set a cookie with the given cookie data;
    // may overwrite equivalent cookies if they exist.
    const cookie = { url: url, name: name, value: value }
    session.defaultSession.cookies.set(cookie)
        .then(() => {
            // success
        }, (error) => {
            console.error(error)
        })
};
function get_Cookie(url) {
    // const { session } = window.nodeRequire('electron');
    // return session.defaultSession.cookies.get({ url: url })
    //     .then((cookies) => {
    //         console.log(cookies)
    //     }).catch((error) => {
    //         console.log(error)
    //     });

};
function getCookieValues(key) {
    const cookie = document.cookie.split(';');
    const cookieValues = {};
    for (let i = 0; i < cookie.length; i++) {
        const cookieValue = cookie[i].trim();
        //if (cookieValue.startsWith('personal=')) {
        console.log("cv:" + cookieValue);
        if (cookieValue.startsWith(key)) {
            const key = cookieValue.substring(key.length.trim() + 1).trim();
            const value = cookieValue.substring(key.length.trim() + 1).trim();
            cookieValues[key] = value;
        }
    }
    return cookieValues;
}
// Example usage
// getCookieValues().then((values) => {
//     console.log(values);
// });
function getURLParam(s) {
    $.urlParam = function (name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results == null) {
            return null;
        }
        return decodeURI(results[1]) || 0;
    }
    return $.urlParam(s);
}
function encode_utf8(s) {
    return unescape(encodeURIComponent(s));
}
function decode_utf8(s) {
    return decodeURIComponent(escape(s));
}

function print(t, isAppend) {
    if (!isAppend) {
        out.html(t);
    } else {
        out.append(t);
    }
}

function msg(t) {
    return t;
}


function createDatabase() {
    var table = $("#newdb").val();
    alert('Create Database:' + table);
    var res = model.GetQuery(dbPath, 'CREATE TABLE ' + table + ' ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT(255,0) NOT NULL, "first_name" TEXT(255,0) NULL, "description" TEXT(255,0) NULL, "zipcode" TEXT(255,0) NULL, "city" TEXT(255,0) NULL,	 "street" TEXT(255,0) NULL,	 "url" TEXT NULL);');
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    res = model.GetQuery(dbPath, 'INSERT INTO systables (name,first_name, description,url)VALUES(\'' + table + '\',\'menu.bat\',\'menu.bat\',\'menu.bat\');');
    document.getElementById("newdbcnt").innerHTML += JSON.stringify(res) + " done.";
}
function getExecSQLQuery(divId, dbPath, sql, isAppended, isScrolling) {
    var sqlite3 = "resources\\app\\sqlite\\SQLite3.exe";
    // var sql = "resources\\app\\sqlite\\SQLite3.exe \"" + dbPath + "\" \"select writefile('" + outputFile + "',cnt) from " + table + " where person_id = " + msgId + " order by person_id asc;\"";
    sql = sqlite3 + " \"" + dbPath + "\" \"" + sql + "\"";
    console.log("SQL: " + sql);
    execCMD(sql, divId, isAppended, isScrolling);
}
function getSQLQueryFileContent(divId, table, isAppended, isScrolling) {
    var sqlite3 = "resources\\app\\sqlite\\SQLite3.exe";
    var dbPath = "resources\\"+table+".db";
    var csql = "select count(*) as count from " + table + "_bin;";
    try {
        isScrolling = (isScrolling === undefined || isScrolling == true || isScrolling == "true") ? true : false;
        var rescount = model.GetQuery(dbPath, csql);
        var count = +(rescount[0]["count"]);
        console.log("COUNT:"+count);        
        var where = " where person_id = "+count+" ";
        var sql = "select content from " + table + "_bin "+where+" order by person_id desc limit 1;";
        console.log("SQL: " + sql);
        var execsql = "exec "+sqlite3 + " \"" + dbPath + "\" \"" + sql + "\"";
        console.log("ExecSQL: " + execsql+" isScrolling:"+isScrolling);
        execCMD(execsql, divId, isAppended, isScrolling);
        //write file
        //var sql = "resources\\app\\sqlite\\SQLite3.exe \"" + dbPath + "\" \"select writefile('" + outputFile + "',cnt) from " + table + " where name = " + name + " order by person_id desc limit 1;\"";
    } catch (error) {
        console.error("Error in getSQLQueryFileContent: " + error);
        console.error("Error in getSQLQueryFileContent: " + error.stack);
    }
}
function getSQLQuery(sql, dbPath) {
    var res = model.GetQuery(dbPath, sql);
    var list = {
        "Data": []
    };
    for (var v in res) {
        var t = {
            "id": res[v]['person_id'],
            "created": res[v]['created'],
            "enddate": res[v]['enddate'],
            "name": res[v]['name'],
            "sname": shortName(res[v]['name']),
            "first_name": res[v]['first_name'],
            "last_name": res[v]['last_name'],
            "city": res[v]['city'],
            "street": res[v]['street'],
            "zipcode": res[v]['zipcode'],
            "description": res[v]['description'],
            "url": res[v]['url'],
        };
        list['Data'].push(t);
    }
    return list.Data;

}
function getExtractArg(arguments, pattern) {
    var query;
    var args = JSON.parse(JSON.stringify(arguments));
    var json = args["0"]["name"];
    var prop1 = JSON.parse(json);
    var prop = prop1["prop1"];
    for (var v in prop) {
        var citem = prop[v];
        if (citem.includes(pattern)) {
            query = citem.replace(pattern, '')
        }
    }
    return query;
}
function readItem(table, id) {
    return model.GetQuery(dbPath, 'SELECT * FROM ' + table + ' WHERE person_id=' + id + ';');
}
function getMsgBody(id, title, text) {
    var props = {
        //appendTo: id,
        title: title,
        show: "puff",
        hide: "explode",
        top: 140,
        resizable: true,
        closeOnEscape: true,
        minWidth: 150,
        minHeight: 250,
        height: "auto",
        width: "auto"
    };
    dialogProperties = props !== undefined ? props : dialogProperties;
    text = decodeURI(text);
    text = decodeURIComponent(text);
    // text = decode_utf8(decode_utf8(decodeURI(text)));
    $(id).attr("title", title);
    $(".ui-dialog-title").html(title);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + text);
    $(id).dialog(dialogProperties);

}
function get_MsgBody(id, title, url) {
    var props = {
        //appendTo: id,
        title: title,
        show: "puff",
        hide: "explode",
        top: 140,
        resizable: true,
        closeOnEscape: true,
        minWidth: 150,
        minHeight: 250,
        height: "auto",
        width: "auto"
    };
    dialogProperties = props !== undefined ? props : dialogProperties;
    //text = decode_utf8(decode_utf8(decodeURI(text)));
    $(id).attr("title", title);
    $(".ui-dialog-title").html(title);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).load('' + url);
    $(id).dialog(dialogProperties);
}
function addItem() {
    var res;
    var table = getURLParam('table');
    var name = $("#namedetail").html();
    var first_name = $("#first_namedetail").html();
    var last_name = $("#last_namedetail").html();
    var zipcode = $("#zipcodedetail").html();
    var description = $("#descriptiondetail").html();
    var url = $("#urldetail").html();

    res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
        ' (name,first_name, zipcode,city,street,description,url)VALUES' +
        '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + city + '\',\'' + street + '\',\'' + description + '\',\'' + url + '\');' +
        '');
    document.getElementById("out").innerHTML += JSON.stringify(res) + " done.";
}
function addItem2() {
    var res;
    var table = getURLParam('db');
    var name = $("#name").val();
    var first_name = $("#first_name").val();
    var last_name = $("#last_name").val();
    var zipcode = $("#zipcode").val();
    var description = $("#description").val();
    var url = $("#url").val();
    $("#conformdialog").attr("title", "Add");
    $("#conformdialog").dialog({
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto",
        modal: true,
        buttons: {
            "Yes": function () {
                res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
                    ' (name,first_name, zipcode,description,url)VALUES' +
                    '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + description + '\',\'' + url + '\');' +
                    '');
                document.getElementById("out_cnt").innerHTML += JSON.stringify(res) + " done.";
                $(this).dialog("close");
            },
            Cancel: function () {
                document.getElementById("out_cnt").innerHTML += JSON.stringify(res) + "Not done.";
                $(this).dialog("close");
            }
        }
    });
}

function updateItem() {
    var table = $.urlParam('table');
    var keyValue = {
        "columns": ["person_id", "name", "first_name", "zipcode", "city", "street", "description", "url"],
        "values": [$.urlParam('iddetail'), $("#namedetail").html(), $("#first_namedetail").html(), $("#zipcodedetail").html(), $("#citydetail").html(), $("#streetdetail").html(), $("#descriptiondetail").html(), $("#urldetail").html()],
    };
    var columns = keyValue.columns;
    var values = keyValue.values;
    model.saveData(dbPath, table, columns, values, function () {
        model.getQuery(dbPath, table, 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC', '#app_cnt');
    });

    document.getElementById("newdbcnt").innerHTML += JSON.stringify(keyValue) + " done.";
}


function deleteItem(id) {
    var table = getURLParam('table');
    var query = 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC';
    document.getElementById("newdbcnt").innerHTML = 'Realy delete:' + id + " from " + table;
    // var res = model.GetQuery(dbPath, 'DELETE from \'systables\' WHERE person_id = \'' + id + '\';');
    var res = model.deletePerson(dbPath, table, id, function () {
        model.getQuery(dbPath, table, query, '#app_cnt');
    });
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    location.reload();
}
function shortName(v) {
    if (v !== undefined && v.length > 50) {
        return v.substring(0, 50) + "...";
    }
    else {
        return v;
    }
}


function goToTable() {
    var t = $("#database").val();
    window.location = 'list.html?db=lc&table=' + t;
}

function goToItem() {
    var t = $("#database").val();
    var id = $("#database").val();
    window.location = 'edit.html?db=' + t + '&table=' + t + '&id=' + id;
}

function openPage(s) {
    window.location = s;
}

function openPage(s) {
    window.open(s);
}

function openAddTable() {
    var t = getURLParam('db');
    var url = 'edit.html?db=' + t;
    // openDialog("#dialog", url + " #addPage", t, { minWidth: 250, minHeight: 150, width: 400 });
    // getOpenDialog('#dialog', url, 'Install', { minWidth: 250, minHeight: 150, width: 400 });
    getExtFile(url, 'blank', { minWidth: 250, minHeight: 150, width: 400 });
}

function openAddPage() {
    var t = getURLParam('db');
    var url = 'edit.html?db=' + t;
    window.open(url, '_blank', 'top=500,left=200,frame=true,nodeIntegration=yes, contextIsolation: false,enableRemoteModule: true');
}

function openPage(url, target, props) {
    window.open(url, target, props);
}

function getAppConfig(appConfigFileName) {
    const fs = window.nodeRequire('fs');
    let rawdata = fs.readFileSync(appConfigFileName);
    let appConfig = JSON.parse(rawdata);
    // console.log(JSON.stringify(appConfig));
    return appConfig;
}

function setAppConfig(appConfigFileName, appConfig) {
    let data = JSON.stringify(appConfig, null, 2);
    fs.writeFileSync(appConfigFileName, data);
}

function getFileContent(id, url) {
    $(id).html(get_FileData(url));
    $(id).load(url);
}
function showGetFileContent(id, url, isDialogOpened) {
    isDialogOpened = isDialogOpened == false ? false : true;
    exec_File(url, id.substr(1), isDialogOpened);
}
function loadFileContent(id, url) {
    $(id).load(url);
}
function load_File(url, props) {
    getload_File(url, props);
}
function getload_File(url, props) {
    var prop = props !== undefined ? props : {
        frame: true,
        nodeIntegration: false,
        top: 10,
        left: 200,
        width: 700,
        height: 960
    };
    console.log(prop);
    window.open(url, '_blank', prop);
}

function openBrowser(t) {
    window.nodeRequire("shell").openExternal(t);
}

function openFile(t) {
    window.location = t;
}

function getReadFileWindow(t, id) {
    var childProcess = window.nodeRequire("child_process");
    // This line initiates
    var script_process = childProcess.spawn(t, [], { env: process.env });
    // Echoes any command output
    script_process.stdout.on('data', function (data) {
        console.log('stdout: ' + data);
        document.getElementById(id).innerHTML = data;

    });
    // Error output
    script_process.stderr.on('data', function (data) {
        document.getElementById(id).innerHTML = 'stderr: ' + data;
        console.log('stderr: ' + data);

    });
    // Process exit
    script_process.on('close', function (code) {
        console.log('child process exited with code ' + code);
    });
}

function getLocalFile(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');

    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);
}

function readLocalFile(url) {
    return readFileSync(url)
}
function showDir(_path, id) {
    const fs = window.nodeRequire('fs');
    fs.readdir(_path, (err, files) => {
        if (err)
            console.log(err);
        else {
            document.getElementById(id).innerHTML = "";

            files.map(function (file) {
                //return file or folder path, such as **MyFolder/SomeFile.txt**
                return path.join(_path, file);
            }).filter(function (file) {
                //use sync judge method. The file will add next files array if the file is directory, or not. 
                return fs.statSync(file).isDirectory();
            }).forEach(function (file) {
                //console.log("%s", files);
                document.getElementById(id).innerHTML += "<input onclick=\"if(getConfirmation('Start task '+document.getElementById('inputKey').value+' now?')){showDir('\'" + document.getElementById('inputKey').value + "\\" + file + "\'', 'pluginresult')};\" class=\"btn btn-default\" value=\"" + id + "\"></input>";
                // files.forEach(file => {
                //     document.getElementById(id).innerHTML += "<a onclick=\"if(getConfirmation('Start task '+document.getElementById('inputKey').value+' now?')){execCMD('\'" + document.getElementById('inputKey').value + "\\" + file + "\'', 'pluginresult')};\">" + id + "x</div>";
                // })

            });

            // files.forEach(file => { })
        }
    })
}
function execCMD(text, id, isAppended, isScrolling) {
    const {
        exec
    } = window.nodeRequire('child_process');
    isAppended = isAppended == true ? true : false;
    isScrolling = (isScrolling === undefined || isScrolling == true) ? true : false;
    if (isAppended != true) {
        document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    }
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        //console.log('OUT:' + stdout);
        //console.log('id:' + id);
        if (isAppended == true) {
            $('#' + id).append(stdout);
        }
        else {
            $('#' + id).html(stdout);
        }
        if (isScrolling == true) {
            $("html, body").delay(1000).animate({
                scrollTop: $('#' + id).offset().top
            }, 300);
        }
    });
}
function execFile(file, id, params) {
    var param = "\n" + params.toString().replace() + "\n";
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec("\"" + file + "\"", (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        //console.log('OUT:' + stdout);
        //console.log('id:' + id);
        document.getElementById(id).innerHTML = stdout;

        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
function execJava(cls, text, id) {
    switch (cls) {
        case "dir":
            cls = "call java -jar org.letztechance.domain.api.IO-0.0.1-SNAPSHOT.jar -DIR "
            break;
        case "files":
            cls = "call java -jar org.letztechance.domain.api.IO-0.0.1-SNAPSHOT.jar -FILES "
            break;
        case "allfiles":
            cls = "call java -jar org.letztechance.domain.api.IO-0.0.1-SNAPSHOT.jar -ALL "
            break;

        default:
            cls = "call java -version"
            break;
    }
    text = cls + "\"" + text + "\"";
    console.log(text);
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        //console.log('OUT:' + stdout);
        //console.log('id:' + id);
        var temp = stdout.split("\n");
        document.getElementById(id).innerHTML = temp;

        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
/**
 * '.\\resources\\plugins\\LC2DEBanksUpdater\\install.html'
 * @param {*} text 
 * @param {*} id 
 */
function execPluginCMD(id, url) {
    try {
        var screenWidth = window.width > 639 ? 640 : 480;
        screenWidth = window.width < 479 ? 320 : screenWidth;
        console.log("id" + id + " sw:" + screenWidth + " Real size:" + window.screen.width);
        getOpenDialog('#' + id, '.\\resources\\plugins\\' + url + '\\index.html', '' + url, { title: url, minWidth: 250, minHeight: 150, width: screenWidth });
        //getOpenDialog('#' + id, '.\\assets\\html\\plugin.html', '' + url, { title: url, minWidth: 250, minHeight: 150, width: screenWidth });
        // var xslt = _readFile(".\\assets\\xml\\plugin.xslt");
        var xslt = _readFile(".\\resources\\plugins\\" + url + "\\xml\\app.xslt");
        var xml = _readFile(".\\resources\\plugins\\" + url + "\\xml\\app.xml");
        // console.log("Transforming now...");
        var transform = getXsltProcess(xml, xslt);
        // console.log("Transform:\n"+transform);
        $('#' + url + '_plugin').html(transform);
        // console.log("Transforming done.");
        const papi = window.nodeRequire(path.join(__dirname, '..', '..', 'resources', 'plugins', pluginName, 'index.js'));
        console.log("Show " + url + " done.");
        $('#' + id).attr("title", url);
        setTimeout(() => {
            pluginINIT(url);
        }, 100);
    } catch (error) {
        console.error(error);
        console.error(error.stack);
    }
}
function extExecCMD(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    text = decode_utf8(text);
    text = text.split("\\").join("\\\\");

    // alert('OUT:'+text.length);
    exec('\"' + text + "\"", (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log('OUT:' + stdout);
        document.getElementById(id).innerHTML = stdout;
        $("html, body").delay(1000).animate({
            scrollTop: $('#' + id).offset().top
        }, 3000);
    });
}
function execPluginCMDList(pluginName, id) {
    var result = "";
    var res = getSQLQuery("select * from " + pluginName + "", "resources\\" + pluginName + ".db");
    // console.log(JSON.stringify(res));
    result += "<ul class=\"listul\">";
    for (var v in res) {
        // result += "<li onclick=\""+res[v]["url"]+"\">";
        result += "<li  class=\"" + res[v]["zipcode"] + "\">";
        //result += "<a href=\"javascript:"+res[v]["url"]+"\" onclick=\""+res[v]["url"]+"\">";
        result += "<a onclick=\"" + res[v]["url"] + "\">";
        result += res[v]["name"];
        result += "</a>";
        result += "</li>";
    }
    result += "</ul>";
    $(id).html(result);
    $("html, body").delay(100).animate({
        scrollTop: $('' + id).offset().top
    }, 30);
}
function getExecPluginCMDList(db, table, id, isAppend) {
    var result = "";
    var res = getSQLQuery("select * from " + table + "", db);
    result += "<ul class=\"listul\">";
    for (var v in res) {
        result += "<li  class=\"" + res[v]["street"] + "\">";
        result += "<a onclick=\"" + res[v]["url"] + "\">";
        result += res[v]["name"];
        result += "</a>";
        result += "<br/><span>" + res[v]["description"] + "</span>";
        result += "</li>";
    }
    result += "</ul>";
    if (isAppend) {
        $(id).append(result);
    }
    else {
        $(id).html(result);
    }
}
function execPluginCMDTableList(db, table, id, isAppended) {
    var result = "";
    isAppended = isAppended == true ? true : false;
    var res = getSQLQuery("select * from " + table + "", db);
    // console.log(JSON.stringify(res));
    result += "<ul class=\"listul\">";
    for (var v in res) {
        result += "<li  class=\"" + res[v]["street"] + "\">";
        result += "<a onclick=\"" + res[v]["url"] + "\">";
        result += res[v]["name"];
        result += "</a>";
        result += "<br/><span>" + res[v]["description"] + "</span>";
        result += "</li>";
    }
    result += "</ul>";
    if (isAppended == true) {
        $(id).append(result);
    }
    else {
        $(id).html(result);
    }
}

function execPlugin(text, id) {
    // execlugin(text, id);
    if (pluginINIT !== undefined) {
        pluginINIT();
    }
}
function execJavaItem(x, id) {
    const dirFlag = "isDir";
    const fileFlag = "isFile";
    var result;
    var t = x.split(";");
    var jFile = t[0];
    var df = t[1] !== undefined ? (t[1]).trim() : undefined;
    console.log("+" + df + "+");
    //var isDir = (df !== undefined && df == "isDir")? true : false;
    var isDir = (df != fileFlag && df == dirFlag) ? true : false;
    jFile = jFile.replace(/\\/g, '\\\\');
    console.log(jFile + " DirFlag:" + df + " isDir:" + isDir);
    result = "<a onclick=\"execCMD('type " + jFile + "','" + id + "')\">" + jFile + "</a><br/>";
    if (isDir) {
        result = "<a onclick=\"execJava('allfiles','" + jFile + "','pluginresult',execJavaItem)\">" + jFile + "</a><br/>";
    }
    return result;
}
function evalCMD(text) {
    const {
        exec
    } = window.nodeRequire('child_process');
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            return;
        }
        // console.log('OUT:' + stdout);
        // document.getElementById(id).innerHTML = stdout;
        try {
            eval(stdout);
        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    });
}

function openBrowser(url) {
    openBrowser(url, false);
}

function openBrowser(url, isOpen) {
    if (isOpen) {
        window.nodeRequire("electron").shell.openExternal("https://www.letztechance.org/openlink?" + url);
    } else {
        window.nodeRequire("electron").shell.openExternal(url);
    }
}

function getExtFile(url, target, props) {
    // window.open(url, '_blank', 'top=500,left=200,frame=false,nodeIntegration=no');
    console.log('open:' + url);
    window.open(url, target, '"' + props + '"');
}

function getFile(url, target, props) {
    const childWindow = window.open(url, '_blank');
    // childWindow.document.write('<h1>Hello</h1>');
    childWindow.document.write('<h1>Hello</h1>');
}

function get_FileData(url) {
    return readFileSync(url);
}

function getLocalFile(url, props) {
    var props = props !== undefined ? props : { width: 800, height: 600 };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);

}

function loadFile(url, props) {
    var prop = props !== undefined ? props : "top=500,left=200,width=640,height=960,frame=true,nodeIntegration=no";//{width: 800,  height: 600 };

    // const electron = window.nodeRequire('electron');
    // app.whenReady().then(() => {
    // protocol.handle('atom', (request) =>
    //   net.fetch('file://' + request.url.slice('atom://'.length)))
    setTimeout(() => {
        const electron = window.nodeRequire('electron');
        const BrowserWindow = electron.remote.BrowserWindow;
        const path = window.nodeRequire('path');
        const childWindow = new BrowserWindow(prop);
        childWindow.loadURL(url);

    }, 2000);
    //   })

    // childWindow.readFile(get_FileData(path.join(url)));

}

function getTextWindow(t, props) {
    var prop = props !== undefined ? props : {
        width: 800,
        height: 600
    };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    // childWindow.loadFileContent("file://" + __dirname + "/" + url);
    childWindow.loadURL('data:text/html;charset=utf-8,' + get_FileData(path.join(t)));
}

function openDialog(id, f, title, props) {
    var prop = props !== undefined ? prop : {
        // appendTo: "#dialog",
        title: title,
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto"
    };
    $(function () {
        $(id).attr("title", title);
        $(id).dialog(prop);
        console.log(f);
        $(id + "cnt").load(f);
    });
}

function getOpenDialog(id, f, title, props) {
    var pluginName = title;
    try {
        // $.noConflict();
        dialogProperties = props !== undefined ? props : dialogProperties;
        var res = get_FileData(path.join(f));
        $(id).attr("title", title);
        // console.log(title + " file:" + f);
        // alert(title +" file:"+f);
        $(id + "cnt").html('Loading now...');
        $(id).append('Loading...');
        $(id).html('' + res);
        $(id).dialog(dialogProperties);
    } catch (error) {
        console.error(" id:" + id + " error" + error);
        console.error(error.stack);
    }
}

function getOpenDialogText(id, t, title, props) {
    console.log(id + "\n" + t);
    // $.noConflict();
    dialogProperties = props !== undefined ? props : dialogProperties;
    $(id).attr("title", title);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + t);
    $(id).dialog(dialogProperties);
}
function getConfirmation(title) {
    return confirm(title);
}
function getShowConfirmDialog(id, message, title, props, callback) {
    if (ConfirmDialog(id, message, title, props)) {
        alert('Thanks for confirming');
        callback;
    } else {
        alert('Why did you press cancel? You should have confirmed');
    }
}
function show_ConfirmDialog(id, message, title, props, callback) {
    var isDialogValid = false;
    $('<div></div>').appendTo(id)
        .html('<div><h6>' + message + '?</h6></div>')
        .dialog({
            modal: true,
            title: title,
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Yes: function () {
                    // $(obj).removeAttr('onclick');                                
                    // $(obj).parents('.Parent').remove();

                    $('body').append('<h1>Confirm Dialog Result: <i>Yes</i></h1>');
                    //{alert('taskkill /f /PID %%b','menu_cnt');}else{alert('Bye');}                
                    isDialogValid = true;
                    $(this).dialog("close");
                    $(this).data("callback")(true);
                    // processDialogResult(true, callback);

                },
                No: function () {
                    $('body').append('<h1>Confirm Dialog Result: <i>No</i></h1>');
                    $(this).dialog("close");
                    $(this).data("callback")(false);
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
};
function processDialogResult(result, callback) {
    if (isDialogValid) {
        callback;
    }
    else {
        alert('Cancelled.');
    }
}
function SimpleConfirmDialog(id, message, title, props, callback) {
    $('<div></div>').appendTo(id)
        .html('<div><h6>' + message + '?</h6></div>')
        .dialog({
            modal: true,
            title: title,
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Yes: function () {
                    // $(obj).removeAttr('onclick');                                
                    // $(obj).parents('.Parent').remove();

                    $('body').append('<h1>Confirm Dialog Result: <i>Yes</i></h1>');
                    //{alert('taskkill /f /PID %%b','menu_cnt');}else{alert('Bye');}
                    // callback;
                    $(this).dialog("close");

                },
                No: function () {
                    $('body').append('<h1>Confirm Dialog Result: <i>No</i></h1>');

                    $(this).dialog("close");
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
};
function conFirmDialog(id, title, props) {
    var isValid = false;
    dialogProperties.buttons = {
        "Yes": function () {
            isValid = true;
            $(this).dialog("close");
        },
        Cancel: function () {
            $(this).dialog("close");
        }
    };
    dialogProperties = props !== undefined ? props : dialogProperties;
    // $(function() {
    $(id).attr("title", title);
    // alert(title);
    //$(id).dialog(dialogProperties);
    $(id).dialog({
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto",
        modal: true,
        buttons: {
            "Yes": function () {
                isValid = true;
                return isValid;
                $(this).dialog("close");
            },
            Cancel: function () {
                $(this).dialog("close");
            }
        }
    });
    // // });
    // return isValid;
}
// import { xsltProcess, xmlParse } from 'xslt-processor'
function getXsltFileProcess(source, target) {
    const xmlString = _readFile(source, { encoding: 'utf8', flag: 'r' });
    const xsltString = _readFile(target, { encoding: 'utf8', flag: 'r' });
    return getXsltProcess(xmlString, xsltString);
}

function getXsltProcess(xmlString, xsltString) {
    const { xsltProcess, xmlParse } = window.nodeRequire('xslt-processor');
    return outXmlString = xsltProcess(
        xmlParse(xmlString),
        xmlParse(xsltString)
    );
}
function getXML(source, target, id, isAppend, isFocused) {
    var outXmlString = "";
    try {
        outXmlString = getXsltFileProcess(source, target);
        // console.log("xslt:\n"+outXmlString);
        if (isAppend == true) {
            document.getElementById(id).innerHTML += outXmlString;
        }
        else {
            document.getElementById(id).innerHTML = outXmlString;
        }
    } catch (e) {
        console.error(e);
        console.error(e.stack);
    }
    if (isFocused == true) {
        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    }
}
function getJSON_CR(url, urlext, isAsync, dataType, callBack) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            method: 'POST',
            url: url,
            data: {
                // url where our server will send request which can't be done by AJAX
                'ext_url': urlext
            },
            success: function (data) {
                // try {
                //     // var $h1 = $(data).find('h1').html();
                //     // $('h1').val($h1);
                // } catch (error) {
                //     console.error(error);
                //     console.error(error.stack);
                // }
                //$('#cnt').html(data);
                resolve(data);
            },
            error: function () {
                console.log('Error');
                reject('Error');
            }
        });
    });
}
function _readFile(source, prop) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    return fs.readFileSync(source, { encoding: 'utf8', flag: 'r' });

}

function _readBinaryFile(source, prop) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    return fs.readFileSync(source);

}
function toBase(file) {
    functione
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.toString().substr(reader.result.toString().indexOf(',') + 1));
        reader.onerror = error => reject(error);
    });
}


//
function isFileExisting(dir) {
    const fs = window.nodeRequire('fs');
    var isExisting = false;
    if (!fs.existsSync(dir)) {
        isExisting = true;
    }
    return isExisting;
}
function createDir(dir, id) {
    const fs = window.nodeRequire('fs');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
        document.getElementById(id).innerHTML += dir + "created.<br>";
    }
}


function getHeader(host) {
    var result = "<div id=\"cm-menu\">";
    result += "<nav id=\"top\" class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"cm-flex\"><a href=\"index.html\" class=\"cm-logo\"></a></div> ";
    result += "<div class=\"btn btn-primary md-menu-white lc-header\" data-toggle=\"cm-menu\" id=\"cm-menu\"></div> ";
    result += "</nav>";

    result += "<div id=\"ctop\"></div>";

    result += "<div id=\"cm-menu-content\"> ";
    result += "<div id=\"cm-menu-items-wrapper\"> ";
    result += "<div id=\"cm-menu-scroller\"> ";
    result += "<ul class=\"cm-menu-items\"> ";

    result += "<li class=\"cm_submenu\"><a href=\"index.html\">Application</a></li> ";
    result += "<li ><a href=\"index.html\">Application</a></li> ";
    // result += "<li ><a href=\"index.html\">Application</a></li> ";
    result += "</ul> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += " <header id=\"cm-header\"> ";
    result += " <nav class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"btn btn-primary md-menu-white hidden-md hidden-lg lc-header\" data-toggle=\"cm-menu\">";
    result += "</div> ";
    result += " <div class=\"cm-flex\"> ";
    result += " <div class=\"cm-breadcrumb-container\"> ";
    // result += " <ol class=\"breadcrumb\"> ";
    // result += " <li><a href=\"index.html\">" + msg('indexpage') + "</a></li> ";
    // result += " <li><a href=\"start.html\" class=\"active\">" + msg('startpage') + "</a></li> ";
    // result += " </ol> ";
    result += "</div> ";
    result += "<form id=\"cm-search\" action=\"" + host + "search.html\" method=\"get\"> ";
    result += "<input type=\"search\" id=\"btnquery\" name=\"query\" autocomplete=\"on\" placeholder=\"" + msg('search') + "\"> ";
    result += "<input type=\"hidden\" name=\"q\" value=\"search\">";

    result += "</form> ";
    result += "</div> ";

    result += "</ul> ";

    result += "</div> ";
    result += "</nav> ";
    result += "</header> ";
    return result;
}
//Java
//getJavaClass("SumOfNumbers",[3,1, 2, 3]);
function printJavaResult(text) {
    const { JavaCaller, JavaCallerCli } = window.nodeRequire("java-caller");
    const spawn = window.nodeRequire("child_process").spawn;
    var java = window.nodeRequire('java');
    var javaLangSystem = java.import('java.lang.System');
    javaLangSystem.out.printlnSync(text);
}
function getJavaClass(className, params, id) {
    let result = "";
    let args = [];
    args.push(className); // remove first argument
    // Push the numbers other arguments
    params.forEach((element) => {
        args.push(element);
    });

    // Starting our worker
    console.log("Starting work");
    let spawn = getSpawn();
    let worker = spawn("java", args);
    console.log('Java Args:' + JSON.stringify(args));
    printJavaWorker(worker, id);
}

function getSpawn() {
    return window.nodeRequire("child_process").spawn;
}
function printJavaWorker(worker, id) {
    let result = "";
    // let worker = spawn("java", args);
    worker.stdout.on("data", function (data) {
        console.log("response: " + data);
        // $("#app_cnt").append("<h1>Data:"+data+"</h1>");
        // result += "<h1>Data:"+data+"</h1>";
        result += "" + data + "";
    });
    worker.on("close", function (code, signal) {
        console.log("Java finished with exit code of " + code);
        // $("#app_cnt").append("Code:"+code);
        // result += "<p>process returncode:"+code+"</p>";
        $("" + id).html(result);
    });

}
function getPluginButtons(pluginName) {
    return getPluginReloadButton(pluginName) + getPluginInstallRequirementsButton(pluginName);

}
function getPluginReloadButton(pluginName) {
    return "<input type=\"button\" value=\"reload\" class=\"btn btn-info\" onclick=\"execPluginCMD('out','" + pluginName + "');\"/>";

}
function getPluginInstallRequirementsButton(pluginName) {
    return "<input type=\"button\" value=\"Run requirement installation\" class=\"btn btn-warning\" onclick=\"getOpenDialog('#dialog','.\\\\resources\\\\plugins\\\\" + pluginName + "\\\\install.html','Install',{ minWidth: 250,  minHeight: 150, width: 400});\"/>";
}
function getInstallModulesButton(pluginName) {
    return "<input type=\"button\" value=\"Run requirement installation\" class=\"btn btn-warning\" onclick=\"Install_Mod(resDir,'modcnt');\"/>";
}
function showDB(s, isConfirm) {
    if (isConfirm) {
        if (getConfirmation('Show DB now?')) { switchListDBLocation(s) };
    }
    else {
        switchListDBLocation(s);
    }
}
function switchListDBLocation(s) {
    window.location = 'list.html?db=' + s + '&table=' + s;
}
function syncCopy(source, destination) {
    var files = [];
    //var targetFolder = path.join( destination, path.basename( source ) );
    var targetFolder = destination;
    if (!fs.existsSync(targetFolder)) {
        fs.mkdirSync(targetFolder);
    }
    // Copy
    if (fs.lstatSync(source).isDirectory()) {
        files = fs.readdirSync(source);
        files.forEach(function (file) {
            var curSource = path.join(source, file);

            if (fs.lstatSync(curSource).isDirectory()) {
                fs.copyFolderRecursiveSync(curSource, targetFolder);
            } else {
                fs.copyFileSync(curSource, targetFolder + file);
            }
        });
    }
};
//
function getFullIndexList(id, api, apiext) {
    // var api = 'https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=';
    console.log("get list by" + api);
    try {
        var p1 = getJSON_CR(api, apiext, 'GET', true, 'jsonp');
        // jQuery('#outcnt').html('Reading' + api);
        p1.then(function (data) {
            try {
                var oJson = JSON.parse(data, false);
                var result = "";
                for (var i = 0; i < oJson.list.length; i++) {
                    var counter = oJson.list[i];
                    result += '<option value="' + counter.name + '">' + counter.id + '</option>';
                }
                // $('#tableId').append(result);
                $(id).append(result);
            } catch (e) {
                $('#error').before('Error:<hr>' + e.stack);
                $('#error').before(e);
            }
        });
    } catch (e) {
        $('#error').before('Error:<hr>' + e.stack);
        $('#error').before(e);
    }
    console.log("List done");
}


//var rowCount=0;
function createStatusbar(obj) {
    rowCount++;
    var row = "odd";
    if (rowCount % 2 == 0) row = "even";
    this.statusbar = $("<div class='statusbar " + row + "'></div>");
    this.filename = $("<div class='filename'></div>").appendTo(this.statusbar);
    this.size = $("<div class='filesize'></div>").appendTo(this.statusbar);
    this.progressBar = $("<div class='progressBar'><div></div></div>").appendTo(this.statusbar);
    this.abort = $("<div class='abort'>Abort</div>").appendTo(this.statusbar);
    obj.after(this.statusbar);

    this.setFileNameSize = function (name, size) {
        var sizeStr = "";
        var sizeKB = size / 1024;
        if (parseInt(sizeKB) > 1024) {
            var sizeMB = sizeKB / 1024;
            sizeStr = sizeMB.toFixed(2) + " MB";
        }
        else {
            sizeStr = sizeKB.toFixed(2) + " KB";
        }

        this.filename.html(name);
        this.size.html(sizeStr);
    }
    this.setProgress = function (progress) {
        var progressBarWidth = progress * this.progressBar.width() / 100;
        this.progressBar.find('div').animate({ width: progressBarWidth }, 10).html(progress + "% ");
        if (parseInt(progress) >= 100) {
            this.abort.hide();
        }
    }
    this.setAbort = function (jqxhr) {
        var sb = this.statusbar;
        this.abort.click(function () {
            jqxhr.abort();
            sb.hide();
        });
    }
}
function sendFileToServer(id, formData, status) {
    var uploadURL = "https://hayageek.com/examples/jquery/drag-drop-file-upload/upload.php"; //Upload URL
    var extraData = {}; //Extra Data.
    var jqXHR = $.ajax({
        xhr: function () {
            var xhrobj = $.ajaxSettings.xhr();
            if (xhrobj.upload) {
                xhrobj.upload.addEventListener('progress', function (event) {
                    var percent = 0;
                    var position = event.loaded || event.position;
                    var total = event.total;
                    if (event.lengthComputable) {
                        percent = Math.ceil(position / total * 100);
                    }
                    //Set progress
                    status.setProgress(percent);
                }, false);
            }
            return xhrobj;
        },
        url: uploadURL,
        type: "POST",
        contentType: false,
        processData: false,
        cache: false,
        data: formData,
        success: function (data) {
            status.setProgress(100);

            //$("#status1").append("File upload Done<br>");           
        }
    });

    status.setAbort(jqXHR);
}
//
function LocalFileData(path) {
    this.arrayBuffer = (() => {
        var buffer = window.nodeRequire('fs').readFileSync(path);
        var arrayBuffer = buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
        return [arrayBuffer];
    })();
    this.name = window.nodeRequire('path').basename(path);
    this.type = window.nodeRequire('mime-types').lookup(window.nodeRequire('path').extname(path)) || undefined;
}
function constructFileFromLocalFileData(localFileData) {
    return new File(localFileData.arrayBuffer, localFileData.name, { type: localFileData.type });
};


//
function exec_FileList(pluginName, table, id, isAppended) {
    var result = "";
    isAppended = isAppended == true ? true : false;
    var res = getSQLQuery("select * from " + table + "", "resources\\" + pluginName + ".db");
    // console.log(JSON.stringify(res));
    result += "<ul class=\"listul\">";
    for (var v in res) {
        result += "<li  class=\"" + res[v]["zipcode"] + "\">";
        // result += "<a onclick=\"execCMD('" + res[v]["url"] + "',''+id);\">";
        //result += "<a onclick=\"if(getConfirmation('Start " + res[v]["url"] + "?')){execCMD('" + res[v]["url"] + "', 'pout')};\">";
        result += "<a onclick=\"if(getConfirmation('Start " + res[v]["url"] + "?')){" + res[v]["url"] + "};\">";
        result += res[v]["name"];
        result += "</a>";
        result += "</li>";
    }
    result += "</ul>";
    if (isAppended == true) {
        $(id).append(result);
    }
    else {
        $(id).html(result);
    }
}
function extractFilePath(filePath) {
    const lastSeparatorIndex = Math.max(filePath.lastIndexOf('\\'), filePath.lastIndexOf('/'));
    if (lastSeparatorIndex === -1) {
        return '';
    }
    return filePath.substring(0, lastSeparatorIndex);
}
function exec_File(file, id, isDialogOpened) {
    // alert(file);
    var result = "";
    var fileExt = getFileExtension(file);
    var fileName = file.substring(file.lastIndexOf('\\') + 1);
    var onlyPath = window.nodeRequire('path').dirname(file);
    var out = $('#' + id);
    isDialogOpened = isDialogOpened == false ? false : true;
    if (isDialogOpened == true) {
        out.html('Loading ' + file + ' id:' + id + ' Path:' + onlyPath);
        // console.log('Loading ' + file + " Ext:" + fileExt + ' id:' + id + ' Path:' + onlyPath);
        getOpenDialog('#dialog', '.\\assets\\html\\ext\\index.html', '' + file, { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
        // console.log("file:" + JSON.stringify(file));
        // console.log("file:" + file);
        setTimeout(() => {
            new fileExt_JS(file);
            // console.log("exec_File caller:"+exec_File.caller.toString()+" file:" + file);
        }, 1000);
    }

}
function exec_FileList(pluginName, table, id, isAppended) {
    var result = "";
    isAppended = isAppended == true ? true : false;
    var res = getSQLQuery("select * from " + table + "", "resources\\" + pluginName + ".db");
    // console.log(JSON.stringify(res));
    result += "<ul class=\"listul\">";
    for (var v in res) {
        result += "<li  class=\"" + res[v]["zipcode"] + "\">";
        // result += "<a onclick=\"execCMD('" + res[v]["url"] + "',''+id);\">";
        //result += "<a onclick=\"if(getConfirmation('Start " + res[v]["url"] + "?')){execCMD('" + res[v]["url"] + "', 'pout')};\">";
        result += "<a onclick=\"if(getConfirmation('Start " + res[v]["url"] + "?')){" + res[v]["url"] + "};\">";
        result += res[v]["name"];
        result += "</a>";
        result += "</li>";
    }
    result += "</ul>";
    if (isAppended == true) {
        $(id).append(result);
    }
    else {
        $(id).html(result);
    }
}
function showResList(res, pluginName, exec, isAppend, isIdActive) {
    var result = "<ul class=\"listul\">";
    try {
        for (var v in res) {
            result += "<li  class=\"" + res[v]["zipcode"] + "\">";
            result += "<a onclick=\"if(getConfirmation('" + exec + "" + res[v]["name"] + "?')){" + exec + (isIdActive == true ? res[v]["id"] : res[v]["url"]) + "};\">";
            result += '' + res[v]["name"];
            result += "</a>";
            result += '<span>' + res[v]["description"] + '</span>';
            result += "</li>";
        }
        result += "</ul>";
    } catch (e) {
        alert(e.stack);
    }
    if (isAppend) {
        $('#' + pluginName).append(result);
    }
    else {
        $('#' + pluginName).html(result);
    }
}
function show_ResList(res, id, exec, execTitle, isAppend) {
    var result = "<ul class=\"listul\">";
    try {
        for (var v in res) {
            result += "<li  class=\"" + res[v]["zipcode"] + "\">";
            //result += "<a onclick=\"if(getConfirmation('Kill " + res[v]["first_name"] + "?')){execCMD('" + exec + "" + res[v]["url"] + "','pout');};\">";
            result += "<a onclick=\"if(getConfirmation('" + res[v]["first_name"] + "?')){" + exec + "" + res[v]["url"] + ";};\">";
            result += execTitle + '' + res[v]["name"];
            result += "</a>";
            result += '<span>-Description:' + res[v]["description"] + '</span>';
            result += "</li>";
        }
        result += "</ul>";
    } catch (e) {
        alert(e.stack);
    }
    if (isAppend == true) {
        console.log("appending..." + id);
        $('#' + id).append(result);
    }
    else {
        $('#' + id).html(result);
    }
}
function showResourceList(res, pluginName, exec, isAppend, isIdActive) {
    var result = "<ul class=\"listul\">";
    try {
        for (var v in res) {
            result += "<li  class=\"" + res[v]["zipcode"] + "\">";
            //result += "<a onclick=\"if(getConfirmation('" + exec + "" + res[v]["name"] + " description:" + res[v]["description"] + "?')){execCMD('" + exec + "" + res[v]["url"] + "', 'pout')};\">";
            result += "<a onclick=\"if(getConfirmation('" + (isIdActive == true ? exec : "") + "" + res[v]["name"] + "\ndescription:" + res[v]["description"] + "?')){" + exec + "" + (isIdActive == true ? res[v]["id"] : res[v]["url"]) + "};\">";
            result += '' + res[v]["name"];
            result += "</a>";
            result += '<span>' + res[v]["description"] + '</span>';
            result += "</li>";
        }
        result += "</ul>";
    } catch (e) {
        alert(e.stack);
    }
    if (isAppend == true) {
        $('#' + pluginName).append(result);
    }
    else {
        $('#' + pluginName).html(result);
    }
}
function show_ResourceList(res, pluginName, table, title, exec, execAfter, isAppend) {
    var result = "<ul class=\"listul\">";
    try {
        for (var v in res) {
            result += "<li  class=\"" + res[v]["zipcode"] + "\">";
            result += "<a onclick=\"if(getConfirmation('" + title + "" + res[v]["name"] + "-" + res[v]["description"] + "?')){" + exec + "" + res[v]["" + table + ""] + "" + execAfter + "" + "};\">";
            result += title + ' ' + res[v]["name"];
            result += "</a>";
            result += '<br/><span>' + res[v]["description"] + '</span>';
            result += "</li>";
        }
        result += "</ul>";
    } catch (e) {
        alert(e.stack);
    }
    if (isAppend == true) {
        $('#' + pluginName).append(result);
    }
    else {
        $('#' + pluginName).html(result);
    }
}
var doDrop_file = (function () {
    return function read_Drop_File(f) {
        //var f = files[0];
        var reader = new FileReader();
        try {
            reader.onload = function (e) {
                var data = e.target.result;
                data = new Uint8Array(data);
                try {
                    // process_wb(XLSX.read(data, {
                    //     type: 'array'
                    // }));
                    console.log(data);
                } catch (e) {
                    console.error(e.stack);
                }

            };
        } catch (e) {
            console.error(e.stack);
        }
        reader.readAsArrayBuffer(f);
    };
})();
//set_DragOver('maindrop','inputFile',"htmlout" );
function set_DragOver(id, target, htmlout, outFile, allowedExt) {
    try {
        // console.log("DIV:" + id + ".");
        var drop = document.getElementById(id);
        var inputFile = $("#" + inputFile);
        var htmlOUT = document.getElementById(htmlout);
        var outFile = $("#" + outFile);
        var newdb = $("#" + target);

        function handleDrop(e) {
            e.stopPropagation();
            e.preventDefault();
            // console.log("handleDrop");
            // console.log("event:" + JSON.stringify(e));
            var files = e.dataTransfer.files;
            const { webUtils } = window.nodeRequire('electron');
            const fileFullPath = webUtils.getPathForFile(files[0]);
            // console.log("path:" + fileFullPath + " filename:" + files[0].name + " size:" + files[0].size);
            //outFile.val((fileFullPath).replace("\\", "\\\\") + files[0].name);
            var fileName = (fileFullPath).replace("\\", "\\\\");
            var fileExt = getFileExtension(fileName);
            var file_Name = getFileNameOnly(fileName);
            newdb.val(file_Name.replace(fileExt, "").replace(".", "_"));
            outFile.val(fileName);
            console.log("fileName:" + fileName);
            if (!allowedExt.includes(fileExt)) {
                if (getConfirmation('Read ' + fileName + ' as excel now?')) {
                    doLoadFile(files, htmlOUT);
                }
                else {
                    execCMD('echo "' + fileName + '" not processed.', id);
                }
            } else {
                execCMD('echo "' + fileName + '" not processed.', id);
            };
            exec_File(fileName, id);
        }

        function handleDragover(e) {
            console.log("handleDragover");
            e.stopPropagation();
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        }
        if (drop !== null && drop !== undefined) {
            drop.addEventListener('dragenter', handleDragover, false);
            drop.addEventListener('dragover', handleDragover, false);
            drop.addEventListener('drop', handleDrop, false);
            // console.log("handleDragover:" + id + ".");
        }
    } catch (error) {
        console.error(error);
    }

}
function setDragOver(id, target, out) {
    var fileName = $('#' + target).val();
    console.log('file init: ' + fileName);
    try {
        //electron = window.nodeRequire('electron');
        var drop = document.getElementById(id);
        var drop2 = $('#' + id);
        var divTarget = $('#' + target);
        var value = divTarget.val();

        // drop2.html('id:' + id + " target:" + target + ' value:' + value);
        console.log('id:' + id + " target:" + target + ' value:' + value);
        drop2.css('border', '10px solid #0185A1');
        $('#' + target).val("" + $('#' + target).val());

        document.addEventListener('' + id, (event) => {
            // event.preventDefault();
            // event.stopPropagation();
            for (const f of event.dataTransfer.files) {
                fileName = f.path;
                // Using the path attribute to get absolute file path
                console.log('fileName: ' + fileName);
                drop2.append('Loading ' + fileName);
            }
        });

        document.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log()
        });

        document.addEventListener('dragenter', (event) => {
            // console.log('enter'+id);
            drop2.html('enter ' + id);
        });

        document.addEventListener('dragleave', (event) => {
            // console.log('left '+id);
            drop2.html('drop a file');
        });

        document.addEventListener('drop', (event) => {
            event.preventDefault();
            event.stopPropagation();
            console.log('drop id:' + id);
            for (const f of event.dataTransfer.files) {
                try {
                    var fname = f.path;
                    // Using the path attribute to get absolute file path
                    console.log('fileName:' + fileName + " fname:" + fname + " file:" + JSON.stringify(f));
                    fileName = (f.path !== undefined) ? f.path : fileName;
                    console.log('File Path of dragged files2: ' + fileName);
                    // console.log('File Path of dragged files2: ' + fileName);
                    drop2.append('Loading ' + fileName);
                    $('#' + id).val(fileName);
                    // if (!fileName+"".includes(".mp4") && !fileName+"".includes(".m4")) {
                    //     execCMD('type ' + f.path, '' + target);
                    // }
                    // handleFileUpload(id, f);
                } catch (error) {
                    console.error(error);
                }
            }

            if (fileName !== undefined) {
                // exec_File(fileName, '' + target);
                // exec_File(fileName, '' + id);
            }
            //  event.preventDefault();
            // event.stopPropagation();
        });
    } catch (error) {
        console.error(error);
        console.error(error.stack);
    }
}
//unzip
function do_Unzip(link, target, id) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    document.getElementById(id).innerHTML += "<br/>Checking if file <strong>" + link + "</strong> is an <strong>archive</strong>." + target;
    // target = path.join(target);
    // link = path.join(link);
    // console.log("Checking if file " + link + " is an archive." + target + "-" + id);
    // document.getElementById(id).innerHTML += "<br/>Checking if file <strong>" + link + "</strong> is an <strong>archive</strong>."+target;
    if (link.includes(".zip")) {
        try {
            link = link.replace("\\", "\\\\");
            target = target.replace("\\", "\\\\");
            console.log('extracting ' + link + ' \"' + target + '\"');
            document.getElementById(id).innerHTML += '<p> ' + link + ' <strong>extracting</strong> to:<br/>' + target + '</p>';
            document.getElementById(id).innerHTML += '<hr/>extracting ' + link + ' "' + target + '"';

            console.log('extracting ' + link + ' \"' + target + '\" now...');
            execCMD('extract ' + link + ' "' + target + '"', id, true, false);
            document.getElementById(id).innerHTML += '<p> ' + link + ' <strong>extracted</strong> to:<br/>' + target + '</p>';
            document.getElementById(id).innerHTML += '<hr/>extract ' + link + ' "' + target + '"';

        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    } else {
        document.getElementById(id).innerHTML += '<p> ' + link + '<br/><strong>NOT</strong> extracted to:<br/>' + target + '</p>';
    }
    //document.getElementById(id).innerHTML += '<hr>' + link + ' extracted <strong>DONE</strong>';
    console.log('Extraction complete');

}
//dowload
function execPluginDL(id, url, localFile) {
    var screenWidth = window.width > 639 ? 640 : 480;
    try {
        screenWidth = window.width < 479 ? 320 : screenWidth;
        console.log(screenWidth + " Real size:" + window.screen.width)
        var tDir = path.join(__dirname, '../', '../');
        url = url.replace("\\", "\\\\");
        var downloadUrls = [
            {
                path: url,
                file: localFile,
            }

        ];
        getOpenDialog('#' + id, '.\\assets\\html\\pluginsdl.html', '' + url, { title: url, minWidth: 250, minHeight: 150, width: screenWidth });
        $(id).attr("title", "DL:" + url);
        $('#dlplugintitle').html('LocalFile:' + localFile);
        $('#dlpluginurl').html(url);
        $('#dlpluginfile').html('to ' + localFile);
        //execCMD(".\\resources\\cmd\\getupdates.bat "+url+" "+loadFile, id,true);
        //execCMD(".\\resources\\cmd\\getupdates.bat "+url+"", id,true);
        doDownload(downloadUrls, tDir, 'dlpluginout');
        //execCMD(".\\extract.exe "+localFile+"", id,true);

    } catch (error) {
        console.error(error);
        console.error(error.stack);
    }
}



function Install_Mod(tmpDir, id) {
    Install_Modules(corelibs, tmpDir, id);
}
function InstallMod(corelibs, tmpDir, id) {
    Install_Modules(corelibs, tmpDir, id);
}
function Install_Modules(libs, tmpDir, id) {
    try {
        $('#' + id).html('<h1>Loading modules...</h1>');
        const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
        npmInstallAsync(libs, tmpDir)
            .then(function (data) {
                $('#' + id).append('<h1>Successfully Installed to:</h1>' + tmpDir + '<br><h2>Done. Close window now and start main plugin.</h2><textarea>' + JSON.stringify(data) + '</textarea>');
            });
        printDir(path.join(tmpDir, 'node_modules'), id);
    } catch (error) {
        alert(error);
        document.getElementById(id).innerHTML += '<h2>ERROR:</h2>' + error;
    }
}
function getDownloads(links, target) {
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file, target);
    }
}
function doDownload(links, target, id) {
    id = id !== undefined ? id : "appcnt";
    console.log("Target:" + target);
    for (var v in links) {
        get_Download_File(links[v].path, links[v].file, target + links[v].file, target, id);
    }
}

function get_Download_File(baseUrl, fileName, target, targetOnly, id) {
    console.log("get_DownloadFile:" + baseUrl + "-" + fileName + "-" + target + "-t:" + targetOnly + " ID:" + id);
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    // Save variable to know progress
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + fileName;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });

    var out = fs.createWriteStream(target);
    req.pipe(out);
    req.on('response', function (data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });
    req.on('data', function (chunk) {
        // Update the received bytes
        received_bytes += chunk.length;
        showDLProgress(received_bytes, total_bytes, id);
    });
    req.on('end', function () {
        document.getElementById("" + id).innerHTML += "<br/>" + url
            + "<br/>File succesfully downloaded.<br/><strong>Extracting:</strong> now:<br/>"
            + target + "to<br/>" + targetOnly + ".";
        if (target.includes(".zip")) {
            setTimeout(() => {
                do_Unzip(target, targetOnly, id);
                console.log("CMD:" + cmd);
                var sqlite = ".\\resources\\app\\sqlite\\SQLite3.exe";
                var dbfile = ".\\resources\\lc.db";
                var sqlfile = ".\\resources\\sql\\" + fileName + ".sql";
                var cmd = "call     " + sqlite + "" + " " + dbfile + " \".read '" + sqlfile + "'\"";
                setTimeout(() => {
                    //var cmd = "call "+sqlite+ ""+" "+dbfile+" .read "+sqlfile+"";
                    console.log("CMD:" + cmd);
                    execCMD("" + cmd, id, true);
                }, 6000);
            }, 3000);
        }
    });
}
function getDownloadFile(baseUrl, link, targetFile, target) {
    console.log("getDownloadFile" + baseUrl + "-" + link + "-" + targetFile + "-" + target)
    get_DownloadFile(baseUrl, link, targetFile, target, "out_cnt");
}
function get_DownloadFile(baseUrl, link, targetFile, target, id) {
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });
    var out = fs.createWriteStream(targetFile);
    req.pipe(out);
    req.on('response', function (data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });
    req.on('data', function (chunk) {
        // Update the received bytes
        received_bytes += chunk.length;
        // showProgress(id, received_bytes, total_bytes);
    });
    req.on('data', function (chunk) {
        // Update the received bytes
        received_bytes += chunk.length;
        showDLProgress(received_bytes, total_bytes, id);
    });
    req.on('end', function () {
        // alert("File succesfully downloaded");
        document.getElementById(id).innerHTML += "<br>" + url + " File succesfully downloaded";
        document.getElementById(id).innerHTML += "<br>" + targetFile + " File succesfully written.";
        document.getElementById(id).innerHTML += "<br>Path:" + target + ".";
        document.getElementById(id).innerHTML += "<br>Link:" + link + ".";
        if (('' + targetFile).includes(".zip")) {
            document.getElementById("" + id).innerHTML += "<br>" + url + "File succesfully downloaded. Extracting now:<br/>" + target + fileName + "to<br/>" + target + ".";
            setTimeout(() => {
                document.getElementById(id).innerHTML += "<br>Unzip process:" + targetFile + " running.";
                do_Unzip(targetFile, target, id);
                document.getElementById(id).innerHTML += "<br>Unzip process:" + targetFile + " done.";
            }, 3000);
            document.getElementById(id).innerHTML += "<br>Download and Unzip process:" + targetFile + " done.";
        }
    });
}

function showDLProgress(received, total, id) {
    var percentage = (received * 100) / total;
    console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
    document.getElementById(id + "_progress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
}
function showProgress(id, received, total) {
    try {
        console.log("ID:" + id);
        var percentage = (received * 100) / total;
        console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
        //document.getElementById(id).innerHTML += percentage + "% | " + received + " bytes out of " + total + " bytes.";
        document.getElementById(id + "_progress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
    } catch (error) {
        console.err(error);
        console.err(error.stack);

    }

}

function handleFileUpload(id, files) {
    foreach(file in files)
    $(id).val(file);
}
function handle_FileUpload(obj, files) {
    for (var i = 0; i < files.length; i++) {
        var fd = new FormData();
        fd.append('file', files[i]);
        var status = new createStatusbar(obj); //Using this we can set progress.
        status.setFileNameSize(files[i].name, files[i].size);
        sendFileToServer(id, fd, status);

    }
}
function eMsg(e) {
    console.error(e);
    // console.error(e.stack);
}
function getFileFullPath(fileName) {
    const { webUtils } = window.nodeRequire('electron');
    return webUtils.getPathForFile(fileName);
}
function do_LoadFile(file, htmlOUT) {    
    var files = fileToFilesArray(file);
    doLoadFile(files, htmlOUT)
}
function fileToFilesArray(filePath) {
    const fs = window.nodeRequire('fs');
    const path = window.nodeRequire('path');

    // Read the file as a buffer
    const buffer = fs.readFileSync(filePath);
    // Get the file name and extension
    const fileName = path.basename(filePath);
    const fileType = ""; // Optionally, set the MIME type if known

    // Create a Blob from the buffer
    const blob = new Blob([buffer], { type: fileType });
    // Create a File object (if supported)
    const file = new File([blob], fileName, { type: fileType });

    // Return as an array, similar to input.files
    return [file];
}

// Example usage:
// let files = fileToFilesArray('C:\\path\\to\\yourfile.txt');
// doLoadFile(files, htmlOUT);
function doLoadFile(files, htmlOUT) {
    var XLSX = window.nodeRequire('xlsx');
    var f = files[0];
    // Ensure file is a File or Blob object before proceeding
    // if (!(file instanceof Blob)) {
    //     console.error("do_LoadFile: Provided file is not a Blob/File object.");
    //     return;
    // }
    var reader = new FileReader();
    // console.log("doFile path:" + f.webkitRelativePath.fullPath + " filename:" + f.name + " size:" + f.size + " json obj:" + JSON.stringify({ "file": f }));
    try {        
        reader.onload = function (e) {
            var data = e.target.result;
            data = new Uint8Array(data);
            try {
                console.log("process do_file" + f + " data length:\n" + data.length);
                processWb(XLSX.read(data, {
                    type: 'array'
                }), htmlOUT);
            } catch (e) {
                console.error(e.stack);
            }

        };
    } catch (e) {
        console.error(e.stack);
    }
    reader.readAsArrayBuffer(f);

}
function processWb(wb, htmlOUT) {
    console.log("processWb");
    var XLSX = window.nodeRequire('xlsx');
    /* get data */
    var ws = wb.Sheets[wb.SheetNames[0]];
    var data = XLSX.utils.sheet_to_json(ws, { header: 1 });
    /* update canvas-datagrid */
    htmlOUT.innerHTML = "";
    var cDg = canvasDatagrid({ parentNode: htmlOUT, data: data });
    cDg.style.height = '100%';
    cDg.style.width = '100%';
    cDg.data = data;
    // XPORT.disabled = false;

    /* create schema (for A,B,C column headings) */
    var range = XLSX.utils.decode_range(ws['!ref']);
    try {
        for (var i = range.s.c; i <= range.e.c; ++i) {
            try {
                cDg.schema[i - range.s.c].title = XLSX.utils.encode_col(i);                
            } catch (error) {
                console.error("WARNING:" + error.stack);        
            }
        }
    } catch (e) {
        console.error("WARNING:" + e.stack+" caller:"+ processWb.caller.toString());
    }
    htmlOUT.style.minHeight = (window.innerHeight - 400) + "px";
    htmlOUT.style.height = "auto";
    // htmlOUT.style.height = (window.innerHeight - 400) + "px";
    // htmlOUT.style.width = (window.innerWidth - 50) + "px";
    //redundant
    // wb.SheetNames.forEach(function(sheetName) {
    //     htmlstr = XLSX.utils.sheet_to_html(wb.Sheets[sheetName], {
    //         editable: true
    //     });
    //     HTMLCNT.innerHTML += htmlstr;
    // });

    // if (typeof console !== 'undefined') console.log("output", new Date());

}
function loadExcelResFile(input, dropDiv) {
    //Excel !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    var htmlOUT = document.getElementById(input);
    // console.log(htmlOUT !== undefined && htmlOUT !== null ? "Yes" : "NO !!!");
    // console.log("loadExcelResFile with DIV:" + dropDiv);
    //
    var XLSX = window.nodeRequire('xlsx');
    var electron;
    // var path;
    var xlsxj;
    // var utils = new XLSXUtils(XLSX);
    try {
        // $ = window.nodeRequire('jquery');
        electron = window.nodeRequire('electron').remote;
        // path = window.nodeRequire('path');
        // fs = window.nodeRequire('fs');
    } catch (e) {
        eMsg(e);
    }
    try {
        // convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
        xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
        XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
    } catch (e) {
        eMsg(e);
    }

    //
    var process_wb = (function () {
        return function process_wb(wb, htmlOUT) {
            console.log("process_wb");

            /* get data */
            var ws = wb.Sheets[wb.SheetNames[0]];
            var data = XLSX.utils.sheet_to_json(ws, { header: 1 });

            /* update canvas-datagrid */
            var cDg = canvasDatagrid({ parentNode: htmlOUT, data: data });
            cDg.style.height = '100%';
            cDg.style.width = '100%';
            cDg.data = data;
            // XPORT.disabled = false;

            /* create schema (for A,B,C column headings) */
            var range = XLSX.utils.decode_range(ws['!ref']);
            try {
                for (var i = range.s.c; i <= range.e.c; ++i) {
                    cDg.schema[i - range.s.c].title = XLSX.utils.encode_col(i);
                }
            } catch (e) {
                console.error("WARNING:" + e.stack);
            }

            htmlOUT.style.height = (window.innerHeight - 400) + "px";
            htmlOUT.style.width = (window.innerWidth - 50) + "px";
            //redundant
            // wb.SheetNames.forEach(function(sheetName) {
            //     htmlstr = XLSX.utils.sheet_to_html(wb.Sheets[sheetName], {
            //         editable: true
            //     });
            //     HTMLCNT.innerHTML += htmlstr;
            // });

            if (typeof console !== 'undefined') console.log("output", new Date());
        };
    })();

    var do_file = (function () {
        return function do_file(files, htmlOUT) {
            var f = files[0];
            var reader = new FileReader();
            // console.log("do_file" + f);
            try {
                reader.onload = function (e) {
                    var data = e.target.result;
                    data = new Uint8Array(data);
                    try {
                        // console.log("process do_file" + f);
                        process_wb(XLSX.read(data, {
                            type: 'array'
                        }), htmlOUT);
                    } catch (e) {
                        console.error(e.stack);
                    }

                };
            } catch (e) {
                console.error(e.stack);
            }
            reader.readAsArrayBuffer(f);
        };
    })();

    (function () {
        // console.log("DIV:" + dropDiv + ".");
        var drop = document.getElementById(dropDiv);

        function handleDrop(e) {
            e.stopPropagation();
            e.preventDefault();
            console.log("handleDrop");
            do_file(e.dataTransfer.files, htmlOUT);
        }

        function handleDragover(e) {
            console.log("handleDragover");
            e.stopPropagation();
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        }
        if (drop !== null && drop !== undefined) {
            drop.addEventListener('dragenter', handleDragover, false);
            drop.addEventListener('dragover', handleDragover, false);
            drop.addEventListener('drop', handleDrop, false);
        }
        else {
            // console.log("NO DIV:" + dropDiv + "!!.");
        }
    })();
    // console.log("loadExcelResFile:DIV:" + dropDiv + " done.");

}
// function handleDrop(e) {
//     e.stopPropagation();
//     e.preventDefault();
//     do_file(e.dataTransfer.files, htmlOUT);
// }

// function handleDragover(e) {
//     e.stopPropagation();
//     e.preventDefault();
//     e.dataTransfer.dropEffect = 'copy';
// }
function XLSXUtils(XLSX) {
    // var $ = window.nodeRequire('jquery');
    // var electron = window.nodeRequire('electron').remote;
    // var path = window.nodeRequire('path');
    // var fs = window.nodeRequire('fs');
    // var convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
    // var xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
    // var XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
    // alert('SUX');

    this.prep = function (arr) {
        var out = [];
        for (var i = 0; i < arr.length; ++i) {
            if (!arr[i]) continue;
            if (Array.isArray(arr[i])) { out[i] = arr[i]; continue };
            var o = new Array();
            Object.keys(arr[i]).forEach(function (k) { o[+k] = arr[i][k] });
            out[i] = o;
        }
        return out;
    }



    this.export_all = function () {
        try {

            convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
            xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
            XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
            // path = path !== undefined ? path : window.nodeRequire('path');

            // alert('Debu22g');
            var XTENSION = "xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html".split("|")
            var HTMLCNT = document.getElementById('htmlcnt');
            var electron = window.nodeRequire('electron').remote;
            var OUT_FILE = OUTFILE.val();
            if (!OUT_FILE) return;
            // var wb = XLSX.utils.table_to_book(HTMLCNT);
            if (!cDg) return;
            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
            /* build workbook */
            var new_wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
            var fileName = path.join("resources", "data", OUT_FILE + ".csv");
            XLSX.writeFile(new_wb, fileName, { bookSST: true });
            /* write file and trigger a download */
            for (var ext in XTENSION) {
                var fileName = path.join("resources", "data", OUT_FILE + "." + XTENSION[ext]);
                XLSX.writeFile(new_wb, fileName, { bookSST: true });
                console.log('size:' + HTMLCNT.innerHTML.length + " file:" + fileName);
            }
        } catch (error) {
            console.error(error.stack);
        }
    };
    //transformed
    this.export_csv2xml = function () {
        try {

            convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
            // xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
            XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
            // path = path !== undefined ? path : window.nodeRequire('path');

            // alert('Debu22g');
            var XTENSION = "xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html".split("|")
            var HTMLCNT = document.getElementById('htmlcnt');
            var electron = window.nodeRequire('electron').remote;
            var OUT_FILE = $("#extFileName").val();


            if (!OUT_FILE) return;
            // var wb = XLSX.utils.table_to_book(HTMLCNT);
            if (!cDg) return;
            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
            /* build workbook */
            var new_wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
            var fileName = path.join("resources", "data", OUT_FILE + ".csv");
            XLSX.writeFile(new_wb, fileName, { bookSST: true });
            /* write file and trigger a download */
            csvToXml(fileName, fileName + "-out" + ".xml");

        } catch (error) {
            console.error(error.stack);
        }
    };
    //db
    this.export_db = function () {
        convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
        xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
        XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
        var XTENSION = "csv|CSV".split("|");


        try {

            if (!cDg) return;
            var OUT_FILE = OUTFILE.val();
            if (!OUT_FILE) return;
            var tableId = $('#tableId>option:selected').text();
            tableId = tableId.trim();
            /* convert canvas-datagrid data to worksheet */
            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
            /* build workbook */
            var new_wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
            /* write file and trigger a download */
            var fileName = path.join("resources", "data", OUT_FILE + "." + XTENSION[0]);
            // alert(tableId + " f=" + fileName);
            XLSX.writeFile(new_wb, fileName, { bookSST: true });
            execCMD('exec.bat .\\resources\\cmd\\dbimport.file.bat "' + fileName + '" ' + tableId + '', 'outcnt', true);
            execCMD('exec.bat .\\resources\\cmd\\dbimport.bat "' + fileName + '" ' + tableId + '', 'outcnt', true);
            document.getElementById('outcnt').innerHTML += '<h1>Import done.</h1>';
            return true;
        } catch (ex) {
            eMsg(ex);
        }
    };
    //db
    this.export_ws = function () {
        var XTENSION = "csv|CSV".split("|");
        var tableId = $('#tableId>option:selected').text();
        try {

            if (!cDg) return;
            var OUT_FILE = OUTFILE.val();
            if (!OUT_FILE) return;
            /* convert canvas-datagrid data to worksheet */
            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
            /* build workbook */
            var new_wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
            /* write file and trigger a download */
            var fileName = path.join("resources", "data", OUT_FILE + "." + XTENSION[0]);
            // alert(fileName);
            XLSX.writeFile(new_wb, fileName, { bookSST: true });
            execCMD('exec.bat .\\resources\\cmd\\dbimport.file.bat "' + fileName + '" ' + tableId + '', 'outcnt', true);
            execCMD('exec.bat .\\resources\\cmd\\dbimport.bat "' + fileName + '" ' + tableId + '', 'outcnt', true);
            this.export_postdata(fileName, tableId);
            document.getElementById('outcnt').innerHTML += '<h1>Import done.</h1>';
            return true;
        } catch (ex) {
            eMsg(ex);
        }
    };
    //csv
    this.export_csv = function () {
        var XTENSION = "csv|CSV".split("|");
        // var tableId = $('#tableId>option:selected').text();
        try {

            if (!cDg) return;
            var OUT_FILE = OUTFILE.val();
            if (!OUT_FILE) return;
            /* convert canvas-datagrid data to worksheet */
            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
            /* build workbook */
            var new_wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
            /* write file and trigger a download */
            var fileName = path.join("resources", "data", OUT_FILE + "." + XTENSION[0]);
            // alert(fileName);
            XLSX.writeFile(new_wb, fileName, { bookSST: true });
            document.getElementById('outcnt').innerHTML += '<h1>' + fileName + '</h1><p>Export done.</p>';
            return true;
        } catch (ex) {
            eMsg(ex);
        }
    }
    //xml
    this.export_xml = function () {
        var XTENSION = "xml|XML".split("|");
        var tableId = $('#tableId>option:selected').text();
        try {

            if (!cDg) return;
            var OUT_FILE = OUTFILE.val();
            /* convert canvas-datagrid data to worksheet */
            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
            /* build workbook */
            var new_wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
            /* write file and trigger a download */
            var fileName = path.join("resources", "data", OUT_FILE + "." + XTENSION[0]);
            // alert(fileName);
            XLSX.writeFile(new_wb, fileName, { bookSST: true });
            document.getElementById('outcnt').innerHTML += '<h1>' + fileName + '</h1><p>Export done.</p>';
            return true;
        } catch (ex) {
            eMsg(ex);
        }
    }
    //CSV
    this.export_csv2 = function () {
        var HTMLCNT = document.getElementById('htmlcnt');
        var XTENSION = "csv|CSV|txt|TXT".split("|");
        var electron = window.nodeRequire('electron').remote;
        return function () {
            try {
                var wb = XLSX.utils.table_to_book(HTMLCNT);
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "csv",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o + 'LetzteChance.Org.xlsx', { bookSST: true });
                        XLSX.writeFile(new_wb, o, { bookSST: true });
                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                }
            } catch (e) {
                eMsg(e);
            }
        };

    };
    //XML
    this.export_xml2 = function () {
        var XTENSION = "xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html".split("|")
        var HTMLCNT = document.getElementById('htmlcnt');
        return function () {
            try {
                // var wb = XLSX.utils.table_to_book(HTMLCNT);
                var electron = window.nodeRequire('electron').remote;
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "xml",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o + 'LetzteChance.Org.xlsx', { bookSST: true });
                        XLSX.writeFile(new_wb, o, { bookSST: true });
                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                }
            } catch (e) {
                eMsg(e);
            }
        };
    };
    // alert('TEST');
    //JSON
    this.export_json = function () {
        var HTMLCNT = document.getElementById('htmlcnt');
        var XTENSION = "json|JSON".split("|");
        var electron = window.nodeRequire('electron').remote;
        return function () {
            try {

                var wb = XLSX.utils.table_to_book(HTMLCNT);
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "json",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        var postFix = '-.LetzteChance.Org.xlsx';
                        // var fileName = o + postFix;
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o + postFix, { bookSST: true });
                        // var workbook = XLSX.readFile(o + postFix);
                        var v = {};
                        new_wb.SheetNames.forEach(function (name) {
                            v[name] = XLSX.utils.sheet_to_json(new_wb.Sheets[name]);
                            fs.writeFileSync(o + name + ".json", JSON.stringify(v[name]), 'utf-8');
                        });
                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                }
            } catch (e) {
                eMsg(e);
            }
        };
    };
    // alert('TEST');
    //DB

    // alert('TEST2');
    //DB
    this.export_ws2 = function () {
        var XTENSION = "csv|CSV".split("|");
        var tableName = $('#tableId>option:selected').text();
        var tableId = $('#tableId>option:selected').val();
        try {
            // var wb = XLSX.utils.table_to_book(HTMLCNT);
            var electron = window.nodeRequire('electron').remote;
            var o = electron.dialog.showSaveDialog({
                title: 'Save file as',
                filters: [{
                    name: "csv",
                    extensions: XTENSION
                }]
            });
            eMsg(o);
            if (o) {
                try {
                    if (!cDg) return;
                    if (!o) return;
                    /* convert canvas-datagrid data to worksheet */
                    var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                    /* build workbook */
                    var new_wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                    /* write file and trigger a download */
                    XLSX.writeFile(new_wb, o, { bookSST: true });
                    // new HttpRequest().execCMD('exec.bat .\\resources\\cmd\\wsimport.bat "' + o + '" "' + tableName + '" ' + tableId, 'outcnt', true);
                    // var singleFileUploadInput = document.querySelector('#singleFileUploadInput');
                    // singleFileUploadInput.val = o;
                    // var files = singleFileUploadInput.files;
                    // if (files.length === 0) {
                    //     document.getElementById('outcnt').innerHTML += "Please select a file";
                    // }
                    // uploadSingleFile(files[0]);
                    this.export_postdata(o, tableId);
                    document.getElementById('outcnt').innerHTML += '<h1>Import done.</h1>';
                    return true;

                } catch (e) {
                    eMsg(e);
                }
                electron.dialog.showMessageBox({
                    message: "Exported data to " + o,
                    buttons: ["OK"]
                });
            } else {
                electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                return;
            }
        } catch (e) {
            eMsg(e);
        }
    };

    this.export_postdata = function (o, tableId) {
        const lineReader = window.nodeRequire('line-reader');

        lineReader.eachLine(o, function (line) {
            console.log(line);
            document.getElementById('outcnt').innerHTML += line + '<br>';
            // var ser = $("#insertForm").serialize();
            var ser = {
                value1: tableId,
                subject: line,
                // body: '[url]' + line + '[/url]',
                body: line,
                ebody: line,
            };
            // console.log('POST:'+ser);
            // $('#rsTitle').prop('title', isUpdate ? 'Update:' : 'Post:' + JSON.stringify(ser));
            var url = 'http://localhost/cms/webservices/client.php?q=doInsert';
            $.ajax({
                type: "POST",
                url: url,
                data: ser, // serializes the form's elements.
                contentType: "application/x-www-form-urlencoded; charset=utf-8",
                success: function (data) {
                    $('#outcnt').append(JSON.stringify(data));
                    $('#outcnt').append(url);

                }
            });
        });
        // alert('File:' + o);
        // fs = window.nodeRequire('fs');
        // fs.readFile(o, 'utf8', function(err, data) {
        //     if (err) {
        //         return console.log(err);
        //     }
        //     console.log(data);
        //     var formData = new FormData();
        //     // formData.append('file', data, {
        //     //     filepath: o,
        //     //     contentType: 'text/plain',
        //     // });
        //     formData.append("file", o);

        //     var xhr = new XMLHttpRequest();
        //     xhr.open("POST", "http://localhost:8081/uploadFile");

        //     xhr.onload = function() {
        //         console.log(xhr.responseText);
        //         var response = JSON.parse(xhr.responseText);
        //         if (xhr.status == 200) {
        //             // document.getElementById('outcnt').style.display = "none";
        //             document.getElementById('outcnt').innerHTML += "<p>File Uploaded Successfully.</p><p>DownloadUrl : <a href='" + response.fileDownloadUri + "' target='_blank'>" + response.fileDownloadUri + "</a></p>";
        //             // singleFileUploadSuccess.innerHTML = "<p>File Uploaded Successfully.</p><p>DownloadUrl : <a href='" + response.fileDownloadUri + "' target='_blank'>" + response.fileDownloadUri + "</a></p>";
        //             // document.getElementById('outcnt').style.display = "block";
        //         } else {
        //             // document.getElementById('outcnt').style.display = "none";
        //             document.getElementById('outcnt').innerHTML += (response && response.message) || "Some Error Occurred";
        //             document.getElementById('outcnt').innerHTML += xhr.responseText;
        //         }
        //     }
        //     xhr.send(formData);
        // });

    }

};
function getPluginArguments() {
    var arguments = null;
    try {
        arguments = getSQLQuery('select name from params order by person_id asc, name asc', dbPath);
        // console.log(arguments);
    } catch (e) {
        alert(e.stack);
    }
    return arguments;
}
function transformJSONtoXML(json) {
    var result = "";
    var xml2js = window.nodeRequire('xml2js');
    var builder = new xml2js.Builder();
    var xml = builder.buildObject("" + JSON.stringify(json) + "");
    //
    // var parser =  window.nodeRequire('xml2json');
    // var xml = parser.toXml(json);
    // console.log("xml:" + xml);
    result = xml;
    return result;

}
function getXSLT(res) {
    var result = '<?xml version="1.0" encoding="UTF-8"?><xsl:stylesheet version="1.0"  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">';
    result += '<xsl:variable name="color" select=\'"red"\' />';
    result += '<root><xsl:template match="/"><html><body>';
    result += '<fieldset>';
    result += '<legend>TEST<legend>';
    result += '<h1>TEST<h1>';
    result += res;
    result += '</fieldset>';
    result += '</body></html></xsl:template></root></xsl:stylesheet>';
    return result;

}
function getXSLTTranformation(pluginName, localFileName, xslt) {
    try {
        var xsltString = getXSLT(xslt);
        //transform json
        var json = _readFile(localFileName, { encoding: 'utf8', flag: 'r' });
        var obj = { root: { $: { "id": "json" }, "data": json, _: "my inner text" } };
        var xmlString = transformJSONtoXML(obj);
        //eof transform json
        console.log("XML:\n" + xmlString + "\nXSLT:\n" + xsltString + "\nID:\n" + pluginName);
        var xmlout = getXsltProcess(xmlString, xsltString);
        $('#' + pluginName + '').html(xmlout);
        console.log("OUT:\n" + xmlout);
    } catch (error) {
        eMsg(error);
    }

}
//
function printListOptionsDrives(files, id) {
    var result = "";
    var max = files.length;
    var i = 0;
    result += "<select id=\"" + id + "\">";
    for (var v in files) {
        if (i < max - 1) {
            var f = files[v] + "";
            result += "<option value=\"javascript:printDirectory('" + f + "\', 'installfilescnt')\" class=\"btn-default\">" + f + "</option>";
        }
        i++;
    }
    result += "</select>";
    result += "<button onclick=\"eval(document.getElementById('menudrives').value)\" class=\"btn btn-default\">Show</button>";
    return result;
}

function get_DirectoryFiles(dir) {
    const fs = window.nodeRequire('fs');
    const directoryPath = dir;
    // Use fs.readdirSync to read the contents of the directory synchronously
    const fileList = fs.readdirSync(directoryPath);
    console.log('Files and folders in the directory:', fileList);
    return fileList;
}
function is_Directory(dir) {
    const fs = window.nodeRequire('node:fs');
    const isFile = fileName => {
        return fs.lstatSync(fileName).isFile();
    };
    fs.readdirSync(folderPath)
        .map(fileName => {
            return path.join(folderPath, fileName);
        })
        .filter(isFile);
}
function makeDirectory(dir) {
    const fs = window.nodeRequire('node:fs');
    const folderName = dir;
    try {
        if (!fs.existsSync(folderName)) {
            fs.mkdirSync(folderName);
        }
    } catch (err) {
        console.error(err);
    }

}

function getListDrives() {
    var spawn = window.nodeRequire("child_process").spawn;
    const list = spawn('cmd');
    // console.log("getListDrives");
    return new Promise((resolve, reject) => {
        list.stdout.on('data', function (data) {
            // console.log('stdout: ' + String(data));
            const output = String(data)
            const out = output.split("\r\n").map(e => e.trim()).filter(e => e != "")
            if (out[0] === "Name") {
                // console.log("OUT:" + out.slice(1));
                resolve(out.slice(1))
            }
        });
        list.stderr.on('data', function (data) {
            console.error('stderr: ' + data);
        });
        list.on('exit', function (code) {
            console.log('child process exited with code ' + code);
            if (code !== 0) {
                reject(code)
            }
        });
        list.stdin.write('wmic logicaldisk get name\n');
        list.stdin.end();
    })
}
//'#files > input[type="file"]'
function getToBase(selector, id) {
    file = document.querySelector(selector).files[0]
    getFile(file).then((customJsonFile) => {
        console.log(customJsonFile);
        $(id).html(JSON.stringify(customJsonFile));
    });
}
function getFiles(files) {
    return Promise.all(files.map(getFile));
}
function getFile(file) {
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
        reader.onerror = () => { reader.abort(); reject(new Error("Error parsing file")); }
        reader.onload = function () {
            //This will result in an array that will be recognized by C#.NET WebApi as a byte[]
            let bytes = Array.from(new Uint8Array(this.result));
            //if you want the base64encoded file you would use the below line:
            let base64StringFile = btoa(bytes.map((item) => String.fromCharCode(item)).join(""));
            //Resolve the promise with your custom file structure
            resolve({
                bytes,
                base64StringFile,
                fileName: file.name,
                fileType: file.type
            });
        }
        reader.readAsArrayBuffer(file);
    });
}
function getBase64ToFile(file) {
    return atob(file);
}
//
async function printDrives(id) {
    // const drivelist = window.nodeRequire('electron-drivelist');
    const drivelist = window.nodeRequire('drivelist');
    const drives = await drivelist.list();
    console.log(drives);
}
function printDir(dir_path, id) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function (err, files) {
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        files.forEach(function (file) {
            try {
                var isValid = false;
                // console.log('File:' + file);
                var obj = document.getElementById(id);
                if (obj !== null && obj !== undefined) {
                    //obj.innerHTML += "<br>" + file;
                    obj.innerHTML += "<br>" + file;
                }
                // for (v in corelibs) {
                //     if (file.includes(v)) {
                //         isValid = true;
                //     }
                // }
                // if (isValid) {
                //     document.getElementById(id).innerHTML += "<br>" + file + " <strong>found</strong>.";
                // }
            } catch (error) {
                console.error(error);
            }

        });
    });
}
function printDirectory(p, id, isAppend, isScrolling) {
    var result = "<fieldset class=\"\">";
    const fs = window.nodeRequire('fs');
    const path = window.nodeRequire('path');
    const filenames = fs.readdirSync(p);
    var cwd = path.resolve(p);
    var pcwd = path.resolve(path.join(p, '..')).replaceAll('\\', '\\\\');
    result += "<legend><a onclick=\"printDirectory('" + pcwd + "','" + id + "')\" class=\"\">" + cwd + "</a></legend>";
    result += "<div id=\"fileout\"></div>";
    result += "<ul class=\"listul\">";

    result += "<li class=\"btn\">";
    result += "<br><a onclick=\"printDirectory('" + pcwd + "','" + id + "')\" class=\"\">..<strong>(directory)</strong></a>";
    result += "</li>";
    filenames.map((filename) => {
        // console.log(filename);
        try {
            if (fs.lstatSync(path.join(p, filename)).isDirectory()) {
                // console.log('Directory: ' + path.join(p, filename));
                var f = path.join(p, filename).replaceAll('\\', '\\\\');
                result += "<li class=\"btn\">";
                result += "<br><a onclick=\"printDirectory('" + f + "','" + id + "')\" class=\"\">" + filename.replaceAll(extractFilePath(filename),'') + "&nbsp;<strong>(directory)</strong></a>";
                result += "</li>";
            }
        } catch (error) {
            console.warn(error);
        }

    })
    filenames.map((filename) => {
        // console.log(filename);
        try {
            if (!fs.lstatSync(path.join(cwd, filename)).isDirectory()) {
                result += "<li class=\"btn\">";
                result += getFileLink(cwd, filename, id, false);
                result += "</li>";
            }
        } catch (error) {
            console.error(error);
        }
    })
    result += "</ul>";
    result += "</fieldset>";
    if (isAppend) {
        $('#' + id).append(result);
    }
    else {
        $('#' + id).html(result);
    }
    //TODO
    if (isScrolling !== undefined && isScrolling == true) {
        $("html, body").delay(1000).animate({
            scrollTop: $('#' + id).offset().top - 100
        }, 3000);
    }
}
function getFileExtension(filename) {
    const extension = filename.split('.').pop();
    return extension;
}
function getFileNameOnly(filename) {
    const extension = filename.split('\\').pop();
    return extension;
}
function getFileLink(p, file, id, isDialogOpened) {
    var result = "";
    // const path = window.nodeRequire('path');
    var fileName = path.join(p, file).replaceAll('\\', '\\\\');
    // console.log('getFileLink:' + fileName);
    isDialogOpened = isDialogOpened == false ? false : true;
    showGetFileContent('#fileout', '"' + fileName + '"', isDialogOpened);
    var fileSize = getFileSize(path.join(p, file));
    var fileExt = getFileExtension(file);
    switch (fileExt) {
        case 'exe':
            result = "<a onclick=\"showGetFileContent('#fileout','" + fileName + "');\" class=\"btn\">" + fileName.replaceAll(extractFilePath(fileName),'') + "</a><p>MB:"+fileSize+"</p>";
            break;
        case 'bat':
            result = "<a onclick=\"showGetFileContent('#fileout','" + fileName + "');\" class=\"btn\">" + fileName.replaceAll(extractFilePath(fileName),'') + "</a><p>MB:"+fileSize+"</p>";
            break;
        default:
            result = "<a onclick=\"showGetFileContent('#fileout','" + fileName + "');\" class=\"btn\">" + fileName.replaceAll(extractFilePath(fileName),'') + "</a><p>MB:"+fileSize+"</p>";
            break;
    }
    return result;

}
function getFileSize(filePath) {
    var fs = window.nodeRequire("fs");
    try {
        const stats = fs.statSync(filePath);
        return stats.size/ (1024 * 1024); // size in bytes
    } catch (err) {
        console.error('Error reading file size:', err);
        return -1;
    }
}
// function getFileSize(file) {
//     var fs = window.nodeRequire("fs"); // Load the filesystem module
//     var stats = fs.statSync(file)
//     var fileSizeInBytes = stats.size;
//     // Convert the file size to megabytes (optional)
//     return fileSizeInBytes / (1024 * 1024);
// };
async function isPortOpen(port) {
    return new Promise((resolve, reject) => {
        var net = window.nodeRequire('net');
        let s = net.createServer();
        s.once('error', (err) => {
            s.close();
            if (err["code"] == "EADDRINUSE") {
                resolve(false);
            } else {
                resolve(false);
            }
        });
        s.once('listening', () => {
            resolve(true);
            s.close();
        });
        s.listen(port);
    });
};

function createZipFromFile(file, savedData) {
    var zip = new JSZip();
    var img = zip.folder(".");
    // var path = require('path');
    var filename = path.basename(file);
    console.log(file);
    zip.file(file, savedData);
    zip.file(file + ".json", JSON.stringify(savedData));
    zip.file("article.html", "Welcome to LetzteChance.Org\n\nTitle:" + file + "\n\n");
    zip.file(file + ".url", "url:file:////" + file);
    zip.file("lc.url", "[InternetShortcut]\nURL=https://www.letztechance.org\nHotKey=\nIconFile=\nIconIndex=\nShowCommand=\nModified=\nRoamed=\nIDList=\nAuthor=David Honisch\nWhatsNew=https://www.letztechance.org\nComment=https://www.letztechance.org\nDesc=https://www.letztechance.org\n");
    //var img = zip.folder("data");
    var img = zip.folder("letztechance.org");
    var img = zip.folder("von David Honisch");
    var img = zip.folder("img");
    imgData = "R0lGODdhBQAFAIACAAAAAP/eACwAAAAABQAFAAACCIwPkWerClIBADs=";
    img.file("smile.gif", imgData, { base64: true });
    var content = zip.generate({ type: "blob" });
    // see FileSaver.js
    saveAs(content, file + "-saved.zip");
}

function _fileExtEditor(file, fileExt) {
    $("#extFileName").val(file);
    const { webUtils } = window.nodeRequire('electron');
    // const file = files[0];
    console.log("file:" + file);
    const cnt = _readFile(file);    // Within browser code
    var fileSize = getFileSize(file);
    //outFile.val((fileFullPath).replace("\\", "\\\\") + files[0].name);
    const cnts = cnt.split("\n");
    var blocks = [{
        "type": "header",
        "data": {
            "text": "LetzteChance.Org",
            "level": 3
        },
    },
    {
        type: 'delimiter',
        data: {}
    }
        // {
        //     type: 'paragraph',
        //     data: {
        //         text: cnt
        //     }
        // }
    ];
    for (var v in cnts) {

        var p = {
            type: 'paragraph',
            data: {
                text: cnts[v]
            }
        };
        blocks.push(p);
    }
    var data = {
        "blocks": blocks
    }

    $("#jsFileName" + fileExt + "").val("" + file);
    $("#editor" + fileExt + "").html("" + cnt);
    //  $("#editor" + fileExt + "CNT").html("<h1>OUT:<h1>" + cnt);    
    const editor = new EditorJS({
        /** 
         * Id of Element that should contain the Editor 
         */
        holder: 'editorext',
        /** 
         * Available Tools list. 
         * Pass Tool's class or Settings object for each Tool you want to use 
         */
        // tools: { 
        //   header: {
        //     class: Header, 
        //     inlineToolbar: ['link'] 
        //   }, 
        //   list: { 
        //     class: List, 
        //     inlineToolbar: true 
        //   } 
        // }, 
        data: {
            blocks: blocks

            // {
            //     type: 'image',
            //     data: {
            //         url: 'assets/codex2x.png',
            //         caption: '',
            //         stretched: false,
            //         withBorder: true,
            //         withBackground: false,
            //     }
            // },
            // ]
        },
        onReady: function () {
            // saveButton.click();
        },
        onChange: function (api, event) {
            console.log('something changed', event);
        }
    });
    const saveButton = document.getElementById('extsaveButton');
    /**
     * Toggle read-only button
     */
    const toggleReadOnlyButton = document.getElementById('toggleReadOnlyButton');
    const readOnlyIndicator = document.getElementById('readonly-state');
    /**
     * Saving example
     */
    saveButton.addEventListener('click', function () {
        editor.save()
            .then((savedData) => {
                //
                createZipFromFile(file, savedData);
                //
                cPreview.show(savedData, document.getElementById("editorjsCNT"));
            })
            .catch((error) => {
                console.error('Saving error', error);
            });
    });

    /**
     * Toggle read-only example
     */
    toggleReadOnlyButton.addEventListener('click', async () => {
        const readOnlyState = await editor.readOnly.toggle();
        readOnlyIndicator.textContent = readOnlyState ? 'On' : 'Off';
    });

}
//
function deprecated_exec_File(file, id) {
    var result = "";
    var fileExt = getFileExtension(file);
    var fileName = file.substring(file.lastIndexOf('\\') + 1);
    var onlyPath = window.nodeRequire('path').dirname(file);
    var out = $('#' + id);
    out.html('Loading ' + file + ' id:' + id + ' Path:' + onlyPath);
    console.log('Loading ' + file + " Ext:" + fileExt + ' id:' + id + ' Path:' + onlyPath);
    switch (fileExt) {
        case 'exe':
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            break;
        case 'bat':
            // result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            // out.append('<hr>' + result);
            // //doFile(file, id);

            // if (getConfirmation('Start ' + onlyPath + file + ' now?')) {
            //     execCMD('call "' + file + '"', id);
            // } else {
            //     execCMD('call "' + file + '"', id);
            // };
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            break;
        case 'xml':
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            break;
        case 'java':
            result = "<a onclick=\"showGetFileContent('#fileout','" + file + "');\" class=\"btn\">" + file + "</a>";
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            onlyPath = window.nodeRequire('path').dirname(file);
            out.append('java ' + fileName + ' Path:' + onlyPath);
            console.log('class ' + file + ' id:' + id + ' Path:' + onlyPath);
            execCMD('javac -d "' + onlyPath + '" "' + file + '"|java ' + fileName.replaceAll('.java', ''), id);
            // execCMD('cd "'+onlyPath+'"|java ' + fileName.replace('.java',''), id,true);
            break;
        case 'class':
            result = "<a onclick=\"showGetFileContent('#fileout','" + file + "');\" class=\"btn\">" + file + "</a>";
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            // onlyPath = window.nodeRequire('path').dirname(file);
            out.append('class ' + fileName + ' Path:' + onlyPath);
            console.log('class ' + file + ' id:' + id + ' Path:' + onlyPath);
            console.log('java ' + (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'));
            execCMD('cd "' + onlyPath, id);
            execCMD('set CLASSPATH=%CLASSPATH%;' + onlyPath + ';.', id);
            execCMD('java ' + (onlyPath + '\\').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'), id);
            break;
        case 'maven':
            // var result = printFileURL(out, file, onlyPath, fileName, id);
            // out.append('<hr>' + result);
            // // onlyPath = window.nodeRequire('path').dirname(file);
            // out.append('class ' + fileName + ' Path:' + onlyPath);
            // console.log('class ' + file + ' id:' + id + ' Path:' + onlyPath);
            // console.log('java ' + (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'));
            // //execCMD('java ' + (onlyPath + '\\').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'), id);
            // execCMD('mvn  -f "' + file + '" install', id);
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });

            break;
        //excel csv and so on
        case 'csv':
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            break;
        case 'js':
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            console.log("file:" + JSON.stringify(file));
            console.log("file:" + file);
            new extJS(file);
            break;
        case 'json':
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            break;
        case 'xlsx':
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            if (getConfirmation('Start ' + onlyPath + file + 'fname:' + fname + ' now?')) {
                getOpenDialog('#dialog', '.\\assets\\html\\ext\\' + fileExt + '\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            };
            break;
        default:
            printFileURL(out, file, onlyPath, fileName, id);
            var fname = (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.');
            console.log(fileExt + ' file:' + fname + " Path:" + onlyPath + " File:" + file);
            getOpenDialog('#dialog', '.\\assets\\html\\ext\\default\\index.html', fileExt + ' Editor', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 480, height: 300 });
            break;
    }

    function printFileURL(out, file, onlyPath, fileName, id) {
        out.append('csv ' + fileName + ' Path:' + onlyPath);
        console.log('csv ' + file + ' id:' + id + ' Path:' + onlyPath);
    }
}
// Example usage
//const csvFilePath = './input.csv'; // Replace with your CSV file path
//const xmlFilePath = './output.xml'; // Replace with your desired XML file path
//csvToXml(csvFilePath, xmlFilePath);
function showCsvToXml(csvFilePath, id) {
    var out = csvToXml(csvFilePath);
    $(id).html(out);
}
function csvToXml(csvFilePath) {
    const fs = window.nodeRequire('fs');
    const csv = window.nodeRequire('csv-parser');
    // const { parse } = window.nodeRequire("csv-parse");
    const { create } = window.nodeRequire('xmlbuilder2');
    const rows = [];

    // Read the CSV file
    return fs.createReadStream(csvFilePath)
        .pipe(csv({ separator: '\t', from_line: 2 }))
        // .pipe(parse({ delimiter: ",", from_line: 2 }))
        .on('data', (row) => {
            rows.push(row);
        })
        .on('end', () => {
            // Create the XML structure
            const root = create({ version: '1.0' })
                .ele('root');

            rows.forEach((row) => {
                const item = root.ele('item');
                Object.keys(row).forEach((key) => {
                    var k = key.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, '_').trim();
                    item.ele(key).txt(row[k]);
                });
            });
            const xml = root.end({ prettyPrint: true });
            // Write the XML to a file
            // fs.writeFileSync(xmlFilePath, xml, 'utf-8');
            // console.log(`XML file has been created at: ${xmlFilePath}`);
            return xml;
        })
        .on('error', (err) => {
            console.error('Error reading the CSV file:', err);
        });

}
function writeCsvToXml(csvFilePath, xmlFilePath) {
    const fs = window.nodeRequire('fs');
    var xml = CsvToXml(csvFilePath, xmlFilePath);
    fs.writeFileSync(xmlFilePath, xml, 'utf-8');
    console.log(`XML file has been created at: ${xmlFilePath}`);
}
function getXMLResponseObject(jsonFilePath, xmlFilePath) {
    SaxonJS.transform({
        stylesheetFileName: jsonFilePath,
        sourceFileName: xmlFilePath,
        destination: "serialized"
    }, "async")
        .then(output => {
            response.writeHead(200, { 'Content-Type': 'text/html' });
            response.write(output.principalResult);
            response.end();
        })
    console.log(`XML file has been created at: ${xmlFilePath}`);
}
function extractFilePath(filePath) {
    // Use the lastIndexOf method to find the last occurrence of the path separator
    const lastSeparatorIndex = filePath.lastIndexOf('\\'); // For Windows paths
    if (lastSeparatorIndex === -1) {
        return ''; // Return an empty string if no path separator is found
    }
    // Extract and return the path portion
    return filePath.substring(0, lastSeparatorIndex);
}
function addCarouselNavigationHandler() {
    $('.cnav > button').on("click", function () {
        console.log("clicked.")
        var b = $(e.target).addClass('down')
        setTimeout(function () {
            b.removeClass('down')
        }, 80);
    })
    $(document).on("keydown", function (e) {
        console.log(JSON.stringify(e));
        switch (e.keyCode) {
            /* left arrow */
            case 37:
                $('.cnav > .left').trigger("click");
                break

            /* right arrow */
            case 39:
                $('.cnav > .right').trigger("click");
        }
    })
}