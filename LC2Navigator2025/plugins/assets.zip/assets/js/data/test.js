// Code goes here

var app = angular.module('app', ['ui.bootstrap']);

function MyController($scope, $http, $filter) {
    // default values for pagination and filtering
    $scope.pageSize = 5;
    $scope.maxSize = 5;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    $scope.data = null;
    $scope.query = { browser: "" };

    // get the data
    $http.get('assets/js/data/data.json')
        .success(function(data) {
            // set the data
            $scope.data = data.aaData;
        });

    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function(data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function() {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });

    // set the pagination for the filtered items
    function setPage() {
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 1);
    }

    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function(page) {
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function(items, old) {
        $scope.currentPage = 1;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function(items) {
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 1) * $scope.pageSize + $scope.pagedItems.length;
    });
}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function(e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function() {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function() {
    return function(input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});