console.log('LC2CONTAINER:\n');
class LC2CONTAINER {
    static run(o, NODEAPI, run) {
        NODEAPI.getContainerInstances(o,8085,3306, run);
        console.log(this.name + " done.\n");
    }
    static test() {
        console.log(this.name + ' test successfull.');
    }

}
module.exports = LC2CONTAINER;