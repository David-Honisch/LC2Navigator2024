SELECT '<h1>lc2mongodb PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
select count(*) as count from application; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE lc2mongodb SQL SCRIPT DONE</h1>'; 
--INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('lc2mongodb Plugin v.1.02a','lc2mongodb Plugin v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\lc2mongodb\\index.bat .\\resources\\plugins\\lc2mongodb\\menu.csv'', ''out'');');
INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('lc2mongodb Plugin v.1.2','lc2mongodb Plugin v.1.01a','','','','','execPluginCMD(''out'',''lc2mongodb'');');

select count(*) as count from application; 
SELECT '<h5>SQL lc2mongodb IMPORT DONE</h5>'; 
