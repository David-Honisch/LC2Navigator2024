SELECT '<h1>apache-ant PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
select count(*) as count from application; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE apache-ant SQL SCRIPT DONE</h1>'; 
--INSERT OR REPLACE INTO application( name, first_name, description, zipcode, city, street, url)VALUES('apache-ant Plugin v.1.01a','apache-ant Plugin v.1.01a','','','','','exec .\\resources\\plugins\\apache-ant\\index.bat .\\resources\\plugins\\apache-ant\\menu.csv'); 
-- INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('apache-ant Plugin v.1.02a','apache-ant Plugin v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\apache-ant\\index.bat .\\resources\\plugins\\apache-ant\\menu.csv'', ''out'');');
INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('apache-ant Plugin v.1.2','apache-ant Plugin v.1.01a','','','','','execPluginCMD(''out'',''apache-ant'');');

select count(*) as count from application; 
SELECT '<h5>SQL apache-ant IMPORT DONE</h5>'; 
