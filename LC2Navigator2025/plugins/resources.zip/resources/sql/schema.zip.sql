SELECT '<h1>SQL schema SCRIPT IS RUNNING</h1>';
SELECT '<h5>Init import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Clear','Clear','echo .');
SELECT '<h4>INSERT schema to applications</h4>';
-- INSERT OR REPLACE INTO application (first_name,name,url) 
-- values ('schema','start .\\resources\\app\\sqlite\\schema.exe','start .\\resources\\app\\sqlite\\schema.exe');
-- 
-- INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('schemawin Plugin v.1.12a','schemawin Plugin v.1.2b','','','','','execCMD(''exec .\\resources\\plugins\\schemawin\\index.bat .\\resources\\plugins\\schemawin\\csv\\default.csv'', ''out'');');
INSERT OR REPLACE INTO importscripts(name, first_name, description, zipcode, city, street, url)VALUES('schema Plugin v.1.2','schema Plugin v.1.01a','','','','','execPluginCMD(''out'',''schema'');');  
-- INSERT OR REPLACE INTO plugins VALUES('All Plugins Downloader v.1.1 Final (install requirements)','all.zip all.zip Download',NULL,NULL,NULL,NULL,'exec .\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip all.zip all.zip');

-- 
SELECT '<h5>INSERT PLUGINS DONE v.0.001</h5>';
SELECT '<h4>'||(SELECT COUNT(*) FROM application)||' plugin added...</h4>';
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';