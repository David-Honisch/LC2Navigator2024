select '<hr/><h2>Import lc2sqlite processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2sqlite;
drop table IF EXISTS lc2sqlite_main;
drop table IF EXISTS lc2sqlite_install;
drop table IF EXISTS lc2sqlite_help;
drop table IF EXISTS lc2sqlite_data;
drop table IF EXISTS lc2sqlite_info;
drop table IF EXISTS lc2sqlite_work;
drop table IF EXISTS lc2sqlite_procdata;
drop table IF EXISTS lc2sqlitetemp;
drop table IF EXISTS lc2sqlite_datatemp;
drop table IF EXISTS lc2sqlite_worktemp;
drop table IF EXISTS lc2sqlite_proc;
drop table IF EXISTS lc2sqlite_tests;
drop table IF EXISTS lc2sqlite_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2sqlite( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2sqlite_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlite_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlite_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlite_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlite_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlite_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2sqlite_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlite_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2sqlite_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlite_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2sqlitetemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2sqlite_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2sqlite\\import\\import.csv lc2sqlitetemp
-- INSERT INTO lc2sqlite(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlitetemp;
.import .\\resources\\plugins\\lc2sqlite\\import\\import.csv lc2sqlite
.import .\\resources\\plugins\\lc2sqlite\\import\\main.csv lc2sqlite_main
.import .\\resources\\plugins\\lc2sqlite\\import\\install.csv lc2sqlite_install
.import .\\resources\\plugins\\lc2sqlite\\import\\help.csv lc2sqlite_help
.import .\\resources\\plugins\\lc2sqlite\\import\\info.csv lc2sqlite_info
.import .\\resources\\plugins\\lc2sqlite\\import\\data.csv lc2sqlite_data
.import .\\resources\\plugins\\lc2sqlite\\import\\work.csv lc2sqlite_work
.import .\\resources\\plugins\\lc2sqlite\\import\\proc.csv lc2sqlite_proc
.import .\\resources\\plugins\\lc2sqlite\\import\\tests.csv lc2sqlite_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2sqlite\\import\\proc.csv' lc2sqlite_proctemp
-- .separator ";"
-- INSERT INTO lc2sqlite_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2sqlite_proctemp;
-- select 'lc2sqlite_work count:';
-- select count(*) from lc2sqlite_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2sqlite count:';
select count(*) from lc2sqlite;
select '<p>start data import to plugin tables</p>';
-- delete from lc2sqlite_datatemp;
--
select '<p>lc2sqlite count:';
select count(*) from lc2sqlite;
select 'lc2sqlite_data count:';
select count(*) from lc2sqlite_data;
select 'lc2sqlite_info count:';
select count(*) from lc2sqlite_info;
select 'lc2sqlite_help count:';
select count(*) from lc2sqlite_help;
select 'lc2sqlite_procdata count:';
select count(*) from lc2sqlite_procdata;
select 'lc2sqlite_work count:';
select count(*) from lc2sqlite_work;
select 'lc2sqlite_proc count:';
select count(*) from lc2sqlite_proc;
select 'lc2sqlite_proctemp count:';
select count(*) from lc2sqlite_proctemp;

drop table IF EXISTS lc2sqlitetemp;
-- drop table IF EXISTS lc2sqlite_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2sqlite processes done.</h4>';
.exit