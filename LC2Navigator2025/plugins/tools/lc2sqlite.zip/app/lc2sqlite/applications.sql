--DROP TABLE "application";
CREATE TABLE IF NOT EXISTS "application" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"command" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"email" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,	
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);
--INSERT INTO application ('person_id','name','command','url') VALUES (1,'Menu v.1.0','test.bat echo test','test.bat');
INSERT INTO application ('name','command','url') VALUES ('Menu v.1.0','test.bat echo test','test.bat');