select '<hr/><h2>Import LC2Authme processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2Authme;
drop table IF EXISTS LC2Authme_main;
drop table IF EXISTS LC2Authme_install;
drop table IF EXISTS LC2Authme_help;
drop table IF EXISTS LC2Authme_data;
drop table IF EXISTS LC2Authme_info;
drop table IF EXISTS LC2Authme_work;
drop table IF EXISTS LC2Authme_procdata;
drop table IF EXISTS LC2Authmetemp;
drop table IF EXISTS LC2Authme_datatemp;
drop table IF EXISTS LC2Authme_worktemp;
drop table IF EXISTS LC2Authme_proc;
drop table IF EXISTS LC2Authme_tests;
drop table IF EXISTS LC2Authme_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2Authme( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2Authme_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Authme_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Authme_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Authme_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Authme_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Authme_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE LC2Authme_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Authme_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2Authme_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Authme_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2Authmetemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2Authme_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2Authme\\import\\import.csv LC2Authmetemp
-- INSERT INTO LC2Authme(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Authmetemp;
.import .\\resources\\plugins\\LC2Authme\\import\\import.csv LC2Authme
.import .\\resources\\plugins\\LC2Authme\\import\\main.csv LC2Authme_main
.import .\\resources\\plugins\\LC2Authme\\import\\install.csv LC2Authme_install
.import .\\resources\\plugins\\LC2Authme\\import\\help.csv LC2Authme_help
.import .\\resources\\plugins\\LC2Authme\\import\\info.csv LC2Authme_info
.import .\\resources\\plugins\\LC2Authme\\import\\data.csv LC2Authme_data
.import .\\resources\\plugins\\LC2Authme\\import\\work.csv LC2Authme_work
.import .\\resources\\plugins\\LC2Authme\\import\\proc.csv LC2Authme_proc
.import .\\resources\\plugins\\LC2Authme\\import\\tests.csv LC2Authme_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2Authme\\import\\proc.csv' LC2Authme_proctemp
-- .separator ";"
-- INSERT INTO LC2Authme_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2Authme_proctemp;
-- select 'LC2Authme_work count:';
-- select count(*) from LC2Authme_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2Authme count:';
select count(*) from LC2Authme;
select '<p>start data import to plugin tables</p>';
-- delete from LC2Authme_datatemp;
--
select '<p>LC2Authme count:';
select count(*) from LC2Authme;
select 'LC2Authme_data count:';
select count(*) from LC2Authme_data;
select 'LC2Authme_info count:';
select count(*) from LC2Authme_info;
select 'LC2Authme_help count:';
select count(*) from LC2Authme_help;
select 'LC2Authme_procdata count:';
select count(*) from LC2Authme_procdata;
select 'LC2Authme_work count:';
select count(*) from LC2Authme_work;
select 'LC2Authme_proc count:';
select count(*) from LC2Authme_proc;
select 'LC2Authme_proctemp count:';
select count(*) from LC2Authme_proctemp;

drop table IF EXISTS LC2Authmetemp;
-- drop table IF EXISTS LC2Authme_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2Authme processes done.</h4>';
.exit