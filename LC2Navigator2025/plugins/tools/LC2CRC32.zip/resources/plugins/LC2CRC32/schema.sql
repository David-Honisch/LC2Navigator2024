select '<hr/><h2>Import LC2CRC32 processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2CRC32;
drop table IF EXISTS LC2CRC32_main;
drop table IF EXISTS LC2CRC32_install;
drop table IF EXISTS LC2CRC32_help;
drop table IF EXISTS LC2CRC32_data;
drop table IF EXISTS LC2CRC32_info;
drop table IF EXISTS LC2CRC32_work;
drop table IF EXISTS LC2CRC32_procdata;
drop table IF EXISTS LC2CRC32temp;
drop table IF EXISTS LC2CRC32_datatemp;
drop table IF EXISTS LC2CRC32_worktemp;
drop table IF EXISTS LC2CRC32_proc;
drop table IF EXISTS LC2CRC32_tests;
drop table IF EXISTS LC2CRC32_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2CRC32( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2CRC32_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE LC2CRC32_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2CRC32_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2CRC32temp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2CRC32_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2CRC32\\import\\import.csv LC2CRC32temp
-- INSERT INTO LC2CRC32(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2CRC32temp;
.import .\\resources\\plugins\\LC2CRC32\\import\\import.csv LC2CRC32
.import .\\resources\\plugins\\LC2CRC32\\import\\main.csv LC2CRC32_main
.import .\\resources\\plugins\\LC2CRC32\\import\\install.csv LC2CRC32_install
.import .\\resources\\plugins\\LC2CRC32\\import\\help.csv LC2CRC32_help
.import .\\resources\\plugins\\LC2CRC32\\import\\info.csv LC2CRC32_info
.import .\\resources\\plugins\\LC2CRC32\\import\\data.csv LC2CRC32_data
.import .\\resources\\plugins\\LC2CRC32\\import\\work.csv LC2CRC32_work
.import .\\resources\\plugins\\LC2CRC32\\import\\proc.csv LC2CRC32_proc
.import .\\resources\\plugins\\LC2CRC32\\import\\tests.csv LC2CRC32_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2CRC32\\import\\proc.csv' LC2CRC32_proctemp
-- .separator ";"
-- INSERT INTO LC2CRC32_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2CRC32_proctemp;
-- select 'LC2CRC32_work count:';
-- select count(*) from LC2CRC32_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2CRC32 count:';
select count(*) from LC2CRC32;
select '<p>start data import to plugin tables</p>';
-- delete from LC2CRC32_datatemp;
--
select '<p>LC2CRC32 count:';
select count(*) from LC2CRC32;
select 'LC2CRC32_data count:';
select count(*) from LC2CRC32_data;
select 'LC2CRC32_info count:';
select count(*) from LC2CRC32_info;
select 'LC2CRC32_help count:';
select count(*) from LC2CRC32_help;
select 'LC2CRC32_procdata count:';
select count(*) from LC2CRC32_procdata;
select 'LC2CRC32_work count:';
select count(*) from LC2CRC32_work;
select 'LC2CRC32_proc count:';
select count(*) from LC2CRC32_proc;
select 'LC2CRC32_proctemp count:';
select count(*) from LC2CRC32_proctemp;

drop table IF EXISTS LC2CRC32temp;
-- drop table IF EXISTS LC2CRC32_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2CRC32 processes done.</h4>';
.exit