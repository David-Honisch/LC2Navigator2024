select '<hr/><h2>Import lc2crud processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2crud;
drop table IF EXISTS lc2crud_main;
drop table IF EXISTS lc2crud_install;
drop table IF EXISTS lc2crud_help;
drop table IF EXISTS lc2crud_data;
drop table IF EXISTS lc2crud_info;
drop table IF EXISTS lc2crud_work;
drop table IF EXISTS lc2crud_procdata;
drop table IF EXISTS lc2crudtemp;
drop table IF EXISTS lc2crud_datatemp;
drop table IF EXISTS lc2crud_worktemp;
drop table IF EXISTS lc2crud_proc;
drop table IF EXISTS lc2crud_tests;
drop table IF EXISTS lc2crud_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2crud( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2crud_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2crud_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2crud_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2crud_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2crud_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2crud_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2crud_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2crud_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2crud_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2crud_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2crudtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2crud_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2crud\\import\\import.csv lc2crudtemp
-- INSERT INTO lc2crud(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2crudtemp;
.import .\\resources\\plugins\\lc2crud\\import\\import.csv lc2crud
.import .\\resources\\plugins\\lc2crud\\import\\main.csv lc2crud_main
.import .\\resources\\plugins\\lc2crud\\import\\install.csv lc2crud_install
.import .\\resources\\plugins\\lc2crud\\import\\help.csv lc2crud_help
.import .\\resources\\plugins\\lc2crud\\import\\info.csv lc2crud_info
.import .\\resources\\plugins\\lc2crud\\import\\data.csv lc2crud_data
.import .\\resources\\plugins\\lc2crud\\import\\work.csv lc2crud_work
.import .\\resources\\plugins\\lc2crud\\import\\proc.csv lc2crud_proc
.import .\\resources\\plugins\\lc2crud\\import\\tests.csv lc2crud_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2crud\\import\\proc.csv' lc2crud_proctemp
-- .separator ";"
-- INSERT INTO lc2crud_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2crud_proctemp;
-- select 'lc2crud_work count:';
-- select count(*) from lc2crud_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2crud count:';
select count(*) from lc2crud;
select '<p>start data import to plugin tables</p>';
-- delete from lc2crud_datatemp;
--
select '<p>lc2crud count:';
select count(*) from lc2crud;
select 'lc2crud_data count:';
select count(*) from lc2crud_data;
select 'lc2crud_info count:';
select count(*) from lc2crud_info;
select 'lc2crud_help count:';
select count(*) from lc2crud_help;
select 'lc2crud_procdata count:';
select count(*) from lc2crud_procdata;
select 'lc2crud_work count:';
select count(*) from lc2crud_work;
select 'lc2crud_proc count:';
select count(*) from lc2crud_proc;
select 'lc2crud_proctemp count:';
select count(*) from lc2crud_proctemp;

drop table IF EXISTS lc2crudtemp;
-- drop table IF EXISTS lc2crud_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2crud processes done.</h4>';
.exit