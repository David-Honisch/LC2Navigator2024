select '<hr/><h2>Import lc2webllmchat processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2webllmchat;
drop table IF EXISTS lc2webllmchat_main;
drop table IF EXISTS lc2webllmchat_install;
drop table IF EXISTS lc2webllmchat_help;
drop table IF EXISTS lc2webllmchat_data;
drop table IF EXISTS lc2webllmchat_info;
drop table IF EXISTS lc2webllmchat_work;
drop table IF EXISTS lc2webllmchat_procdata;
drop table IF EXISTS lc2webllmchattemp;
drop table IF EXISTS lc2webllmchat_datatemp;
drop table IF EXISTS lc2webllmchat_worktemp;
drop table IF EXISTS lc2webllmchat_proc;
drop table IF EXISTS lc2webllmchat_tests;
drop table IF EXISTS lc2webllmchat_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2webllmchat( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2webllmchat_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2webllmchat_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2webllmchat_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2webllmchat_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2webllmchat_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2webllmchat_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2webllmchat_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2webllmchat_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2webllmchat_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2webllmchat_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2webllmchattemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2webllmchat_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2webllmchat\\import\\import.csv lc2webllmchattemp
-- INSERT INTO lc2webllmchat(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2webllmchattemp;
.import .\\resources\\plugins\\lc2webllmchat\\import\\import.csv lc2webllmchat
.import .\\resources\\plugins\\lc2webllmchat\\import\\main.csv lc2webllmchat_main
.import .\\resources\\plugins\\lc2webllmchat\\import\\install.csv lc2webllmchat_install
.import .\\resources\\plugins\\lc2webllmchat\\import\\help.csv lc2webllmchat_help
.import .\\resources\\plugins\\lc2webllmchat\\import\\info.csv lc2webllmchat_info
.import .\\resources\\plugins\\lc2webllmchat\\import\\data.csv lc2webllmchat_data
.import .\\resources\\plugins\\lc2webllmchat\\import\\work.csv lc2webllmchat_work
--.import .\\resources\\plugins\\lc2webllmchat\\import\\proc.csv lc2webllmchat_proc
.import .\\resources\\plugins\\lc2webllmchat\\import\\tests.csv lc2webllmchat_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2webllmchat\\import\\proc.csv' lc2webllmchat_proctemp
-- .separator ";"
-- INSERT INTO lc2webllmchat_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2webllmchat_proctemp;
-- select 'lc2webllmchat_work count:';
-- select count(*) from lc2webllmchat_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2webllmchat count:';
select count(*) from lc2webllmchat;
select '<p>start data import to plugin tables</p>';
-- delete from lc2webllmchat_datatemp;
--
select '<p>lc2webllmchat count:';
select count(*) from lc2webllmchat;
select 'lc2webllmchat_data count:';
select count(*) from lc2webllmchat_data;
select 'lc2webllmchat_info count:';
select count(*) from lc2webllmchat_info;
select 'lc2webllmchat_help count:';
select count(*) from lc2webllmchat_help;
select 'lc2webllmchat_procdata count:';
select count(*) from lc2webllmchat_procdata;
select 'lc2webllmchat_work count:';
select count(*) from lc2webllmchat_work;
select 'lc2webllmchat_proc count:';
select count(*) from lc2webllmchat_proc;
select 'lc2webllmchat_proctemp count:';
select count(*) from lc2webllmchat_proctemp;

drop table IF EXISTS lc2webllmchattemp;
-- drop table IF EXISTS lc2webllmchat_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2webllmchat processes done.</h4>';
.exit