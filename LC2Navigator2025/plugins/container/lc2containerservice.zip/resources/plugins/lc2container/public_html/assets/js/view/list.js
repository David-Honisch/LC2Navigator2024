'use strict';
var appConfig;



window.onload = init();

function init() {
    console.log('INIT RUNNING...');
    $('#out').append('INIT RUNNING...');
    getHead();

    if (fs.existsSync(APPCFG)) {
        console.log(APPCFG + " file exists.");
        appConfig = getAppConfig(APPCFG);

    } else {
        console.log(APPCFG + ' file does not exist.\nCreating new Configuration file.' + APPCFG);

        //  setAppConfig(APPCFG, appConfig);
    }
    $('#submenu, #alertcnt').on('click', 'a[href^="http"]', function(event) {
        event.preventDefault();
        console.log(this.href + " opens...");
        shell.openExternal(this.href);
    });
    $('#out').html('Successfully done.');

    console.log('DONE.');
}

function getHead() {
    document.title = 'LETZECHANCE.ORG - Show table';
    var head = getHeader(cfg.local);
    // console.log(JSON.stringify(head));    
    $('#head').html(head);
    $('#ptitle').html('LC2Navigator Home - Show table');
}


function print(t, isAppend) {
    if (!isAppend) {
        out.html(t);
    } else {
        out.append(t);
    }
}

function msg(t) {
    return t;
}