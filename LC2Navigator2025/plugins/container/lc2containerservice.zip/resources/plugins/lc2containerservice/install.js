try {
    document.getElementById("appcnt").innerHTML = "";
    document.getElementById("modcnt").innerHTML = "";
    for (var v in installDirectories) {
        createDir(installDirectories[v]);
    }
    var opath = window.nodeRequire('path');
    var resDir = opath.join(__dirname, '../../resources/');
    var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
    var downloadDir = opath.join(__dirname, '../../');
    console.log(resDir);
    console.log(pluginDir);
    console.log(downloadDir);
    Install_Mod(resDir,"modcnt");


    doDownload(downloadUrls, pluginDir);
    document.getElementById("mvncnt").innerHTML += "<h1>Please wait, build in progress</h1>";
    setTimeout(() => {
        document.getElementById("mvncnt").innerHTML += "<h1>Maven Build</h1>";
        document.getElementById("mvncnt").innerHTML += "<h1>Building....</h1>";
        execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'mvncnt');
        //execCMD('.\\resources\\plugins\\' + pluginName + '\\build.bat install', 'mvncnt');
        document.getElementById("appcnt").innerHTML += "<h1>Build successfully done</h1>";
        
    }, 2000);
    // doUnzip(downloadUrls, targetDir);
} catch (e) {
    console.error(e);
    alert(e.stack);
}