select '<hr/><h2>Import lc2stable_diffusion processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2stable_diffusion;
drop table IF EXISTS lc2stable_diffusion_main;
drop table IF EXISTS lc2stable_diffusion_install;
drop table IF EXISTS lc2stable_diffusion_help;
drop table IF EXISTS lc2stable_diffusion_data;
drop table IF EXISTS lc2stable_diffusion_info;
drop table IF EXISTS lc2stable_diffusion_work;
drop table IF EXISTS lc2stable_diffusion_procdata;
drop table IF EXISTS lc2stable_diffusiontemp;
drop table IF EXISTS lc2stable_diffusion_datatemp;
drop table IF EXISTS lc2stable_diffusion_worktemp;
drop table IF EXISTS lc2stable_diffusion_proc;
drop table IF EXISTS lc2stable_diffusion_tests;
drop table IF EXISTS lc2stable_diffusion_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2stable_diffusion( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2stable_diffusion_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2stable_diffusion_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2stable_diffusion_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2stable_diffusiontemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2stable_diffusion_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2stable_diffusion\\import\\import.csv lc2stable_diffusiontemp
-- INSERT INTO lc2stable_diffusion(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2stable_diffusiontemp;
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\import.csv lc2stable_diffusion
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\main.csv lc2stable_diffusion_main
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\install.csv lc2stable_diffusion_install
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\help.csv lc2stable_diffusion_help
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\info.csv lc2stable_diffusion_info
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\data.csv lc2stable_diffusion_data
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\work.csv lc2stable_diffusion_work
--.import .\\resources\\plugins\\lc2stable_diffusion\\import\\proc.csv lc2stable_diffusion_proc
.import .\\resources\\plugins\\lc2stable_diffusion\\import\\tests.csv lc2stable_diffusion_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2stable_diffusion\\import\\proc.csv' lc2stable_diffusion_proctemp
-- .separator ";"
-- INSERT INTO lc2stable_diffusion_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2stable_diffusion_proctemp;
-- select 'lc2stable_diffusion_work count:';
-- select count(*) from lc2stable_diffusion_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2stable_diffusion count:';
select count(*) from lc2stable_diffusion;
select '<p>start data import to plugin tables</p>';
-- delete from lc2stable_diffusion_datatemp;
--
select '<p>lc2stable_diffusion count:';
select count(*) from lc2stable_diffusion;
select 'lc2stable_diffusion_data count:';
select count(*) from lc2stable_diffusion_data;
select 'lc2stable_diffusion_info count:';
select count(*) from lc2stable_diffusion_info;
select 'lc2stable_diffusion_help count:';
select count(*) from lc2stable_diffusion_help;
select 'lc2stable_diffusion_procdata count:';
select count(*) from lc2stable_diffusion_procdata;
select 'lc2stable_diffusion_work count:';
select count(*) from lc2stable_diffusion_work;
select 'lc2stable_diffusion_proc count:';
select count(*) from lc2stable_diffusion_proc;
select 'lc2stable_diffusion_proctemp count:';
select count(*) from lc2stable_diffusion_proctemp;

drop table IF EXISTS lc2stable_diffusiontemp;
-- drop table IF EXISTS lc2stable_diffusion_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2stable_diffusion processes done.</h4>';
.exit