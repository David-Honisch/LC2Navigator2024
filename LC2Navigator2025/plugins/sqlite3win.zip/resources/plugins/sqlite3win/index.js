function pluginINIT(pName) {
    const APPCFG = "application.config.json";
    try {
        var cfg = getAppConfig(APPCFG);
        //const api = window.nodeRequire(path.join(__dirname, '..', 'assets', 'js', 'api', 'api.js'));
        var arg = getPluginArguments();
        console.log(arg);
        //
        // var dlPath = cfg.api.baseurl;
        var dlPath = cfg.resources.homeurldir;
        var resDir = path.join(__dirname, '../../');
        var localFileName = resDir + pName + "-news.json";
        // get_Download_File(dlPath, cfg.resources.sqlite, cfg.resources.sqlite, resDir, pluginName + '');
        // get_Download_File(dlPath, cfg.resources.sqlitexslt, cfg.resources.sqlitexslt, resDir, pluginName + '');
        execCMD("call resources\\cmd\\register_plugin.bat " + pName, pName + "_info", true, false);
        execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\proc.csv", pName + "_install", true, false);
        //creating schema import        
        $('#' + pName + '').before(getPluginButtons(pName));
        // $('#' + pName + '_main').before(getPluginButtons(pName));
        $('#' + pName + '_main').append(getPluginButtons(pName));
        printDirectory('resources\\plugins\\' + pName + '\\', '' + pName + '_info', true);
        //queries        

        setTimeout(() => {
            set_DragOver(pName+'maindrop', 'newdb', pName+"htmlout", pName+"outFile", ["bat", "csv", "git", "h", "c", "cpp", "js", "json", "log", "nfo", "md", "xls", "xlsx", "txt", "xml", "xslt"]);
            execCMD("resources\\cmd\\register.config.bat", "_app", true, false);
            execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\cmd\\csv\\check.csv", "_app", true, false);
        }, 3000);
        //queries
        setTimeout(() => {
            execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pName + "\\\\schema.sql\"", pName + "_install", true, false);
            getExecPluginCMDList(".\\resources\\" + pName + ".db", pluginTable, '#' + pName + '_main', true);
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_main", '#' + pluginName + '', true);
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_main", '#' + pluginName + '_main', true);
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_install", '#' + pluginName + '_install', true);
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_info", '#' + pluginName + '_info', true);
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_help", '#' + pluginName + '_help', true);
            execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\plugins\\" + pluginName + "\\csv\\check.csv", "" + pluginName + "_install", true, false);
            // execCMD("call  resources\\app\\sqlite\\SQLite3.exe  \"resources\\" + pluginName + ".db\" \"select * from " + pluginTable + "_work\">\"resources\\plugins\\" + pluginName + "\\csv\\data.csv\"",pName + "_info", true, false);

        }, 3000);
    } catch (error) {
        $("" + out).append("<p class=\"alert\">" + error + "<p>");
        console.error(error);
        console.error(error.stack);
    }
}
function pluginINIT2(pName) {
    const APPCFG = "application.config.json";
    try {
        var cfg = getAppConfig(APPCFG);
        //const api = window.nodeRequire(path.join(__dirname, '..', 'assets', 'js', 'api', 'api.js'));
        var arg = getPluginArguments();
        console.log(arg);
        //
        // var dlPath = cfg.api.baseurl;
        var dlPath = cfg.resources.homeurldir;
        var resDir = path.join(__dirname, '../../');
        var localFileName = resDir + pName + "-news.json";
        get_Download_File(dlPath, cfg.resources.sqlite, cfg.resources.sqlite, resDir, pName);
        get_Download_File(dlPath, cfg.resources.sqlitexslt, cfg.resources.sqlitexslt, resDir, pName);


        //
        // execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\work.csv", "pnavmenu", true, false);
        execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\proc.csv", "pnavmenu", true, false);
        //execCMD("call tasklist /FO CSV /NH> .\\resources\\plugins\\" + pluginName + "\\import\\work.csv", "pnavmenu");
        //creating schema import
        execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pName + "\\\\schema.sql\"", "pschema", true, false);
        //eof schema import
        if (getConfirmation('Install requirements of ' + pName + ' now?')) { getOpenDialog('#dialog', '.\\resources\\plugins\\' + pName + '\\install.html', 'Install', { minWidth: 250, minHeight: 150, width: 400 }) };
        getXML(".\\resources\\plugins\\" + pName + "\\xml\\app.xml", ".\\resources\\plugins\\" + pName + "\\xml\\app.xslt", "pnav");
        execCMD("call resources\\cmd\\register_plugin.bat " + pName, "pregister", true, false);
        $('#' + pName + '').before(getPluginButtons(pName));
        $('#' + pName + '_main').append(getPluginButtons(pName));
        // console.log("reading tables...");
        // getExecPluginCMDList(".\\resources\\" + pName + ".db", pluginTable, '#' + pName + '', false);
        setTimeout(() => {
            try {

                // getXSLTTranformation(pluginName + '_info', localFileName, '<h1>TEST<h1><xsl:value-of select="/root" /><xsl:for-each select="root"><xsl:value-of select="subject" /><xsl:value-of select="body" /></xsl:for-each>');
                //
                console.log("reading tables...");
                getExecPluginCMDList(".\\resources\\" + pName + ".db", pluginTable, '#' + pName + '', true);
                execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_main", '#' + pluginName + '_main', true);
                execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_install", '#' + pluginName + '_install', true);
                execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_help", '#' + pluginName + '_help', true);

                execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\plugins\\" + pluginName + "\\csv\\check.csv", "" + pluginName + "_install", true, false);

                execCMD("call  resources\\app\\sqlite\\SQLite3.exe  \"resources\\" + pluginName + ".db\" \"select * from " + pluginTable + "_work\">\"resources\\plugins\\" + pluginName + "\\csv\\" + pluginName + "_data.csv\"", "pout", true, false);

                execCMD("call  \"resources\\plugins\\" + pluginName + "\\resources\\work\\" + pluginName + ".bat\"", "pform", true, false);



                var res2 = getSQLQuery("select * from " + pluginTable + "_work", "resources\\" + pluginName + ".db");
                showResourceList(res2, pluginName, '', true);

                var res = getSQLQuery("select * from " + pluginTable + "_info", "resources\\" + pluginName + ".db");
                showResourceList(res, pluginName + '_info', '', true);

                var procres = getSQLQuery("select * from " + pluginTable + "_proc", "resources\\" + pluginName + ".db");
                show_ResourceList(procres, pluginName + '_main', 'first_name', 'kill task ', 'execCMD(\'taskkill /F /PID ', '\',\'pout\');', true);

                var testres = getSQLQuery("select * from " + pluginTable + "_tests", "resources\\" + pluginName + ".db");
                showResList(testres, pluginName + '_tests', '', true);


                // printDirectory('resources\\plugins\\' + pluginName + '\\', '' + pluginName + '_install', true);
                // setDragOver('inputKeyFile', pluginName + 'result');
                // setTimeout(() => {
                //     // var out = document.getElementById('result');
                //     // console.log(out !== undefined ? "Yes" : "NO !!!");
                //     loadExcelResFile(pluginName + 'result', "inputKeyFile");
                // }, 4000);
                setTimeout(() => {
                    set_DragOver('sqlite3winmaindrop', 'newdb', "sqlite3winhtmlout", "sqlite3winoutFile", ["bat", "csv", "git", "h", "c", "cpp", "js", "json", "log", "nfo", "md", "xls", "xlsx", "txt", "xml", "xslt"]);
                    execCMD("resources\\cmd\\register.config.bat", "_app", true, false);
                    execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\cmd\\csv\\check.csv", "_app", true, false);
                }, 3000);

            } catch (error) {
                $("" + out).append("<p class=\"alert\">" + error + "<p>");
                console.error(error);
                console.error(error.stack);
            }
        }, 3000);
    } catch (e) {
        alert(e.stack);
    }
}