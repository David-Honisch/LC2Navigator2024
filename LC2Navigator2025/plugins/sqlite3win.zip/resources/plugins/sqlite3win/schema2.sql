select '<hr/><h2>Import sqlite3win processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS sqlite3win;
drop table IF EXISTS sqlite3win_main;
drop table IF EXISTS sqlite3win_install;
drop table IF EXISTS sqlite3win_help;
drop table IF EXISTS sqlite3win_data;
drop table IF EXISTS sqlite3win_work;
drop table IF EXISTS sqlite3win_procdata;
drop table IF EXISTS sqlite3wintemp;
drop table IF EXISTS sqlite3win_datatemp;
drop table IF EXISTS sqlite3win_worktemp;
drop table IF EXISTS sqlite3win_proc;
drop table IF EXISTS sqlite3win_tests;
drop table IF EXISTS sqlite3win_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE sqlite3win( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE sqlite3win_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS sqlite3wintemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS sqlite3win_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\sqlite3win\\import\\import.csv sqlite3wintemp
-- INSERT INTO sqlite3win(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3wintemp;
.import .\\resources\\plugins\\sqlite3win\\import\\import.csv sqlite3win
.import .\\resources\\plugins\\sqlite3win\\import\\main.csv sqlite3win_main
.import .\\resources\\plugins\\sqlite3win\\import\\install.csv sqlite3win_install
.import .\\resources\\plugins\\sqlite3win\\import\\help.csv sqlite3win_help
.import .\\resources\\plugins\\sqlite3win\\import\\data.csv sqlite3win_data
.import .\\resources\\plugins\\sqlite3win\\import\\work.csv sqlite3win_work
.import .\\resources\\plugins\\sqlite3win\\import\\tests.csv sqlite3win_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
.separator ","
.import '.\\resources\\plugins\\sqlite3win\\import\\proc.csv' sqlite3win_proctemp
select 'sqlite3win_proctemp count:';
select count(*) from sqlite3win_proctemp;
.separator ";"
INSERT INTO sqlite3win_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from sqlite3win_proctemp;
select 'sqlite3win_proc count:';
select count(*) from sqlite3win_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'sqlite3win count:';
select count(*) from sqlite3win;
select '<p>start data import to plugin tables</p>';
-- delete from sqlite3win_datatemp;
--
select '<p>sqlite3win count:';
select count(*) from sqlite3win;
select 'sqlite3win_data count:';
select count(*) from sqlite3win_data;
select 'sqlite3win_procdata count:';
select count(*) from sqlite3win_procdata;
select 'sqlite3win_work count:';
select count(*) from sqlite3win_work;
select 'sqlite3win_proc count:';
select count(*) from sqlite3win_proc;
select 'sqlite3win_proctemp count:';
select count(*) from sqlite3win_proctemp;

drop table IF EXISTS sqlite3wintemp;
-- drop table IF EXISTS sqlite3win_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import sqlite3win processes done.</h4>';
.exit