//package fileprocessors;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class TestFileReader {

    public static void main(String[] args) throws Exception {
        
        
        String filePath = "table.csv";   
        List<String> values = null;
        
        List<String> lines = new ArrayList<String>();
        
        try(BufferedReader br = new BufferedReader(new FileReader(filePath))){           
            
            br.readLine();
            String line = null;
            
     while((line = br.readLine()) != null) {                   
                lines.add(line);               
            
        
        for(String ln : lines) {
            
            
            String [] header = ln.split(",");
            values = new ArrayList<String>();
            
            values = Arrays.asList(header);
        
        }
        
            }   
        
     for(String val : values) {
            
            System.out.println(val);
        }
        }
    }
}