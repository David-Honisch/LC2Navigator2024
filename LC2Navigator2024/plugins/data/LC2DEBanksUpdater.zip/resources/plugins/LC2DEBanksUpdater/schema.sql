select '<hr/><h2>Import LC2DEBanksUpdater processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2DEBanksUpdater;
drop table IF EXISTS LC2DEBanksUpdater_main;
drop table IF EXISTS LC2DEBanksUpdater_install;
drop table IF EXISTS LC2DEBanksUpdater_help;
drop table IF EXISTS LC2DEBanksUpdater_data;
drop table IF EXISTS LC2DEBanksUpdater_info;
drop table IF EXISTS LC2DEBanksUpdater_work;
drop table IF EXISTS LC2DEBanksUpdater_procdata;
drop table IF EXISTS LC2DEBanksUpdatertemp;
drop table IF EXISTS LC2DEBanksUpdater_datatemp;
drop table IF EXISTS LC2DEBanksUpdater_worktemp;
drop table IF EXISTS LC2DEBanksUpdater_proc;
drop table IF EXISTS LC2DEBanksUpdater_tests;
drop table IF EXISTS LC2DEBanksUpdater_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2DEBanksUpdater( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2DEBanksUpdater_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2DEBanksUpdatertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2DEBanksUpdater_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\import.csv LC2DEBanksUpdatertemp
-- INSERT INTO LC2DEBanksUpdater(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DEBanksUpdatertemp;
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\import.csv LC2DEBanksUpdater
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\main.csv LC2DEBanksUpdater_main
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\install.csv LC2DEBanksUpdater_install
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\help.csv LC2DEBanksUpdater_help
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\data.csv LC2DEBanksUpdater_data
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\info.csv LC2DEBanksUpdater_info
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\work.csv LC2DEBanksUpdater_work
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\proc.csv LC2DEBanksUpdater_proc
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\tests.csv LC2DEBanksUpdater_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2DEBanksUpdater\\import\\proc.csv' LC2DEBanksUpdater_proctemp
-- .separator ";"
-- INSERT INTO LC2DEBanksUpdater_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2DEBanksUpdater_proctemp;
-- select 'LC2DEBanksUpdater_work count:';
-- select count(*) from LC2DEBanksUpdater_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2DEBanksUpdater count:';
select count(*) from LC2DEBanksUpdater;
select '<p>start data import to plugin tables</p>';
-- delete from LC2DEBanksUpdater_datatemp;
--
select '<p>LC2DEBanksUpdater count:';
select count(*) from LC2DEBanksUpdater;
select 'LC2DEBanksUpdater_data count:';
select count(*) from LC2DEBanksUpdater_data;
select 'LC2DEBanksUpdater_info count:';
select count(*) from LC2DEBanksUpdater_info;

select 'LC2DEBanksUpdater_procdata count:';
select count(*) from LC2DEBanksUpdater_procdata;
select 'LC2DEBanksUpdater_work count:';
select count(*) from LC2DEBanksUpdater_work;
select 'LC2DEBanksUpdater_proc count:';
select count(*) from LC2DEBanksUpdater_proc;
select 'LC2DEBanksUpdater_proctemp count:';
select count(*) from LC2DEBanksUpdater_proctemp;

drop table IF EXISTS LC2DEBanksUpdatertemp;
-- drop table IF EXISTS LC2DEBanksUpdater_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2DEBanksUpdater processes done.</h4>';
.exit