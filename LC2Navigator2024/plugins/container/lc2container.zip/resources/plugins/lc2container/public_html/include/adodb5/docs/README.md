# ADOdb Documentation

ADOdb documentation is available in the following locations

- [Online](http://adodb.org/)
- [Download](https://sourceforge.net/projects/adodb/files/Documentation/) for offline use

## Legacy documentation

The old HTML files are available in
[GitHub](https://github.com/ADOdb/ADOdb/tree/8b8133771ecbe9c95e57abbe5dc3757f0226bfcd/docs),
or in the release zip/tarballs for version 5.20 and before on
[Sourceforge](https://sourceforge.net/projects/adodb/files/adodb-php5-only/).

## Changelog

The full historical [Changelog](changelog.md) is available on GitHub.
