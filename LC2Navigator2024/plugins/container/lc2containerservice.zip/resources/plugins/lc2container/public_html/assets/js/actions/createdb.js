  $('#out').html("running...")
  $("#out").load("/view/index.php");