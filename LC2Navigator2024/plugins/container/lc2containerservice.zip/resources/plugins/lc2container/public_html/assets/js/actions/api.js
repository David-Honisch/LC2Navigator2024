function postQUERY(api, id) {
    $.post(infoAPI, {
            q: api,
            value1: "Donald+Duck",
        },
        function(data, status) {
            $(id).append("Data: " + data + "\nStatus: " + status);
        });
}

function getQUERY(api, id) {

    $.get(api + "&value1=test&value2=test", function(data, status) {
        $(id).append("infoAPI Data: " + data + "\nStatus: " + status);
    });
}

function loadQUERY(api, id) {
    $(id).load(api, function(responseTxt, statusTxt, xhr) {
        if (statusTxt == "success")
            $(id).append(".");
        if (statusTxt == "error")
            $(id).append("Error: " + xhr.status + ": " + xhr.statusText);
    });
}

function getQUERY(api, id, ) {
    $(id).load(api, function(responseTxt, statusTxt, xhr) {
        if (statusTxt == "success")
            $(id).append(".");
        if (statusTxt == "error")
            $(id).append("Error: " + xhr.status + ": " + xhr.statusText);
    });
}

function loadXML(id, api, tag, tags) {
    $.post(api, {
            q: api,
            value1: "Donald+Duck",
            cache: false,
            data: {
                value1: "Donald+Duck"
            },
            dataType: "xml",
        },
        function(data, status) {
            transformXML(id, data, tag, tags);
        });
}

function loadXMLDoc(id, api, tag, tags) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            transformXML(id, this, tag, tags);
        }
    };
    xmlhttp.open("GET", api, true);
    xmlhttp.send();
}

function transformXML(id, xml, tag, tags) {
    var i;
    var xmlDoc = xml.responseXML;
    var table = "<table><tr><th>" + tags[0] + "</th><th>" + tags[1] + "</th></tr>";
    var x = xmlDoc.getElementsByTagName(tag);
    for (i = 0; i < x.length; i++) {
        table += "<tr><td>" +
            x[i].getElementsByTagName(tags[0])[0].childNodes[0].nodeValue +
            "</td><td>" +
            "<a href=\"" + x[i].getElementsByTagName("URL")[0].childNodes[0].nodeValue + "\" target=\"_blank\">" +
            x[i].getElementsByTagName(tags[1])[0].childNodes[0].nodeValue +
            "</a>" +
            "</td></tr>";
    }
    table += "</table>";
    document.getElementById(id).innerHTML = table;
}