select '<hr/><h2>Import lc2dockerphpapache processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2dockerphpapache;
drop table IF EXISTS lc2dockerphpapache_main;
drop table IF EXISTS lc2dockerphpapache_install;
drop table IF EXISTS lc2dockerphpapache_help;
drop table IF EXISTS lc2dockerphpapache_data;
drop table IF EXISTS lc2dockerphpapache_info;
drop table IF EXISTS lc2dockerphpapache_work;
drop table IF EXISTS lc2dockerphpapache_procdata;
drop table IF EXISTS lc2dockerphpapachetemp;
drop table IF EXISTS lc2dockerphpapache_datatemp;
drop table IF EXISTS lc2dockerphpapache_worktemp;
drop table IF EXISTS lc2dockerphpapache_proc;
drop table IF EXISTS lc2dockerphpapache_tests;
drop table IF EXISTS lc2dockerphpapache_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2dockerphpapache( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2dockerphpapache_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2dockerphpapachetemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2dockerphpapache_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2dockerphpapache\\import\\import.csv lc2dockerphpapachetemp
-- INSERT INTO lc2dockerphpapache(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2dockerphpapachetemp;
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\import.csv lc2dockerphpapache
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\main.csv lc2dockerphpapache_main
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\install.csv lc2dockerphpapache_install
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\help.csv lc2dockerphpapache_help
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\data.csv lc2dockerphpapache_data
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\info.csv lc2dockerphpapache_info
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\work.csv lc2dockerphpapache_work
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\proc.csv lc2dockerphpapache_proc
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\tests.csv lc2dockerphpapache_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2dockerphpapache\\import\\proc.csv' lc2dockerphpapache_proctemp
-- .separator ";"
-- INSERT INTO lc2dockerphpapache_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2dockerphpapache_proctemp;
-- select 'lc2dockerphpapache_work count:';
-- select count(*) from lc2dockerphpapache_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2dockerphpapache count:';
select count(*) from lc2dockerphpapache;
select '<p>start data import to plugin tables</p>';
-- delete from lc2dockerphpapache_datatemp;
--
select '<p>lc2dockerphpapache count:';
select count(*) from lc2dockerphpapache;
select 'lc2dockerphpapache_data count:';
select count(*) from lc2dockerphpapache_data;
select 'lc2dockerphpapache_info count:';
select count(*) from lc2dockerphpapache_info;

select 'lc2dockerphpapache_procdata count:';
select count(*) from lc2dockerphpapache_procdata;
select 'lc2dockerphpapache_work count:';
select count(*) from lc2dockerphpapache_work;
select 'lc2dockerphpapache_proc count:';
select count(*) from lc2dockerphpapache_proc;
select 'lc2dockerphpapache_proctemp count:';
select count(*) from lc2dockerphpapache_proctemp;

drop table IF EXISTS lc2dockerphpapachetemp;
-- drop table IF EXISTS lc2dockerphpapache_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2dockerphpapache processes done.</h4>';
.exit