-- select '<h2>Import processes</h2>';
drop table IF EXISTS web_GrabUrls;
drop table IF EXISTS web_GrabUrls_data;
drop table IF EXISTS web_GrabUrls_procdata;
drop table IF EXISTS web_GrabUrlstemp;
drop table IF EXISTS web_GrabUrls_datatemp;
CREATE TABLE web_GrabUrls( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE web_GrabUrls_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE web_GrabUrls_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS web_GrabUrlstemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS web_GrabUrls_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS web_GrabUrls_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\web_GrabUrls\\import\\import.csv web_GrabUrlstemp
-- INSERT INTO web_GrabUrls(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from web_GrabUrlstemp;
.import .\\resources\\plugins\\org.letztechance.domain.web.GrabUrls\\import\\import.csv web_GrabUrls
--
-- eof insert work data
select 'web_GrabUrls count:';
select count(*) from web_GrabUrls;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\web_GrabUrls\\import\\menu.csv' web_GrabUrls_datatemp
-- .import '.\\resources\\plugins\\web_GrabUrls\\import\\menu.csv' web_GrabUrls_datatemp
-- INSERT INTO web_GrabUrls_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from web_GrabUrls_datatemp;
.import '.\\resources\\plugins\\org.letztechance.domain.web.GrabUrls\\import\\menu.csv' web_GrabUrls_data
delete from web_GrabUrls_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\web_GrabUrls\\import\\web_GrabUrlswork.csv' web_GrabUrls_datatemp
-- INSERT INTO web_GrabUrls_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from web_GrabUrls_datatemp;
--
select '<p>web_GrabUrls count:';
select count(*) from web_GrabUrls;
select 'web_GrabUrls_data count:';
select count(*) from web_GrabUrls_data;
select 'web_GrabUrls_procdata count:';
select count(*) from web_GrabUrls_procdata;
.separator ";"
drop table IF EXISTS web_GrabUrlstemp;
-- select '<p>Import done</p>';
.exit