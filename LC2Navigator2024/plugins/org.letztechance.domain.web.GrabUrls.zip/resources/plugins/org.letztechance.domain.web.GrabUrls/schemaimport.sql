select '<h2>Import current process data</h2>';
-- drop table IF EXISTS web_GrabUrls;
-- drop table IF EXISTS web_GrabUrls_data;
drop table IF EXISTS web_GrabUrls_procdata;
drop table IF EXISTS web_GrabUrls_procdatatemp;
-- CREATE TABLE web_GrabUrls( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE web_GrabUrls_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE web_GrabUrls_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS web_GrabUrls_procdatatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';

-- delete from web_GrabUrls_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\org.letztechance.domain.web.GrabUrls\\import\\web_GrabUrlswork.csv' web_GrabUrls_procdatatemp
INSERT INTO web_GrabUrls_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from web_GrabUrls_procdatatemp;
--
select 'web_GrabUrls_procdata count:';
select count(*) from web_GrabUrls_procdata;
.separator ";"
drop table IF EXISTS web_GrabUrls_procdatatemp;
-- select '<p>Import done</p>';
.exit