select '<hr/><h2>Import LC2RegistryWizard processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2RegistryWizard;
drop table IF EXISTS LC2RegistryWizard_main;
drop table IF EXISTS LC2RegistryWizard_install;
drop table IF EXISTS LC2RegistryWizard_help;
drop table IF EXISTS LC2RegistryWizard_data;
drop table IF EXISTS LC2RegistryWizard_info;
drop table IF EXISTS LC2RegistryWizard_work;
drop table IF EXISTS LC2RegistryWizard_procdata;
drop table IF EXISTS LC2RegistryWizardtemp;
drop table IF EXISTS LC2RegistryWizard_datatemp;
drop table IF EXISTS LC2RegistryWizard_worktemp;
drop table IF EXISTS LC2RegistryWizard_proc;
drop table IF EXISTS LC2RegistryWizard_tests;
drop table IF EXISTS LC2RegistryWizard_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2RegistryWizard( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2RegistryWizard_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2RegistryWizardtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2RegistryWizard_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2RegistryWizard\\import\\import.csv LC2RegistryWizardtemp
-- INSERT INTO LC2RegistryWizard(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2RegistryWizardtemp;
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\import.csv LC2RegistryWizard
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\main.csv LC2RegistryWizard_main
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\install.csv LC2RegistryWizard_install
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\help.csv LC2RegistryWizard_help
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\data.csv LC2RegistryWizard_data
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\info.csv LC2RegistryWizard_info
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\work.csv LC2RegistryWizard_work
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\proc.csv LC2RegistryWizard_proc
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\tests.csv LC2RegistryWizard_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2RegistryWizard\\import\\proc.csv' LC2RegistryWizard_proctemp
-- .separator ";"
-- INSERT INTO LC2RegistryWizard_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2RegistryWizard_proctemp;
-- select 'LC2RegistryWizard_work count:';
-- select count(*) from LC2RegistryWizard_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2RegistryWizard count:';
select count(*) from LC2RegistryWizard;
select '<p>start data import to plugin tables</p>';
-- delete from LC2RegistryWizard_datatemp;
--
select '<p>LC2RegistryWizard count:';
select count(*) from LC2RegistryWizard;
select 'LC2RegistryWizard_data count:';
select count(*) from LC2RegistryWizard_data;
select 'LC2RegistryWizard_info count:';
select count(*) from LC2RegistryWizard_info;

select 'LC2RegistryWizard_procdata count:';
select count(*) from LC2RegistryWizard_procdata;
select 'LC2RegistryWizard_work count:';
select count(*) from LC2RegistryWizard_work;
select 'LC2RegistryWizard_proc count:';
select count(*) from LC2RegistryWizard_proc;
select 'LC2RegistryWizard_proctemp count:';
select count(*) from LC2RegistryWizard_proctemp;

drop table IF EXISTS LC2RegistryWizardtemp;
-- drop table IF EXISTS LC2RegistryWizard_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2RegistryWizard processes done.</h4>';
.exit