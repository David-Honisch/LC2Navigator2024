function dobaseInstallation() {
    const APPCFG = "application.config.json";
    try {
        const fs = window.nodeRequire("fs");
        var installcnt = document.getElementById("installcnt");
        var installmodcnt = document.getElementById("installmodcnt");
        var installdlcnt = document.getElementById("installdlcnt");
        var installmvncnt = document.getElementById("installmvncnt");

        var isDBRunning = document.getElementById("isDBRunning");
        var isServerRunning = document.getElementById("isServerRunning");

        installcnt.innerHTML = "";
        installmodcnt.innerHTML = "";
        installdlcnt.innerHTML = "";
        installmvncnt.innerHTML = "";

        if (fs.existsSync(APPCFG)) {
            console.log(APPCFG + ' exists.\nReading Configuration:\n');
            appConfig = getAppConfig(APPCFG);
        }

        for (var v in installDirectories) {
            createDir(installDirectories[v],'installmodcnt');
        }
        var opath = window.nodeRequire('path');
        var resDir = opath.join(__dirname, '../../resources/');
        var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
        var downloadDir = opath.join(__dirname, '../../');
        console.log("Install:Dir:"+resDir+" pluginDir:"+pluginDir+" dlDir:"+downloadDir);
        const NODEAPI = window.nodeRequire(path.join(__dirname,'..', '..', 'assets', 'js', 'api', 'nodeapi.js'));
        console.log(downloadDir);
        var pDB = isPortOpen(3306);
        pDB.then(function(isDBInUse){
            if (isDBInUse == true){
                isDBRunning.value = "The container is NOT running on port:3306.";
                isDBRunning.classList.remove('btn-default');
                isDBRunning.classList.add('btn-success');                
                isDBRunning.setAttribute("onclick","execCMD('"+appConfig.server.launchcontainerNode+"','dialog');");
            }
            else{
                isDBRunning.value = "The container is running on port:3306.";
                isDBRunning.classList.remove('btn-default');
                isDBRunning.classList.add('btn-warning');
                isDBRunning.setAttribute("onclick","execCMD('"+appConfig.server.stopcontainer+"','dialog');");
            }
        })
        var pB = isPortOpen(8085);
        pB.then(function(isDBInUse){
            if (isDBInUse == true){
                isServerRunning.value = "The backend is NOT running on port:8085.";
                isServerRunning.classList.remove('btn-default');
                isServerRunning.classList.add('btn-warning');
                isServerRunning.setAttribute("onclick","execCMD('"+appConfig.cmd+" "+appConfig.params+" "+appConfig.server.jar+"','dialog');");
            }
            else {
                isServerRunning.value = "The backend is running on port:8085.";
                isServerRunning.classList.remove('btn-default');
                isServerRunning.classList.add('btn-success');
                
                isServerRunning.setAttribute("onclick","execCMD('start http://localhost:8085/actuator/shutdown','dialog');");

            }
        })
        

        // InstallModules(resDir);
        Install_Modules(corelibs, resDir, 'installmodcnt');
        //doDownload(downloadUrls, pluginDir,'installcnt');
        for (var v in downloadUrls) {
            var file = downloadUrls[v].file;
            if (!isFileExisting(file)){
                console.log("downloading:"+JSON.stringify(downloadUrls[v]));
                installdlcnt.innerHTML += "" + JSON.stringify(downloadUrls[v]);
                doDownload([downloadUrls[v]], pluginDir,'installcnt');
            }
            else {
                console.log(file+" already exits");
                installdlcnt.innerHTML += "" + file+" already exits<br/>";
            }
        }
        setTimeout(() => {
            execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'installmvncnt', false,false);
        }, 3000);

        // doUnzip(downloadUrls, targetDir);
    } catch (e) {
        console.error(e);
        alert(e.stack);
    }
}