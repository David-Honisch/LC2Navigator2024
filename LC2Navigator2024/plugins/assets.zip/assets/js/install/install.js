function dobaseInstallation() {
    try {
        var installcnt = document.getElementById("installcnt");
        var installmodcnt = document.getElementById("installmodcnt");
        var installdlcnt = document.getElementById("installdlcnt");
        var installmvncnt = document.getElementById("installmvncnt");
        installcnt.innerHTML = "";
        installmodcnt.innerHTML = "";
        installdlcnt.innerHTML = "";
        installmvncnt.innerHTML = "";
        for (var v in installDirectories) {
            createDir(installDirectories[v],'installmodcnt');
        }
        var opath = window.nodeRequire('path');
        var resDir = opath.join(__dirname, '../../resources/');
        var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
        var downloadDir = opath.join(__dirname, '../../');
        console.log(resDir);
        console.log(pluginDir);
        console.log(downloadDir);
        // InstallModules(resDir);
        Install_Modules(corelibs, resDir, 'installmodcnt');
        //doDownload(downloadUrls, pluginDir,'installcnt');
        for (var v in downloadUrls) {
            var file = downloadUrls[v].file;
            if (!isFileExisting(file)){
                console.log("downloading:"+JSON.stringify(downloadUrls[v]));
                installdlcnt.innerHTML += "" + JSON.stringify(downloadUrls[v]);
                doDownload([downloadUrls[s]], pluginDir,'installcnt');
            }
            else {
                console.log(file+" already exits");
                installdlcnt.innerHTML += "" + file+" already exits";
            }
        }
        setTimeout(() => {
            execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'installmvncnt');
        }, 3000);

        // doUnzip(downloadUrls, targetDir);
    } catch (e) {
        console.error(e);
        alert(e.stack);
    }
}