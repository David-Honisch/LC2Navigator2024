$( document ).ready(function() {
    console.log( "LC2Navigator Check install ready." );
    dobaseInstallation();
});