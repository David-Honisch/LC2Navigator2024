/*jshint node: true*/

'use strict';

module.exports = {
    build: [
        '<%= meta.build %>'
    ]
};
