console.log('LC2CONTAINER:\n');
//$(document).ready(function () {
    console.log("LC2Navigator Server ready.");
    var text = document.getElementById("servertext");
    var legend = document.getElementById("serverlegend");
    legend.innerHTML += "LC2Backend Detect running....";
    text.innerHTML += "<span>Container is up.</span>";
    text.innerHTML += "<span>Successfully detected</span>";
    doMore();
    legend.innerHTML = "LC2Backend Detect done.";

   
//});
function showServerWindow(url,target){
    window.open(url, target)
}
function doMore()
{
    $.ajax({
        url: "http://localhost:8085/",
        context: document.body
      }).done(function() {
        var text = document.getElementById("isServerRunning");
        text.innerHTML += "<span>Successfully detected</span>";
        $( this ).removeClass( "btn-warning" );
        $( this ).addClass( "btn-success" );
      });
      $.ajax({
        url: "http://localhost:8081",
        context: document.body
      }).done(function() {
        var text = document.getElementById("isDBRunning");
        text.value = "IS RUNNING";
        $( this ).removeClass( "btn-warning" );
        $( this ).addClass( "btn-success" );
      });
}

// const fs = window.nodeRequire("fs");
// const fs = window.require("fs");
//const fs = require("fs");

// const APPCFG = "application.config.json";
// if (fs.existsSync(APPCFG)) {
//     console.log(APPCFG + ' exists.\nReading Configuration:\n');
//     appConfig = getAppConfig(APPCFG);
// }
// console.log('LC2CONTAINER:\n');
// execCMD(appConfig.check.javacmd, "java_version", false, false);
// setTimeout(() => {
//     execCMD(appConfig.check.viewjava, "java_version", true, false);
// }, 1000);
// //
// var pDB = isPortOpen(3306);
//         pDB.then(function(isDBInUse){
//             if (isDBInUse == true){
//                 isDBRunning.value = "The container is NOT running on port:3306.";
//                 isDBRunning.classList.remove('btn-default');
//                 isDBRunning.classList.add('btn-success');                
//                 isDBRunning.setAttribute("onclick","execCMD('"+appConfig.server.launchcontainerNode+"','dialog');");
//             }
//             else{
//                 isDBRunning.value = "The container is running on port:3306.";
//                 isDBRunning.classList.remove('btn-default');
//                 isDBRunning.classList.add('btn-warning');
//                 isDBRunning.setAttribute("onclick","execCMD('"+appConfig.server.stopcontainer+"','dialog');");
//             }
//         })
//         var pB2 = isPortOpen(8085);
//         pB2.then(function(isDBInUse){
//             if (isDBInUse == true){
//                 isServerRunning.value = "The backend is NOT running on port:8085.";
//                 isServerRunning.classList.remove('btn-default');
//                 isServerRunning.classList.add('btn-warning');
//                 isServerRunning.setAttribute("onclick","execCMD('"+appConfig.cmd+" "+appConfig.params+" "+appConfig.server.jar+"','dialog');");
//             }
//             else {
//                 isServerRunning.value = "The backend is running on port:8085.";
//                 isServerRunning.classList.remove('btn-default');
//                 isServerRunning.classList.add('btn-success');
                
//                 isServerRunning.setAttribute("onclick","execCMD('start http://localhost:8085/actuator/shutdown','dialog');");

//             }
//         })
// //TEST
// class SERVER {
//     static run(o, NODEAPI, jarPath) {
//         NODEAPI.getServerInstances(o, jarPath);
//         console.log(this.name + " done.\n");


//     }
//     static test() {
//         console.log(this.name + ' test successfull.');
//     }

// }
// module.exports = SERVER;