console.log('LC2CONTAINER:\n');
class SERVER {
    static run(o, NODEAPI, jarPath) {
        NODEAPI.getServerInstances(o,jarPath);
        console.log(this.name + " done.\n");


    }
    static test() {
        console.log(this.name + ' test successfull.');
    }

}
module.exports = SERVER;