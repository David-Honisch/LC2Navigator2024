'use strict';
var title = 'LC2Navigator List - Application';

$.urlParam = function(name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results == null) {
        return null;
    }
    return decodeURI(results[1]) || 0;
}


window.onload = init();

function init() {

    getHead();
    $('#out').append('INIT RUNNING...');
    $('#out').html('init successfully  done.');

    $('#submenu, #alertcnt').on('click', 'a[href^="http"]', function(event) {
        event.preventDefault();
        console.log(this.href + " opens...");
        shell.openExternal(this.href);
    });
}

function getNewsXML(source, target) {
    var outXmlString = "";
    try {
        outXmlString = getXsltFileProcess(source, target);
        document.getElementById('appplugins').innerHTML += outXmlString;
    } catch (e) {
        console.error(e);
        console.error(e.stack);
    }

}

function getHead() {
    const path = window.nodeRequire('path');
    const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
    document.title = title;
    var head = getHeader(cfg.local);
    // console.log(JSON.stringify(head));    
    $('#head').html(head);
    $('#ptitle').html(title);
}