'use strict';
// function writeFileSync(wb, filename, opts) {
//     var o = opts || {};
//     o.type = 'file';
//     o.file = filename;
//     if (!o.bookType) switch (o.file.slice(-5).toLowerCase()) {
//         case '.xlsx':
//             o.bookType = 'xlsx';
//             break;
//         case '.xlsm':
//             o.bookType = 'xlsm';
//             break;
//         case '.xlsb':
//             o.bookType = 'xlsb';
//             break;
//         case '.fods':
//             o.bookType = 'fods';
//             break;
//         case '.xlml':
//             o.bookType = 'xlml';
//             break;
//         default:
//             switch (o.file.slice(-4).toLowerCase()) {
//                 case '.xls':
//                     o.bookType = 'biff2';
//                     break;
//                 case '.xml':
//                     o.bookType = 'xml';
//                     break;
//                 case '.ods':
//                     o.bookType = 'ods';
//                     break;
//                 case '.csv':
//                     o.bookType = 'csv';
//                     break;
//             }
//     }
//     return writeSync(wb, o);
// }
// eMsg('Debug');
// var htmlstr;
var XLSX = window.nodeRequire('xlsx');
var utils = new XLSXUtils(XLSX);

// var $ = $;
// var XLSX;
var electron;
// var path;
var xlsxj;
// var fs;
var cDg;
var convert;
// eMsg('Debug');
try {
    // $ = window.nodeRequire('jquery');
    electron = window.nodeRequire('electron').remote;
    // path = window.nodeRequire('path');
    // fs = window.nodeRequire('fs');
} catch (e) {
    eMsg(e);
}
try {
    convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
    xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
    XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
} catch (e) {
    eMsg(e);
}
try {
    convert = XLSX;
    // XLSX = new XLSX();
} catch (e) {
    eMsg(e);
}
// eMsg('Debug');

var HTMLCNT = document.getElementById('htmlcnt');
var HTMLOUT = document.getElementById('htmlout');

// var XLSXPORT = document.getElementById('xlsxport');
var CSVXPORT = document.getElementById('csvxport');
var JSONXPORT = document.getElementById('jsonxport');
var XMLXPORT = document.getElementById('xmlxport');
var WSXPORT = document.getElementById('wsxport');
var DBIMPORT = document.getElementById('dbimport');
var OUTFILE = $('#outFile');
// XLSXPORT.disabled = false;
CSVXPORT.disabled = false;
JSONXPORT.disabled = false;
XMLXPORT.disabled = false;
WSXPORT.disabled = false;
DBIMPORT.disabled = false;
loadExcelResFile(HTMLOUT,'drop');