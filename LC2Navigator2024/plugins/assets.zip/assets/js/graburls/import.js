var xlsxUtils = new XLSXUtils(XLSX);
console.log('main.js running...');
/* <input type="submit" value="Import to SQLite" id="dbimport" onclick="export_db();" disabled="false"></input> */
$("#saveall").on("click", function(e) {
    alert('Debug');
    e.preventDefault();
    e.stopPropagation();
    xlsxUtils.export_all();
});
$("#csvxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    xlsxUtils.export_csv();
});
$("#xmlxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    xlsxUtils.export_xml();
});
$("#jsonxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    xlsxUtils.export_json();
});
$("#btngraburls").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    // alert('Debug');
    xlsxUtils.grab_urls();
});
$("#dbimport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    // alert('Debug');
    xlsxUtils.export_db();
});
$("#wsxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    // alert('Debug');
    xlsxUtils.export_ws();
});
$("#runserver").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    try {
        // alert('Debug');
        execCMD('.\\resources\\plugins\\graburls\\runserver.bat', 'outcnt');
        // alert('Debug');
    } catch (error) {
        alert(error);
        alert(error.stack);
    }
});
//
(function () {
    var readf = document.getElementById('readf');

    function handleF( /*e*/) {
        var o = electron.dialog.showOpenDialog({
            title: 'Select a file',
            filters: [{
                name: "Spreadsheets",
                extensions: "xls|xlsx|xlsm|xlsb|xml|xlw|xlc|csv|txt|dif|sylk|slk|prn|ods|fods|uos|dbf|wks|123|wq1|qpw|htm|html".split("|")
            }],
            properties: ['openFile']
        });
        if (o.length > 0) process_wb(XLSX.readFile(o[0]));
    }
    readf.addEventListener('click', handleF, false);
})();

(function () {
    var xlf = document.getElementById('xlf');

    function handleFile(e) {
        do_file(e.target.files, htmlOUT);
    }
    xlf.addEventListener('change', handleFile, false);
})();
getFullIndexList('#tableId', 'https://www.letztechance.org/webservices/getcontent.php', 'https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=');
console.log('import.js done.');
