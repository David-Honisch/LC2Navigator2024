// $.urlParam = function(name) {
//         var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);EditController
//         if (results == null) {
//             return null;
//         }
//         return decodeURI(results[1]) || 0;
//     }
//     //angular
// const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
var app = angular.module('app', ['ui.bootstrap']);

const path = window.nodeRequire('path');
const jQuery = window._PAGE_.jQuery;
const { readFileSync, fs } = window.nodeRequire('fs');
// const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
// const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
const cfg = window.nodeRequire(path.join(__dirname,'..', '..', 'config.json'));
const model = window.nodeRequire(path.join(__dirname, '..', 'assets', 'js', 'app', 'model.js'));
const cpath = path.join(__dirname);
const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
const gelectron = window.nodeRequire('electron');
const shell = gelectron.shell;
const OPEN_LINK = "https://www.letztechance.org/openlink?";
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    top: 140,
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};


function EditController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    const path = window.nodeRequire('path');
    // default values for pagination and filtering
    $scope.pageSize = 10;
    $scope.maxSize = 15;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    $scope.currentDB = $.urlParam('db') !== undefined ? $.urlParam('db') : "lc";
    $scope.currentTable = $.urlParam('table') !== undefined ? $.urlParam('table') : "systables";
    $scope.data = [];
    $scope.security = [];
    $scope.query = { browser: "" };
    $scope.index = [];
    $scope.news = [];
    $scope.menu = [];
    $scope.person = [];
    $scope.log = [];

    // get the data
    // $http.get('assets/js/data/mainmenu.json')
    //     .success(function(data) {
    //         $scope.menu = data;
    //     });
    // console.log(APPCFG);
    $scope.cfg = getAppConfig(APPCFG);
    $scope.menu = $scope.cfg.topmenu;


    $http.get($scope.cfg.apiexternal[0].url)
        .success(function (data) {
            // set the data
            $scope.index = data.list;
        });

    $http.get($scope.cfg.apiexternal[1].url)
        .success(function (data) {
            // set the data
            $scope.news = data.row;
        });

    $http.get($scope.cfg.apiexternal[2].url)
        .success(function (data) {
            $scope.security = data.row;
        });
    $http.get($scope.cfg.apiexternal[5].url)
        .success(function (data) {
            $scope.person = data.row;
        });
    $http.get($scope.cfg.apiexternal[6].url)
        .success(function (data) {
            $scope.log = data;
        });

    $scope.data = getSQLQuery('select * from  ' + $.urlParam('table') + ' order by person_id asc', dbPath);
    $scope.dataplugins = getSQLQuery('select * from plugins order by person_id asc', dbPath);
    $scope.dropdowns = getSQLQuery('select * from dropdowns order by person_id asc, name asc', dbPath);

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    console.log("resdir:" + resDir)
    get_DownloadFile(dlPath, "util.xml", resDir + "util.xml", resDir, "_app");
    get_DownloadFile(dlPath, "util.xslt", resDir + "util.xslt", resDir, "_app");
    document.getElementById('appplugins').innerHTML += '<input type="button" value="Get Update" onclick="getNewsXML(\'util.xml\', \'util.xslt\');"></input>';


    if ($.urlParam('db') !== undefined) {
        console.log($.urlParam('table') + " exists.");
        var item = readItem($.urlParam('table'), $.urlParam('id'));
        console.log(item);
        if (item[0] !== undefined && item[0]['name'] !== undefined) {
            $('#name').val(item[0]['name']);
            $('#namedetail').text(item[0]['name']);
            $('#first_name').val(item[0]['first_name']);
            $('#first_namedetail').text(item[0]['first_name']);
            $('#last_name').val(item[0]['last_name']);
            $('#last_namedetail').text(item[0]['last_name']);
            $('#city').val(item[0]['city']);
            $('#citydetail').text(item[0]['city']);
            $('#street').val(item[0]['street']);
            $('#streetdetail').text(item[0]['street']);
            $('#zipcode').val(item[0]['zipcode']);
            $('#zipcodedetail').text(item[0]['zipcode']);
            $('#description').val(item[0]['description']);
            $('#descriptiondetail').text(item[0]['description']);
            $('#url').val(item[0]['url']);
            $('#urldetail').text(item[0]['url']);
        }


    } else {
        console.log(tableName + " does not exists.");

        //  setAppConfig(APPCFG, appConfig);
    }
    // setTimeout(() => {
    // getXML("app.xml", "app.xslt");
    // }, 1000);
    console.log('DONE.');



    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function (data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function () {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });

    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function (page) {
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function (items, old) {
        $scope.currentPage = 0;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function (items) {
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 2) * $scope.pageSize + $scope.pagedItems.length;
    });
    // set the pagination for the filtered items
    function setPage() {
        $scope.start = ($scope.currentPage - 0) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 0);
    }
    function getSQLQuery(sql, dbPath) {
        var res = model.GetQuery(dbPath, sql);
        var list = {
            "Data": []
        };
        for (var v in res) {
            var t = {
                "id": res[v]['person_id'],
                "name": res[v]['name'],
                "sname": shortName(res[v]['name']),
                "first_name": res[v]['first_name'],
                "last_name": res[v]['last_name'],
                "zipcode": res[v]['zipcode'],
                "city": res[v]['city'],
                "street": res[v]['street'],
                "description": res[v]['description'],
                "url": res[v]['url'],

            };
            list['Data'].push(t);
        }
        return list.Data;

    }

    function getXML(source, target, id) {
        var outXmlString = "";
        try {
            outXmlString = getXsltFileProcess(source, target);
            document.getElementById(id).innerHTML += outXmlString;
        } catch (e) {
            console.error(e);
            console.error(e.stack);
        }

    }




}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function (e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function () {
    return function (input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});