$.urlParam = function (name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results == null) {
        return null;
    }
    return decodeURI(results[1]) || 0;
}
function encode_utf8(s) {
    return unescape(encodeURIComponent(s));
}

function decode_utf8(s) {
    return decodeURIComponent(escape(s));
}

function print(t, isAppend) {
    if (!isAppend) {
        out.html(t);
    } else {
        out.append(t);
    }
}

function msg(t) {
    return t;
}


function createDatabase() {
    var table = $("#newdb").val();
    alert('Create Database:' + table);
    var res = model.GetQuery(dbPath, 'CREATE TABLE ' + table + ' ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT(255,0) NOT NULL, "first_name" TEXT(255,0) NULL, "description" TEXT(255,0) NULL, "zipcode" TEXT(255,0) NULL, "city" TEXT(255,0) NULL,	 "street" TEXT(255,0) NULL,	 "url" TEXT NULL);');
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    res = model.GetQuery(dbPath, 'INSERT INTO systables (name,first_name, description,url)VALUES(\'' + table + '\',\'menu.bat\',\'menu.bat\',\'menu.bat\');');
    document.getElementById("newdbcnt").innerHTML += JSON.stringify(res) + " done.";
}
function getSQLQuery(sql, dbPath) {
    var res = model.GetQuery(dbPath, sql);
    var list = {
        "Data": []
    };
    for (var v in res) {
        var t = {
            "id": res[v]['person_id'],
            "created": res[v]['created'],
            "enddate": res[v]['enddate'],
            "name": res[v]['name'],
            "sname": shortName(res[v]['name']),
            "first_name": res[v]['first_name'],
            "last_name": res[v]['last_name'],
            "city": res[v]['city'],
            "street": res[v]['street'],
            "zipcode": res[v]['zipcode'],
            "description": res[v]['description'],
            "url": res[v]['url'],
        };
        list['Data'].push(t);
    }
    return list.Data;

}
function getExtractArg(arguments, pattern) {
    var query;
    var args = JSON.parse(JSON.stringify(arguments));
    var json = args["0"]["name"];
    var prop1 = JSON.parse(json);
    var prop = prop1["prop1"];
    for (var v in prop) {
        var citem = prop[v];
        if (citem.includes(pattern)) {
            query = citem.replace(pattern, '')
        }
    }
    return query;
}
function readItem(table, id) {
    return model.GetQuery(dbPath, 'SELECT * FROM ' + table + ' WHERE person_id=' + id + ';');
}
function getMsgBody(id, title, text) {
    var props = {
        //appendTo: id,
        title: title,
        show: "puff",
        hide: "explode",
        top: 140,
        resizable: true,
        closeOnEscape: true,
        minWidth: 150,
        minHeight: 250,
        height: "auto",
        width: "auto"
    };
    dialogProperties = props !== undefined ? props : dialogProperties;
    text = decodeURI(text);
    text = decodeURIComponent(text);
    //text = decode_utf8(decode_utf8(decodeURI(text)));
    $(id).attr("title", title);
    $(".ui-dialog-title").html(title);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + text);
    $(id).dialog(dialogProperties);

}
function addItem() {
    var res;
    var table = $.urlParam('table');
    var name = $("#namedetail").html();
    var first_name = $("#first_namedetail").html();
    var last_name = $("#last_namedetail").html();
    var zipcode = $("#zipcodedetail").html();
    var description = $("#descriptiondetail").html();
    var url = $("#urldetail").html();

    res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
        ' (name,first_name, zipcode,city,street,description,url)VALUES' +
        '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + city + '\',\'' + street + '\',\'' + description + '\',\'' + url + '\');' +
        '');
    document.getElementById("out").innerHTML += JSON.stringify(res) + " done.";
}
function addItem2() {
    var res;
    var table = $.urlParam('db');
    var name = $("#name").val();
    var first_name = $("#first_name").val();
    var last_name = $("#last_name").val();
    var zipcode = $("#zipcode").val();
    var description = $("#description").val();
    var url = $("#url").val();
    $("#conformdialog").attr("title", "Add");
    $("#conformdialog").dialog({
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto",
        modal: true,
        buttons: {
            "Yes": function () {
                res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
                    ' (name,first_name, zipcode,description,url)VALUES' +
                    '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + description + '\',\'' + url + '\');' +
                    '');
                document.getElementById("out_cnt").innerHTML += JSON.stringify(res) + " done.";
                $(this).dialog("close");
            },
            Cancel: function () {
                document.getElementById("out_cnt").innerHTML += JSON.stringify(res) + "Not done.";
                $(this).dialog("close");
            }
        }
    });
}

function updateItem() {
    var table = $.urlParam('table');
    var keyValue = {
        "columns": ["person_id", "name", "first_name", "zipcode", "city", "street", "description", "url"],
        "values": [$.urlParam('iddetail'), $("#namedetail").html(), $("#first_namedetail").html(), $("#zipcodedetail").html(), $("#citydetail").html(), $("#streetdetail").html(), $("#descriptiondetail").html(), $("#urldetail").html()],
    };
    var columns = keyValue.columns;
    var values = keyValue.values;
    model.saveData(dbPath, table, columns, values, function () {
        model.getQuery(dbPath, table, 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC', '#app_cnt');
    });

    document.getElementById("newdbcnt").innerHTML += JSON.stringify(keyValue) + " done.";
}


function deleteItem(id) {
    var table = $.urlParam('table');
    var query = 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC';
    document.getElementById("newdbcnt").innerHTML = 'Realy delete:' + id + " from " + table;
    // var res = model.GetQuery(dbPath, 'DELETE from \'systables\' WHERE person_id = \'' + id + '\';');
    var res = model.deletePerson(dbPath, table, id, function () {
        model.getQuery(dbPath, table, query, '#app_cnt');
    });
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    location.reload();
}
function shortName(v) {
    if (v !== undefined && v.length > 50) {
        return v.substring(0, 50) + "...";
    }
    else {
        return v;
    }
}


function goToTable() {
    var t = $("#database").val();
    window.location = 'list.html?db=' + t;
}

function goToItem() {
    var t = $("#database").val();
    var id = $("#database").val();
    window.location = 'edit.html?db=' + t + '&id=' + id;
}

function openPage(s) {
    window.location = s;
}

function openPage(s) {
    window.open(s);
}

function openAddTable() {
    var t = $.urlParam('db');
    var url = 'edit.html?db=' + t;
    // openDialog("#dialog", url + " #addPage", t, { minWidth: 250, minHeight: 150, width: 400 });
    // getOpenDialog('#dialog', url, 'Install', { minWidth: 250, minHeight: 150, width: 400 });
    getExtFile(url, 'blank', { minWidth: 250, minHeight: 150, width: 400 });
}

function openAddPage() {
    var t = $.urlParam('db');
    var url = 'edit.html?db=' + t;
    window.open(url, '_blank', 'top=500,left=200,frame=true,nodeIntegration=yes, contextIsolation: false,enableRemoteModule: true');
}

function openPage(url, target, props) {
    window.open(url, target, props);
}

function getAppConfig(appConfigFileName) {
    const fs = window.nodeRequire('fs');
    let rawdata = fs.readFileSync(appConfigFileName);
    let appConfig = JSON.parse(rawdata);
    console.log(appConfig);
    return appConfig;
}

function setAppConfig(appConfigFileName, appConfig) {
    let data = JSON.stringify(appConfig, null, 2);
    fs.writeFileSync(appConfigFileName, data);
}

function getFileContent(id, url) {
    $(id).html(get_FileData(url));
    $(id).load(url);
}
function showGetFileContent(id, url) {
    console.log(url);
    $(id).load(url);
    $("html, body").delay(1000).animate({
        scrollTop: $('' + id).offset().top - 100
    }, 300);
}
function loadFileContent(id, url) {
    $(id).load(url);
}
function load_File(url, props) {
    getload_File(url, props);
}
function getload_File(url, props) {
    var prop = props !== undefined ? props : {
        frame: true,
        nodeIntegration: false,
        top: 10,
        left: 200,
        width: 700,
        height: 960
    };
    console.log(prop);
    window.open(url, '_blank', prop);
}

function openBrowser(t) {
    window.nodeRequire("shell").openExternal(t);
}

function openFile(t) {
    window.location = t;
}

function getReadFileWindow(t, id) {
    var childProcess = window.nodeRequire("child_process");
    // This line initiates
    var script_process = childProcess.spawn(t, [], { env: process.env });
    // Echoes any command output
    script_process.stdout.on('data', function (data) {
        console.log('stdout: ' + data);
        document.getElementById(id).innerHTML = data;

    });
    // Error output
    script_process.stderr.on('data', function (data) {
        document.getElementById(id).innerHTML = 'stderr: ' + data;
        console.log('stderr: ' + data);

    });
    // Process exit
    script_process.on('close', function (code) {
        console.log('child process exited with code ' + code);
    });
}

function getLocalFile(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');

    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);
}

function readLocalFile(url) {
    return readFileSync(url)
}
function showDir(text, id) {
    const fs = window.nodeRequire('fs');
    fs.readdir(text, (err, files) => {
        if (err)
            console.log(err);
        else {
            document.getElementById(id).innerHTML = "";

            files.map(function (file) {
                //return file or folder path, such as **MyFolder/SomeFile.txt**
                return path.join(text, file);
            }).filter(function (file) {
                //use sync judge method. The file will add next files array if the file is directory, or not. 
                return fs.statSync(file).isDirectory();
            }).forEach(function (file) {
                //console.log("%s", files);
                document.getElementById(id).innerHTML += "<input onclick=\"if(getConfirmation('Start task '+document.getElementById('inputKey').value+' now?')){showDir('\'" + document.getElementById('inputKey').value + "\\" + file + "\'', 'pluginresult')};\" class=\"btn btn-default\" value=\"" + id + "\"></input>";
                // files.forEach(file => {
                //     document.getElementById(id).innerHTML += "<a onclick=\"if(getConfirmation('Start task '+document.getElementById('inputKey').value+' now?')){execCMD('\'" + document.getElementById('inputKey').value + "\\" + file + "\'', 'pluginresult')};\">" + id + "x</div>";
                // })

            });

            // files.forEach(file => { })
        }
    })
}
function execCMD(text, id, isAppended, isScrolling) {
    const {
        exec
    } = window.nodeRequire('child_process');
    isAppended = isAppended == true ? true : false;
    isScrolling = isScrolling == false ? false : true;
    if (isAppended != true) {
        document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    }
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        //console.log('OUT:' + stdout);        
        if (isAppended == true) {
            $('#' + id).append(stdout);
        }
        else {
            $('#' + id).html(stdout);
        }
        if (isScrolling == true) {
            $("html, body").delay(1000).animate({
                scrollTop: $('#' + id).offset().top
            }, 300);
        }
    });
}
function execFile(file, id, params) {
    var param = "\n" + params.toString().replace() + "\n";
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec("\"" + file + "\"", (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        //console.log('OUT:' + stdout);
        //console.log('id:' + id);
        document.getElementById(id).innerHTML = stdout;

        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
function execJava(cls, text, id) {
    switch (cls) {
        case "dir":
            cls = "call java -jar org.letztechance.domain.api.IO-0.0.1-SNAPSHOT.jar -DIR "
            break;
        case "files":
            cls = "call java -jar org.letztechance.domain.api.IO-0.0.1-SNAPSHOT.jar -FILES "
            break;
        case "allfiles":
            cls = "call java -jar org.letztechance.domain.api.IO-0.0.1-SNAPSHOT.jar -ALL "
            break;

        default:
            cls = "call java -version"
            break;
    }
    text = cls + "\"" + text + "\"";
    console.log(text);
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        //console.log('OUT:' + stdout);
        //console.log('id:' + id);
        var temp = stdout.split("\n");
        document.getElementById(id).innerHTML = temp;

        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
/**
 * '.\\resources\\plugins\\LC2DEBanksUpdater\\install.html'
 * @param {*} text 
 * @param {*} id 
 */
function execPluginCMD(id, url) {
    try {
        var screenWidth = window.width > 639 ? 640 : 480;
        screenWidth = window.width < 479 ? 320 : screenWidth;
        console.log(screenWidth + " Real size:" + window.screen.width)
        getOpenDialog('#' + id, '.\\resources\\plugins\\' + url + '\\index.html', '' + url, { title: url, minWidth: 250, minHeight: 150, width: screenWidth });
        $(id).attr("title", url);
        pluginINIT(url);
    } catch (error) {
        console.error(error);
        console.error(error.stack);
    }
}
function extExecCMD(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    text = decode_utf8(text);
    text = text.split("\\").join("\\\\");

    // alert('OUT:'+text.length);
    exec('\"' + text + "\"", (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log('OUT:' + stdout);
        document.getElementById(id).innerHTML = stdout;
        $("html, body").delay(1000).animate({
            scrollTop: $('#' + id).offset().top
        }, 3000);
    });
}
function execPluginCMDList(pluginName, id) {
    var result = "";
    var res = getSQLQuery("select * from " + pluginName + "", "resources\\" + pluginName + ".db");
    // console.log(JSON.stringify(res));
    result += "<ul class=\"listul\">";
    for (var v in res) {
        // result += "<li onclick=\""+res[v]["url"]+"\">";
        result += "<li  class=\"" + res[v]["zipcode"] + "\">";
        //result += "<a href=\"javascript:"+res[v]["url"]+"\" onclick=\""+res[v]["url"]+"\">";
        result += "<a onclick=\"" + res[v]["url"] + "\">";
        result += res[v]["name"];
        result += "</a>";
        result += "</li>";
    }
    result += "</ul>";
    $(id).html(result);
    $("html, body").delay(100).animate({
        scrollTop: $('' + id).offset().top
    }, 30);
}
function getExecPluginCMDList(pluginName, table, id, isAppend) {
    var result = "";
    var res = getSQLQuery("select * from " + table + "", "resources\\" + pluginName + ".db");
    result += "<ul class=\"listul\">";
    for (var v in res) {
        result += "<li  class=\"" + res[v]["street"] + "\">";
        result += "<a onclick=\"" + res[v]["url"] + "\">";
        result += res[v]["name"];
        result += "</a>";
        result += "</li>";
    }
    result += "</ul>";
    if (isAppend) {
        $(id).append(result);
    }
    else {
        $(id).html(result);
    }
}
function execPluginCMDTableList(pluginName, table, id, isAppended) {
    var result = "";
    isAppended = isAppended == true ? true : false;
    var res = getSQLQuery("select * from " + table + "", "resources\\" + pluginName + ".db");
    // console.log(JSON.stringify(res));
    result += "<ul class=\"listul\">";
    for (var v in res) {
        result += "<li  class=\"" + res[v]["street"] + "\">";
        result += "<a onclick=\"" + res[v]["url"] + "\">";
        result += res[v]["name"];
        result += "</a>";
        result += "</li>";
    }
    result += "</ul>";
    if (isAppended == true) {
        $(id).append(result);
    }
    else {
        $(id).html(result);
    }
}
function exec_FileList(pluginName, table, id, isAppended) {
    var result = "";
    isAppended = isAppended == true ? true : false;
    var res = getSQLQuery("select * from " + table + "", "resources\\" + pluginName + ".db");
    // console.log(JSON.stringify(res));
    result += "<ul class=\"listul\">";
    for (var v in res) {
        result += "<li  class=\"" + res[v]["zipcode"] + "\">";
        // result += "<a onclick=\"execCMD('" + res[v]["url"] + "',''+id);\">";
        result += "<a onclick=\"if(getConfirmation('Start " + res[v]["url"] + "?')){execCMD('" + res[v]["url"] + "', 'pout')};\">";
        result += res[v]["name"];
        result += "</a>";
        result += "</li>";
    }
    result += "</ul>";
    if (isAppended == true) {
        $(id).append(result);
    }
    else {
        $(id).html(result);
    }
}
function execPlugin(text, id) {
    execlugin(text, id);
    if (pluginINIT !== undefined) {
        pluginINIT();
    }
}
function execJavaItem(x, id) {
    const dirFlag = "isDir";
    const fileFlag = "isFile";
    var result;
    var t = x.split(";");
    var file = t[0];
    var df = t[1] !== undefined ? (t[1]).trim() : undefined;
    console.log("+" + df + "+");
    //var isDir = (df !== undefined && df == "isDir")? true : false;
    var isDir = (df != fileFlag && df == dirFlag) ? true : false;
    file = file.replace(/\\/g, '\\\\');
    console.log(file + " DirFlag:" + df + " isDir:" + isDir);
    result = "<a onclick=\"execCMD('type " + file + "','" + id + "')\">" + file + "</a><br/>";
    if (isDir) {
        result = "<a onclick=\"execJava('allfiles','" + file + "','pluginresult',execJavaItem)\">" + file + "</a><br/>";
    }
    return result;
}
function evalCMD(text) {
    const {
        exec
    } = window.nodeRequire('child_process');
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            return;
        }
        // console.log('OUT:' + stdout);
        // document.getElementById(id).innerHTML = stdout;
        try {
            eval(stdout);
        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    });
}

function openBrowser(url) {
    openBrowser(url, false);
}

function openBrowser(url, isOpen) {
    if (isOpen) {
        window.nodeRequire("electron").shell.openExternal("https://www.letztechance.org/openlink?" + url);
    } else {
        window.nodeRequire("electron").shell.openExternal(url);
    }
}

function getExtFile(url, target, props) {
    // window.open(url, '_blank', 'top=500,left=200,frame=false,nodeIntegration=no');
    console.log('open:' + url);
    window.open(url, target, props);
}

function getFile(url, target, props) {
    const childWindow = window.open(url, '_blank');
    // childWindow.document.write('<h1>Hello</h1>');
    childWindow.document.write('<h1>Hello</h1>');
}

function get_FileData(url) {
    return readFileSync(url);
}

function getLocalFile(url, props) {
    var props = props !== undefined ? props : { width: 800, height: 600 };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);

}

function loadFile(url, props) {
    var prop = props !== undefined ? props : {
        width: 800,
        height: 600
    };

    // const electron = window.nodeRequire('electron');
    // app.whenReady().then(() => {
    // protocol.handle('atom', (request) =>
    //   net.fetch('file://' + request.url.slice('atom://'.length)))
    setTimeout(() => {
        const { app, electron, protocol, net } = window.nodeRequire('electron');
        const BrowserWindow = electron.remote.BrowserWindow;
        const path = window.nodeRequire('path');
        const childWindow = new BrowserWindow(prop);
        childWindow.loadURL(url);

    }, 2000);
    //   })

    // childWindow.readFile(get_FileData(path.join(url)));

}

function getTextWindow(t, props) {
    var prop = props !== undefined ? props : {
        width: 800,
        height: 600
    };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    // childWindow.loadFileContent("file://" + __dirname + "/" + url);
    childWindow.loadURL('data:text/html;charset=utf-8,' + get_FileData(path.join(t)));
}

function openDialog(id, f, title, props) {
    var prop = props !== undefined ? prop : {
        // appendTo: "#dialog",
        title: title,
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto"
    };
    $(function () {
        $(id).attr("title", title);
        $(id).dialog(prop);
        console.log(f);
        $(id + "cnt").load(f);
    });
}

function getOpenDialog(id, f, title, props) {
    var pluginName = title;
    // $.noConflict();
    dialogProperties = props !== undefined ? props : dialogProperties;
    var res = get_FileData(path.join(f));
    $(id).attr("title", title);
    console.log(title + " file:" + f);
    // alert(title +" file:"+f);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + res);
    $(id).dialog(dialogProperties);
}

function getOpenDialogText(id, t, title, props) {
    // $.noConflict();
    dialogProperties = props !== undefined ? props : dialogProperties;
    $(id).attr("title", title);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + t);
    $(id).dialog(dialogProperties);
}
function getConfirmation(title) {
    return confirm(title);
}
function getShowConfirmDialog(id, message, title, props, callback) {
    if (ConfirmDialog(id, message, title, props)) {
        alert('Thanks for confirming');
        callback;
    } else {
        alert('Why did you press cancel? You should have confirmed');
    }
}
function show_ConfirmDialog(id, message, title, props, callback) {
    var isDialogValid = false;
    $('<div></div>').appendTo(id)
        .html('<div><h6>' + message + '?</h6></div>')
        .dialog({
            modal: true,
            title: title,
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Yes: function () {
                    // $(obj).removeAttr('onclick');                                
                    // $(obj).parents('.Parent').remove();

                    $('body').append('<h1>Confirm Dialog Result: <i>Yes</i></h1>');
                    //{alert('taskkill /f /PID %%b','menu_cnt');}else{alert('Bye');}                
                    isDialogValid = true;
                    $(this).dialog("close");
                    $(this).data("callback")(true);
                    // processDialogResult(true, callback);

                },
                No: function () {
                    $('body').append('<h1>Confirm Dialog Result: <i>No</i></h1>');
                    $(this).dialog("close");
                    $(this).data("callback")(false);
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
};
function processDialogResult(result, callback) {
    if (isDialogValid) {
        callback;
    }
    else {
        alert('Cancelled.');
    }
}
function SimpleConfirmDialog(id, message, title, props, callback) {
    $('<div></div>').appendTo(id)
        .html('<div><h6>' + message + '?</h6></div>')
        .dialog({
            modal: true,
            title: title,
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Yes: function () {
                    // $(obj).removeAttr('onclick');                                
                    // $(obj).parents('.Parent').remove();

                    $('body').append('<h1>Confirm Dialog Result: <i>Yes</i></h1>');
                    //{alert('taskkill /f /PID %%b','menu_cnt');}else{alert('Bye');}
                    // callback;
                    $(this).dialog("close");

                },
                No: function () {
                    $('body').append('<h1>Confirm Dialog Result: <i>No</i></h1>');

                    $(this).dialog("close");
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
};
function conFirmDialog(id, title, props) {
    var isValid = false;
    dialogProperties.buttons = {
        "Yes": function () {
            isValid = true;
            $(this).dialog("close");
        },
        Cancel: function () {
            $(this).dialog("close");
        }
    };
    dialogProperties = props !== undefined ? props : dialogProperties;
    // $(function() {
    $(id).attr("title", title);
    // alert(title);
    //$(id).dialog(dialogProperties);
    $(id).dialog({
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto",
        modal: true,
        buttons: {
            "Yes": function () {
                isValid = true;
                return isValid;
                $(this).dialog("close");
            },
            Cancel: function () {
                $(this).dialog("close");
            }
        }
    });
    // // });
    // return isValid;
}
// import { xsltProcess, xmlParse } from 'xslt-processor'
function getXsltFileProcess(source, target) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    const xmlString = _readFile(source, { encoding: 'utf8', flag: 'r' });
    const xsltString = _readFile(target, { encoding: 'utf8', flag: 'r' });
    return getXsltProcess(xmlString, xsltString);
}

function getXsltProcess(xmlString, xsltString) {
    const { xsltProcess, xmlParse } = window.nodeRequire('xslt-processor');
    return outXmlString = xsltProcess(
        xmlParse(xmlString),
        xmlParse(xsltString)
    );
}
function getXML(source, target, id, isAppend) {
    var outXmlString = "";
    try {
        outXmlString = getXsltFileProcess(source, target);
        if (isAppend) {
            document.getElementById(id).innerHTML += outXmlString;
        }
        else {
            document.getElementById(id).innerHTML = outXmlString;
        }
    } catch (e) {
        console.error(e);
        console.error(e.stack);
    }
    $("html, body").delay(100).animate({
        scrollTop: $('#' + id).offset().top
    }, 30);

}
function getJSON_CR(url, urlext, isAsync, dataType, callBack) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            method: 'POST',
            url: url,
            data: {
                // url where our server will send request which can't be done by AJAX
                'ext_url': urlext
            },
            success: function (data) {
                // try {
                //     // var $h1 = $(data).find('h1').html();
                //     // $('h1').val($h1);
                // } catch (error) {
                //     console.error(error);
                //     console.error(error.stack);
                // }
                //$('#cnt').html(data);
                resolve(data);
            },
            error: function () {
                console.log('Error');
                reject('Error');
            }
        });
    });
}
function _readFile(source, prop) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    return fs.readFileSync(source, { encoding: 'utf8', flag: 'r' });

}
function toBase(file) {
    functione
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.toString().substr(reader.result.toString().indexOf(',') + 1));
        reader.onerror = error => reject(error);
    });
}
//'#files > input[type="file"]'
function getToBase(selector, id) {
    file = document.querySelector(selector).files[0]
    getFile(file).then((customJsonFile) => {
        console.log(customJsonFile);
        $(id).html(JSON.stringify(customJsonFile));
    });
}
function getFiles(files) {
    return Promise.all(files.map(getFile));
}
function getFile(file) {
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
        reader.onerror = () => { reader.abort(); reject(new Error("Error parsing file")); }
        reader.onload = function () {
            //This will result in an array that will be recognized by C#.NET WebApi as a byte[]
            let bytes = Array.from(new Uint8Array(this.result));

            //if you want the base64encoded file you would use the below line:
            let base64StringFile = btoa(bytes.map((item) => String.fromCharCode(item)).join(""));

            //Resolve the promise with your custom file structure
            resolve({
                bytes,
                base64StringFile,
                fileName: file.name,
                fileType: file.type
            });
        }
        if (file !== undefined) {
            reader.readAsArrayBuffer(file);
        }
        else {
            alert("Please choose a file first and retry.");
        }
    });
}
function getBase64ToFile(file) {
    return atob(file);
}


//
function createDir(dir, id) {
    const fs = window.nodeRequire('fs');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
        document.getElementById(id).innerHTML += dir + "created.<br>";
    }
}

function do_Unzip(link, target, id) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    target = path.join(target);
    link = path.join(link);
    if (link.includes(".zip")) {
        document.getElementById(id).innerHTML += '<br><h4>Extracting:</h4><p>' + link + ' to:' + target + '</p>';
        try {
            console.log('extract ' + link + ' \"' + target + '\"');
            execCMD('extract ' + link + ' "' + target + '"', 'modcnt');
        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    } else {
        document.getElementById(id).innerHTML += '<p> ' + link + ' <strong>NOT</strong> extracted to:' + target + '</p>';
    }
    document.getElementById(id).innerHTML += '<hr><strong>DONE</strong>';
    console.log('Extraction complete')

}
function Install_Mod(tmpDir, id) {
    Install_Modules(corelibs, tmpDir, id);
}
function InstallMod(corelibs, tmpDir, id) {
    Install_Modules(corelibs, tmpDir, id);
}
function Install_Modules(libs, tmpDir, id) {
    try {
        $('#' + id).html('<h1>Loading modules...</h1>');
        const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
        npmInstallAsync(libs, tmpDir)
            .then(function (data) {
                $('#' + id).append('<h1>Successfully Installed to:</h1>' + tmpDir + '<br><h2>Done. Close window now and start main plugin.</h2><textarea>' + JSON.stringify(data) + '</textarea>');
            });
        printDir(path.join(tmpDir, 'node_modules'), id);
    } catch (error) {
        alert(error);
        document.getElementById(id).innerHTML += '<h2>ERROR:</h2>' + error;
    }
}
function getDownloads(links, target) {
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file, target);
    }
}

function getDownloadFile(baseUrl, link, targetFile, target) {
    get_DownloadFile(baseUrl, link, targetFile, target, "out_cnt");
}

function get_DownloadFile(baseUrl, link, targetFile, target, id) {
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });
    var out = fs.createWriteStream(targetFile);
    req.pipe(out);
    req.on('response', function (data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });
    req.on('data', function (chunk) {
        // Update the received bytes
        received_bytes += chunk.length;
        // showProgress(id, received_bytes, total_bytes);
    });
    req.on('end', function () {
        // alert("File succesfully downloaded");
        document.getElementById(id).innerHTML += "<br>" + url + " File succesfully downloaded";
        document.getElementById(id).innerHTML += "<br>" + targetFile + " File succesfully written.";
        document.getElementById(id).innerHTML += "<br>Path:" + target + ".";
        document.getElementById(id).innerHTML += "<br>Link:" + link + ".";
        if (('' + targetFile).includes(".zip")) {
            do_Unzip(targetFile, target, id);
            document.getElementById(id).innerHTML += "<br>Unzip:" + targetFile + ".";
        }
    });
}

function showProgress(id, received, total) {
    try {
        console.log("ID:" + id);
        var percentage = (received * 100) / total;
        console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
        //document.getElementById(id).innerHTML += percentage + "% | " + received + " bytes out of " + total + " bytes.";
        document.getElementById(id + "_progress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
    } catch (error) {
        console.err(error);
        console.err(error.stack);

    }

}
function getHeader(page) {
    var result = "<div id=\"cm-menu\">";
    result += "<nav id=\"top\" class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"cm-flex\"><a href=\"index.html\" class=\"cm-logo\"></a></div> ";
    result += "<div class=\"btn btn-primary md-menu-white lc-header\" data-toggle=\"cm-menu\" id=\"cm-menu\"></div> ";
    result += "</nav>";

    result += "<div id=\"ctop\"></div>";

    result += "<div id=\"cm-menu-content\"> ";
    result += "<div id=\"cm-menu-items-wrapper\"> ";
    result += "<div id=\"cm-menu-scroller\"> ";
    result += "<ul class=\"cm-menu-items\"> ";

    result += "<li class=\"cm_submenu\"><a href=\"index.html\">Application</a></li> ";
    result += "<li ><a href=\"index.html\">Application</a></li> ";
    // result += "<li ><a href=\"index.html\">Application</a></li> ";
    result += "</ul> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += " <header id=\"cm-header\"> ";
    result += " <nav class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"btn btn-primary md-menu-white hidden-md hidden-lg lc-header\" data-toggle=\"cm-menu\">";
    result += "</div> ";
    result += " <div class=\"cm-flex\"> ";
    result += " <div class=\"cm-breadcrumb-container\"> ";
    // result += " <ol class=\"breadcrumb\"> ";
    // result += " <li><a href=\"index.html\">" + msg('indexpage') + "</a></li> ";
    // result += " <li><a href=\"start.html\" class=\"active\">" + msg('startpage') + "</a></li> ";
    // result += " </ol> ";
    result += "</div> ";
    result += "<form id=\"cm-search\" action=\"" + page.host + "\" method=\"get\"> ";
    result += "<input type=\"search\" id=\"btnquery\" name=\"query\" autocomplete=\"on\" placeholder=\"" + msg('search') + "\"> ";
    result += "<input type=\"hidden\" name=\"q\" value=\"search\">";

    result += "</form> ";
    result += "</div> ";

    result += "</ul> ";

    result += "</div> ";
    result += "</nav> ";
    result += "</header> ";
    return result;
}
//Java
//getJavaClass("SumOfNumbers",[3,1, 2, 3]);
function printJavaResult(text) {
    const { JavaCaller, JavaCallerCli } = window.nodeRequire("java-caller");
    const spawn = window.nodeRequire("child_process").spawn;
    var java = window.nodeRequire('java');
    var javaLangSystem = java.import('java.lang.System');
    javaLangSystem.out.printlnSync(text);
}
function getJavaClass(className, params, id) {
    let result = "";
    let args = [];
    args.push(className); // remove first argument
    // Push the numbers other arguments
    params.forEach((element) => {
        args.push(element);
    });

    // Starting our worker
    console.log("Starting work");
    let spawn = getSpawn();
    let worker = spawn("java", args);
    console.log('Java Args:' + JSON.stringify(args));
    printJavaWorker(worker, id);
}

function getSpawn() {
    return window.nodeRequire("child_process").spawn;
}
function printJavaWorker(worker, id) {
    let result = "";
    // let worker = spawn("java", args);
    worker.stdout.on("data", function (data) {
        console.log("response: " + data);
        // $("#app_cnt").append("<h1>Data:"+data+"</h1>");
        // result += "<h1>Data:"+data+"</h1>";
        result += "" + data + "";
    });
    worker.on("close", function (code, signal) {
        console.log("Java finished with exit code of " + code);
        // $("#app_cnt").append("Code:"+code);
        // result += "<p>process returncode:"+code+"</p>";
        $("" + id).html(result);
    });

}
function getPluginButtons(pluginName) {
    return getPluginReloadButton(pluginName) + getPluginInstallRequirementsButton(pluginName);

}
function getPluginReloadButton(pluginName) {
    return "<input type=\"button\" value=\"reload\" class=\"btn btn-info\" onclick=\"execPluginCMD('out','" + pluginName + "');\"/>";

}
function getPluginInstallRequirementsButton(pluginName) {
    return "<input type=\"button\" value=\"Run requirement installation\" class=\"btn btn-warning\" onclick=\"getOpenDialog('#dialog','.\\\\resources\\\\plugins\\\\" + pluginName + "\\\\install.html','Install',{ minWidth: 250,  minHeight: 150, width: 400});\"/>";
}
function getInstallModulesButton(pluginName) {
    return "<input type=\"button\" value=\"Run requirement installation\" class=\"btn btn-warning\" onclick=\"Install_Mod(resDir,'modcnt');\"/>";
}
async function printDrives(id) {
    // const drivelist = window.nodeRequire('electron-drivelist');
    const drivelist = window.nodeRequire('drivelist');
    const drives = await drivelist.list();
    console.log(drives);
}
function printDir(dir_path, id) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function (err, files) {
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        files.forEach(function (file) {
            try {
                var isValid = false;
                console.log('File:' + file);
                document.getElementById(id).innerHTML += "<br>" + file;
                for (v in corelibs) {
                    if (file.includes(v)) {
                        isValid = true;
                    }
                }
                if (isValid) {
                    document.getElementById(id).innerHTML += "<br>" + file + " <strong>found</strong>.";
                }
            } catch (error) {
                console.error(error);
            }

        });
    });
}
function printDirectory(p, id, isAppend) {
    var result = "<fieldset class=\"\">";
    const fs = window.nodeRequire('fs');
    const path = window.nodeRequire('path');
    const filenames = fs.readdirSync(p);
    var cwd = path.resolve(p);
    var pcwd = path.resolve(path.join(p, '..')).replaceAll('\\', '\\\\');
    result += "<legend>" + cwd + "</legend>";
    result += "<div id=\"fileout\"></div>";
    result += "<ul class=\"listul\">";

    result += "<li class=\"btn\">";
    result += "<br><a onclick=\"printDirectory('" + pcwd + "','" + id + "')\" class=\"\">..<strong>(directory)</strong></a>";
    result += "</li>";
    filenames.map((filename) => {
        // console.log(filename);
        try {
            if (fs.lstatSync(path.join(p, filename)).isDirectory()) {
                var f = path.join(p, filename).replaceAll('\\', '\\\\');
                result += "<li class=\"btn\">";
                result += "<br><a onclick=\"printDirectory('" + f + "','" + id + "')\" class=\"\">" + filename + "&nbsp;<strong>(directory)</strong></a>";
                result += "</li>";
            }
        } catch (error) {
            console.error(error);
        }

    })
    filenames.map((filename) => {
        // console.log(filename);
        try {
            if (!fs.lstatSync(path.join(cwd, filename)).isDirectory()) {
                result += "<li class=\"btn\">";
                // result += "<br><strong><a onclick=\"showFile('" + p + "','" + filename + "','fileout')\" class=\"\">" + filename + "</a></strong>";
                result += getFileLink(cwd, filename, id);
                result += "</li>";
            }
        } catch (error) {
            console.error(error);
        }
    })
    result += "</ul>";
    result += "</fieldset>";
    if (isAppend) {
        $('#' + id).append(result);
    }
    else {
        $('#' + id).html(result);
    }
}
function getFileExtension(filename) {
    const extension = filename.split('.').pop();
    return extension;
}
function getFileLink(p, file, id) {
    var result = "";
    // const path = window.nodeRequire('path');
    var fileName = path.join(p, file).replaceAll('\\', '\\\\');
    var fileExt = getFileExtension(file);
    switch (fileExt) {
        case 'exe':
            result = "<a onclick=\"execCMD('" + fileName + "','fileout');\" class=\"btn\">" + file + "</a>";
            break;
        case 'bat':
            result = "<a onclick=\"execCMD('" + fileName + "','fileout');\" class=\"btn\">" + file + "</a>";
            break;
        case 'xml':
            result = "<a onclick=\"showGetFileContent('#fileout','" + fileName + "');\" class=\"btn\">" + file + "</a>";
            break;

        default:
            result = "<a onclick=\"showGetFileContent('#fileout','" + fileName + "');\" class=\"btn\">" + file + "</a>";
            break;
    }
    return result;

}

function showDB(s, isConfirm) {
    if (isConfirm) {
        if (getConfirmation('Show DB now?')) { switchListDBLocation(s) };
    }
    else {
        switchListDBLocation(s);
    }
}
function switchListDBLocation(s) {
    window.location = 'list.html?db=' + s + '&table=' + s;
}
function syncCopy(source, destination) {
    var files = [];
    //var targetFolder = path.join( destination, path.basename( source ) );
    var targetFolder = destination;
    if (!fs.existsSync(targetFolder)) {
        fs.mkdirSync(targetFolder);
    }
    // Copy
    if (fs.lstatSync(source).isDirectory()) {
        files = fs.readdirSync(source);
        files.forEach(function (file) {
            var curSource = path.join(source, file);

            if (fs.lstatSync(curSource).isDirectory()) {
                fs.copyFolderRecursiveSync(curSource, targetFolder);
            } else {
                fs.copyFileSync(curSource, targetFolder + file);
            }
        });
    }
};
//
function getFullIndexList(id, api, apiext) {
    // var api = 'https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=';
    console.log("get list by" + api);
    try {
        var p1 = getJSON_CR(api, apiext, 'GET', true, 'jsonp');
        // jQuery('#outcnt').html('Reading' + api);
        p1.then(function (data) {
            try {
                var oJson = JSON.parse(data, false);
                var result = "";
                for (var i = 0; i < oJson.list.length; i++) {
                    var counter = oJson.list[i];
                    result += '<option value="' + counter.name + '">' + counter.id + '</option>';
                }
                // $('#tableId').append(result);
                $(id).append(result);
            } catch (e) {
                $('#error').before('Error:<hr>' + e.stack);
                $('#error').before(e);
            }
        });
    } catch (e) {
        $('#error').before('Error:<hr>' + e.stack);
        $('#error').before(e);
    }
    console.log("List done");
}

function doDownload(links, target, id) {
    id = id !== undefined ? id : "appcnt";
    console.log("Target:" + target);
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file, id);
        // downloadAppBinaries(links[v].path, links[v].file, target);
        // bulkDownloadAppBinaries(links, target);
    }
}


function getDownloadFile(baseUrl, link, target, id) {
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    // Save variable to know progress
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });

    var out = fs.createWriteStream(target);
    req.pipe(out);

    req.on('response', function (data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });

    req.on('data', function (chunk) {
        // Update the received bytes
        received_bytes += chunk.length;

        showDLProgress(received_bytes, total_bytes, id);
    });

    req.on('end', function () {
        // alert("File succesfully downloaded");
        document.getElementById("" + id).innerHTML += "<br>" + url + "File succesfully downloaded";
        // doUnzip(target + link, target);
    });
}

function showDLProgress(received, total, id) {
    var percentage = (received * 100) / total;
    console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
    document.getElementById(id + "progress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
}
function handleFileUpload(id, files) {
    foreach(file in files)
    $(id).val(file);
}
function handle_FileUpload(obj, files) {
    for (var i = 0; i < files.length; i++) {
        var fd = new FormData();
        fd.append('file', files[i]);
        var status = new createStatusbar(obj); //Using this we can set progress.
        status.setFileNameSize(files[i].name, files[i].size);
        sendFileToServer(id, fd, status);

    }
}
//var rowCount=0;
function createStatusbar(obj) {
    rowCount++;
    var row = "odd";
    if (rowCount % 2 == 0) row = "even";
    this.statusbar = $("<div class='statusbar " + row + "'></div>");
    this.filename = $("<div class='filename'></div>").appendTo(this.statusbar);
    this.size = $("<div class='filesize'></div>").appendTo(this.statusbar);
    this.progressBar = $("<div class='progressBar'><div></div></div>").appendTo(this.statusbar);
    this.abort = $("<div class='abort'>Abort</div>").appendTo(this.statusbar);
    obj.after(this.statusbar);

    this.setFileNameSize = function (name, size) {
        var sizeStr = "";
        var sizeKB = size / 1024;
        if (parseInt(sizeKB) > 1024) {
            var sizeMB = sizeKB / 1024;
            sizeStr = sizeMB.toFixed(2) + " MB";
        }
        else {
            sizeStr = sizeKB.toFixed(2) + " KB";
        }

        this.filename.html(name);
        this.size.html(sizeStr);
    }
    this.setProgress = function (progress) {
        var progressBarWidth = progress * this.progressBar.width() / 100;
        this.progressBar.find('div').animate({ width: progressBarWidth }, 10).html(progress + "% ");
        if (parseInt(progress) >= 100) {
            this.abort.hide();
        }
    }
    this.setAbort = function (jqxhr) {
        var sb = this.statusbar;
        this.abort.click(function () {
            jqxhr.abort();
            sb.hide();
        });
    }
}
function sendFileToServer(id, formData, status) {
    var uploadURL = "https://hayageek.com/examples/jquery/drag-drop-file-upload/upload.php"; //Upload URL
    var extraData = {}; //Extra Data.
    var jqXHR = $.ajax({
        xhr: function () {
            var xhrobj = $.ajaxSettings.xhr();
            if (xhrobj.upload) {
                xhrobj.upload.addEventListener('progress', function (event) {
                    var percent = 0;
                    var position = event.loaded || event.position;
                    var total = event.total;
                    if (event.lengthComputable) {
                        percent = Math.ceil(position / total * 100);
                    }
                    //Set progress
                    status.setProgress(percent);
                }, false);
            }
            return xhrobj;
        },
        url: uploadURL,
        type: "POST",
        contentType: false,
        processData: false,
        cache: false,
        data: formData,
        success: function (data) {
            status.setProgress(100);

            //$("#status1").append("File upload Done<br>");           
        }
    });

    status.setAbort(jqXHR);
}
function exec_File(file, id) {
    var result = "";
    var fileExt = getFileExtension(file);
    var fileName = file.substring(file.lastIndexOf('\\') + 1);
    var onlyPath = window.nodeRequire('path').dirname(file);
    var out = $('#' + id);
    out.html('Loading ' + file + ' id:' + id + ' Path:' + onlyPath);
    console.log('Loading ' + file + ' id:' + id + ' Path:' + onlyPath);
    switch (fileExt) {
        case 'exe':
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            execCMD('start ' + file, id);
            break;
        case 'bat':
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            execCMD('call ' + file, id);
            break;
        case 'xml':
            result = "<a onclick=\"showGetFileContent('#fileout','" + file + "');\" class=\"btn\">" + file + "</a>";
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            execCMD('type ' + file, id);
            execCMD('mvn  -f "' + file + '" install', id);
            break;
        case 'java':
            result = "<a onclick=\"showGetFileContent('#fileout','" + file + "');\" class=\"btn\">" + file + "</a>";
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            onlyPath = window.nodeRequire('path').dirname(file);
            out.append('java ' + fileName + ' Path:' + onlyPath);
            console.log('class ' + file + ' id:' + id + ' Path:' + onlyPath);
            execCMD('javac -d "' + onlyPath + '" "' + file + '"|java ' + fileName.replaceAll('.java', ''), id);
            // execCMD('cd "'+onlyPath+'"|java ' + fileName.replace('.java',''), id,true);
            break;
        case 'class':
            result = "<a onclick=\"showGetFileContent('#fileout','" + file + "');\" class=\"btn\">" + file + "</a>";
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            // onlyPath = window.nodeRequire('path').dirname(file);
            out.append('class ' + fileName + ' Path:' + onlyPath);
            console.log('class ' + file + ' id:' + id + ' Path:' + onlyPath);
            console.log('java ' + (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'));
            execCMD('cd "' + onlyPath, id);
            execCMD('set CLASSPATH=%CLASSPATH%;' + onlyPath + ';.', id);
            execCMD('java ' + (onlyPath + '\\').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'), id);
            break;
        case 'maven':
            result = "<a onclick=\"showGetFileContent('#fileout','" + file + "');\" class=\"btn\">" + file + "</a>";
            result = "<a onclick=\"execCMD('" + file + "','fileout');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            // onlyPath = window.nodeRequire('path').dirname(file);
            out.append('class ' + fileName + ' Path:' + onlyPath);
            console.log('class ' + file + ' id:' + id + ' Path:' + onlyPath);
            console.log('java ' + (onlyPath + '\\').replaceAll('c:', '').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'));
            //execCMD('java ' + (onlyPath + '\\').replaceAll('\\', '.') + fileName.replaceAll('.class', '').replace('\\', '.'), id);
            execCMD('mvn  -f "' + file + '" install', id);
            break;



        default:
            result = "<a onclick=\"showGetFileContent('#fileout','" + fileName + "');\" class=\"btn\">" + file + "</a>";
            out.append('<hr>' + result);
            if (!target.includes(".mp4") && !target.includes(".m4")) {
                execCMD('type \"' + file + '\"', id);
            }
            break;
    }
}
var doDrop_file = (function () {
    return function read_Drop_File(f) {
        //var f = files[0];
        var reader = new FileReader();
        try {
            reader.onload = function (e) {
                var data = e.target.result;
                data = new Uint8Array(data);
                try {
                    // process_wb(XLSX.read(data, {
                    //     type: 'array'
                    // }));
                    console.log(data);
                } catch (e) {
                    console.error(e.stack);
                }

            };
        } catch (e) {
            console.error(e.stack);
        }
        reader.readAsArrayBuffer(f);
    };
})();
function setDragOver(id, target) {
    try {
        //electron = window.nodeRequire('electron');
        var drop = document.getElementById(id);
        var drop2 = $('#' + id);
        drop2.html('Loading ' + id);
        console.log('setDragOver ' + id);
        drop2.css('border', '10px solid #0185A1');
        document.addEventListener('' + id, (event) => {
            event.preventDefault();
            event.stopPropagation();
            for (const f of event.dataTransfer.files) {
                // Using the path attribute to get absolute file path
                console.log('File Path of dragged files: ', f.path);
                drop2.append('Loading ' + f.path);
            }
        });

        document.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log()
        });

        document.addEventListener('dragenter', (event) => {
            // console.log('enter'+id);
            drop2.html('enter ' + id);
        });

        document.addEventListener('dragleave', (event) => {
            // console.log('left '+id);
            drop2.html('drop a file');
        });

        document.addEventListener('drop', (event) => {
            console.log('drop' + id);
            for (const f of event.dataTransfer.files) {
                // Using the path attribute to get absolute file path
                console.log('File Path of dragged files: ', f.path);
                drop2.append('Loading ' + f.path);
                $('#inputFile').val(f.path);
                if (!target.includes(".mp4") && !target.includes(".m4")) {
                    execCMD('type ' + f.path, '' + target);
                }
                exec_File('' + f.path, '' + target);
                // handleFileUpload(id, f);
                //handle_FileUpload(obj, f);

            }

        });
    } catch (error) {
        console.error(error);
        console.error(error.stack);
    }
}
// function handleDrop(e) {
//     e.stopPropagation();
//     e.preventDefault();
//     console.log('Drop');
//     doDrop_file(e.dataTransfer.files);
//     handleFileUpload(id, files, obj);
//     handle_FileUpload(id, files, obj);
//     console.log('eof Drop');
// }

// function handleDragover(e) {
//     e.stopPropagation();
//     e.preventDefault();
//     e.dataTransfer.dropEffect = 'copy';
// }