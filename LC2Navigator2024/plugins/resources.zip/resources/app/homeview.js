'use strict';
const path = require('path');
const model = require(path.join(__dirname, 'model.js'));
const api = require(path.join(__dirname, 'api.js'));
module.exports.showPeople = function(_dbPath, rowsObject, ctab, iD) {
    let markup = '';
    let openlink = 'https://letztechance.org/openlink?';
    // markup += '<link rel="stylesheet" href="app/css/custom.css">';
    // markup += '[<a class="nav-link add" onclick="window.view.addPerson(_dbPath,this,\'' + iD + '\');">Add</a>]';
    markup += '<button type="button" class="btn btn-default" onclick="window.view.addPerson(_dbPath,this,\'' + iD + '\');">Add</button>';
    // markup += '[<a onclick="new HttpRequest().execCMD(\'menu.bat\', \'cnt\');">' + window._PAGE_.cpage.langController.msg('menu') + '</a>]';
    markup += '<button type="button" class="btn btn-default" onclick="new HttpRequest().execCMD(\'menu.bat\', \'cnt\');">' + window._PAGE_.cpage.langController.msg('menu') + '</button>';

    // markup += '<input id="isLimit" type="text" value="10"></input>';
    markup += '<select id="isLimit">';
    markup += '<option id="isLimit">20</option>';
    markup += '<option id="isLimit">30</option>';
    markup += '<option id="isLimit">50</option>';
    markup += '<option id="isLimit">100</option>';
    markup += '<option id="isLimit">1000</option>';
    markup += '<option id="isLimit">10000</option>';
    markup += '</select>';

    markup += '<br><input class="_search" style="max-width:96%;width:96%;" id="search' + ctab + '" name="search' + ctab + '" type="text" value=""></input>';
    markup += '<br><input id="issql" type="checkbox"></input>';
    markup += '<input id="searchsubmit-' + ctab + '" name="searchsubmit-' + ctab + '" type="submit" value="Search"></input>';
    for (let rowId in rowsObject) {
        let row = rowsObject[rowId];
        let execUrl = "new HttpRequest().execCMD('" + row.url + "', 'cnt')";
        markup += '' +
            '<div class="row justify-content-start">' +
            '<div class="col-xs-2 edit-icons"><a><img id="edit-pid_' +
            row.person_id + '" class="icon edit" src="' +
            path.join(__dirname, 'img', 'edit-icon.png') + '"></a>' +
            '<a><img id="del-pid_' + row.person_id +
            '" class="icon delete" src="' + path.join(__dirname, 'img', 'x-icon.png') +
            '"></a></div>' +
            //    '<div class="col-xs-5 name">' + row.person_id + '</div>' +
            '<div class="col-xs-5 name">' + row.person_id + '.' + row.first_name + '</div>' +
            '<div class="col-xs-5 name">' + row.name + '&nbsp;</div>' +
            '</br>' +
            '<div class="col-xs-5 name">' + row.description + '</div>' +
            '<div class="col-xs-5 name">' + row.city + '</div>' +
            '<div class="col-xs-5 name">' + row.street + '</div>' +
            '<div class="col-xs-5 name"><a onclick="' + execUrl + '" title="' + row.url + '" target="_parent">' + row.first_name + '</a></div>' +
            '<div class="col-xs-5 name"><a href="' + row.url + '" target="_blank">Go to</a></div>' +
            '</div>';
    }
    $('#add-Item, #edit-Item').hide()
        //  console.log('ID:'+id+' View:'+markup)
    $(iD).html(markup);
    var limit = $('#isLimit').val() !== undefined ? $('#isLimit').val() : 0;
    var limitText = limit === undefined || +limit <= 0 ? "" : " limit " + limit + " ";

    $('#searchsubmit-' + ctab).click(function(e) {
            var issql = $("#issql").prop("checked");
            if (!issql) {
                var query = $('#search' + ctab).val();
                var sql = 'SELECT * FROM `' + ctab +
                    '` WHERE ' +
                    ' name like "%' + query + '%"' +
                    ' or first_name like "%' + query + '%"' +
                    ' or description like "%' + query + '%"' +
                    ' or city like "%' + query + '%"' +
                    ' or street like "%' + query + '%"' +
                    ' or url like "%' + query + '%"' +
                    ' ORDER BY `name` ASC' + limitText;
                // alert(sql);
                window.model.getQuery(_dbPath, ctab, sql, '#' + ctab);
            } else {
                window.model.GetQuery(_dbPath, '' + $('#search' + ctab).val() + '');
            }
        })
        //  $('a.nav-link').removeClass('active')
        //  $('a.nav-link.people').addClass('active')
        //  $('#people').show();
    $("#search" + ctab).keypress(function(e) {
        if (e.keyCode == 13) {
            var issql = $("#issql").prop("checked");
            if (!issql) {
                var query = $('#search' + ctab).val();
                var sql = 'SELECT * FROM `' + ctab +
                    '` WHERE ' +
                    ' name like "%' + query + '%"' +
                    ' or first_name like "%' + query + '%"' +
                    ' or description like "%' + query + '%"' +
                    ' or city like "%' + query + '%"' +
                    ' or street like "%' + query + '%"' +
                    ' or url like "%' + query + '%"' +
                    ' ORDER BY `name` ASC' + limitText;
                window.model.getQuery(_dbPath, ctab, sql, '#' + ctab);
            } else {
                window.model.GetQuery(_dbPath, '' + $('#search' + ctab).val() + '');
            }
        }
    });
    $(iD + ' img.edit').each(function(idx, obj) {
        $(obj).on('click', function() {
            console.log('PID is:' + this.id + ' ID:' + iD);
            window.view.editPerson(_dbPath, this.id, ctab, iD);
            console.log('PID is:' + this.id + ' ID:' + iD);
            // $("html, body").delay(100).animate({
            //     scrollTop: $('#edit-Item').offset().top
            // }, 300);
        })
    })
    $(iD + ' img.delete').each(function(idx, obj) {
            $(obj).on('click', function() {
                var ctable = $(iD).val();
                var query = 'DELETE FROM `' + ctable + '` WHERE `person_id` IS ?';
                //    	console.log(query);
                window.view.deletePerson(_dbPath, ctab, this.id)
            })
        })
        //  $(obj).on('click', function () {
        //      window.view.deletePerson(this.id)
        //  })
}

module.exports.listPeople = function(e) {
    var limit = $('#isLimit').val();
    var limitText = limit == 0 ? "" : " limit " + limit + " ";
    $('a.nav-link').removeClass('active');
    $(e).addClass('active');
    $('#edit-Item').hide();
    window.model.getQuery('SELECT * FROM `app` ORDER BY `person_id` ASC' + limitText);
    $('#people').show();
}
module.exports.addPerson = function(_dbPath, e, ctab) {
    let OE = cheerio.load(editbody);
    $('#modal-body').html(OE.html());
    $('#edit-person').html(editPerson);
    console.log('Add:' + JSON.stringify(ctab));
    $('a.nav-link').removeClass('active');
    $(e).addClass('active');
    // $('#people').hide();
    // alert('Debug!');
    $('#edit-person h2').html('Add adress');
    $('#edit-person-submit').html('Save');
    $('#edit-person-form input').val('');
    $('#edit-person-form').removeClass('was-validated');
    // $('#first_name, #last_name')
    $('#name').removeClass('is-valid is-invalid');
    // alert('Debug!2');
    $('#person_id').parent().hide();
    // alert('Debug!3');
    // $('#edit-Item').show();
    $('#edit-person').show();
    $("html, body").delay(100).animate({
        scrollTop: $('#edit-person').offset().top
    }, 30);
    this.addEditHandler(_dbPath, ctab.replace('#', ''));
}

module.exports.editPerson = function(_dbPath, pid, ctab, id) {
    let OE = cheerio.load(editbody);
    $('#modal-body').html(OE.html());
    $('#edit-person').html(editPerson);
    console.log('Add:' + JSON.stringify(ctab));
    $('#edit-Item h2').html('Edit Person');
    $('#edit-Item-submit').html('Update');
    $('#edit-Item-form').removeClass('was-validated');
    $('#name').removeClass('is-valid is-invalid');
    $('#person_id').parent().show();
    pid = pid.split('_')[1];
    // alert(pid + '' + id);
    let row = model.getPerson(pid, 'SELECT * FROM `' + ctab + '` WHERE `person_id` IS ?')[0];
    $('#person_id').val(row.person_id);
    $('#first_name').val(row.first_name);
    $('#name').val(row.name);
    $('#description').val(row.description);
    $('#zipcode').val(row.zipcode);
    $('#city').val(row.city);
    $('#street').val(row.street);
    $('#url').val(row.url);
    // $('#people, #add-Item').hide();
    // $('#edit-Item').show();
    $('#edit-person').show();
    $("html, body").delay(100).animate({
        scrollTop: $('#edit-person').offset().top
    }, 30);
    this.addEditHandler(_dbPath, ctab.replace('#', ''));

}
module.exports.addEditHandler = function(_dbPath, ctab) {
    $('#edit-person-submit').click(function(e) {
        // e.preventDefault();
        let ok = true;
        //$('#first_name, #last_name').each(function (idx, obj) {
        $('#first_name').each(function(idx, obj) {
            if ($(obj).val() === '') {
                $(obj).removeClass('is-valid').addClass('is-invalid');
                ok = false;
            } else {
                $(obj).addClass('is-valid').removeClass('is-invalid');
            }
        })
        if (ok) {
            $('#edit-person-form').addClass('was-validated');
            let formId = $(e.target).parents('form').attr('id');
            let keyValue = window.view.getFormFieldValues(formId);
            window.model.saveFormData(_dbPath, ctab, keyValue, function() {
                window.model.getQuery(_dbPath, ctab, 'SELECT * FROM `' + ctab + '` ORDER BY `person_id` ASC', '#people');
            })
        }
        console.log('Saved');
    })

}
module.exports.deletePerson = function(_dbPath, ctab, pid, id) {
    model.deletePerson(_dbPath, ctab, pid.split('_')[1], $('#' + pid).closest('div.row').remove())
}

module.exports.getFormFieldValues = function(formId) {
    let keyValue = { columns: [], values: [] }
    $('#' + formId).find('input:visible, textarea:visible').each(function(idx, obj) {
        keyValue.columns.push($(obj).attr('id'))
        keyValue.values.push($(obj).val())
    })
    return keyValue
}