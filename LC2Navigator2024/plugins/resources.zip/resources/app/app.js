'use strict';
// if (require !== undefined) {
//     window.nodeRequire = require;
//     delete window.require;
//     delete window.exports;
//     delete window.module;
// }
const fs = window.nodeRequire('fs');
// const path = require('path');
const capp = window.nodeRequire('electron').remote.app;
const cheerio = window.nodeRequire('cheerio');
const path = window.nodeRequire('path');
const homeview = window.nodeRequire(path.join(__dirname, 'app', 'homeview.js'));
const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
const api = window.nodeRequire(path.join(__dirname, 'app', 'api.js'));
const os = window.nodeRequire('os');
// const rootLib = window.nodeRequire('app-root-path');
const cpath = window.nodeRequire('path');
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = cpath.dirname(('' + rootLib).replace("resources", ""));

const htmlPath = path.join(capp.getAppPath(), 'app', 'html');
const body = fs.readFileSync(path.join(htmlPath, 'fragments', 'body.html'), 'utf8');
const editbody = fs.readFileSync(path.join(htmlPath, 'fragments', 'editbody.html'), 'utf8');
const navBar = fs.readFileSync(path.join(htmlPath, 'fragments', 'nav-bar.html'), 'utf8');
const menu = fs.readFileSync(path.join(htmlPath, 'fragments', 'menu.html'), 'utf8');
const people = fs.readFileSync(path.join(htmlPath, 'fragments', 'people.html'), 'utf8');
const editPerson = fs.readFileSync(path.join(htmlPath, 'fragments', 'edit-person.html'), 'utf8');

// window.$ = window.jQuery = window.nodeRequire('jquery');
// window.Tether = window.nodeRequire('tether');
// window.Bootstrap = window.nodeRequire('bootstrap');

// let webRoot = path.dirname(__dirname);
let webRoot = path.dirname(__dirname);
window.view = window.nodeRequire(path.join(webRoot, 'app', 'homeview.js'));
window.model = window.nodeRequire(path.join(webRoot, 'app', 'model.js'));
let rootLib = window.nodeRequire('app-root-path');
let appRoot = path.dirname(('' + rootLib).replace("resources", ""));


// alert(_dbPath);
window.$ = window.jQuery = window.nodeRequire('jquery');
window.Tether = window.nodeRequire('tether');
window.Bootstrap = window.nodeRequire('bootstrap');
var remote = window.nodeRequire('electron').remote;
console.log(remote.getGlobal('sharedObj').path);
console.log(remote.getGlobal('sharedObj').dbPath);

const _dbPath = remote.getGlobal('sharedObj').dbPath;
// console.log("Path:" + webRoot);
window.model.db = path.join(_dbPath); //path.join(app.getPath('userData'), 'lc.db');
console.log('app is running... ' + remote.getGlobal('sharedObj').path);
var downloadUrls = [
    "https://www.letztechance.org/LC2Intro.v.4.0/assets/lclogo.png",
    // "https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l="
];
try {
    // updateApp(links);
    updateApp(downloadUrls[0]);
    var app = new APPLICATION();
    $('#app').html(app.getAppTabs(app.tabs));
    app.AddAppTabsEvents(app.tabs);
} catch (e) {
    alert(e.stack);
}

function fixSlash(links) {
    return links.replace("\\", "\\\\");
}

function updateApp(links) {
    // var target = path.join(appRoot, "download");
    // window.nodeRequire("electron").remote.require("electron-download-manager").download({
    //     url: downloadUrls,
    //     // path: target
    // }, function(error, info) {
    //     if (error) {
    //         console.log(error);
    //         return;
    //     }

    //     console.log("DONE: " + info.url);
    // })
}


function APPLICATION() {
    this.fixSlash = function fixSlash(links) {
        return links.replace("\\", "\\\\");
    }
    this.getTables = function getTables() {
        let result = [];
        let row;
        try {
            if (window._PAGE_.cpage.isApp) {
                // const path = require('path');
                var limit = $('#isLimit').val() !== undefined ? $('#isLimit').val() : 0;
                var limitText = limit === undefined || +limit <= 0 ? "" : " limit " + limit + " ";
                const model = window.nodeRequire(path.join(__dirname, '/app/model.js'));
                row = model.GetQuery(_dbPath, 'SELECT name FROM systables' + limitText);
                var i = 0;
                for (var v in row) {
                    result[i] = row[v]["name"];
                    i++;
                }
            }
        } catch (e) {
            console.error(e);
            console.error(e.stack);
            console.error(JSON.stringify(e));
        }
        // alert(JSON.stringify(result));
        return result;
    }
    this.tabs = this.getTables();


    this.getAppTabs = function getAppTabs(list) {
        var ltext = window._PAGE_.cpage.langController.msg('list');
        return window._PAGE_.cpage.config.tabModel.getTabs(ltext, list, list, "#article");
    }

    this.ExecAppTabsEvents = function ExecAppTabsEvents(ctab) {
        // Compose the DOM from separate HTML concerns; each from its own file.
        let O = cheerio.load(body);
        O('#nav-bar').append(navBar);
        O('#menu').append(menu);
        O('#people').append(people);
        // Pass the DOM from Cheerio to jQuery.
        let dom = O.html()
        $('#' + ctab).html(dom);
        let OE = cheerio.load(editbody);
        // $('#modal-body').html(OE.html());
        $('#cnt').html(OE.html());
        O('#edit-person').html(editPerson);
        var limit = $('#isLimit').val() !== undefined ? $('#isLimit').val() : 0;
        var limitText = limit === undefined || +limit <= 0 ? "" : " limit " + limit + " ";
        // console.log(limitText);
        window.model.getQuery(_dbPath, ctab, 'SELECT * FROM `' + ctab + '` ORDER BY `person_id` ASC' + limitText, '#' + ctab);
    }

    this.AddAppTabsEvents = function AddAppTabsEvents(list) {
        var that = this;
        var count = list.length;
        for (var v in list) {
            $("#" + list[v] + '-tab').on("click", function() {
                var ctab = $(this).text();
                console.log(ctab);
                that.ExecAppTabsEvents(ctab)
            });
            $("#" + list[0] + '-tab').click();
        }
        that.ExecAppTabsEvents(list[count - 1]);
        $('body').on('click', '#nneues a,#nsecurity a,#npolitik a,#nsport a,#videoofday a,#nmedia a, #nentertain a, #ncode a', (event) => {
            event.preventDefault();
            let link = event.target.href;
            window.nodeRequire("electron").shell.openExternal(link);
        });
        $('body').on('click', '#games a', (event) => {
            event.preventDefault();
            let link = event.target.href;
            window.nodeRequire("electron").shell.openExternal(link);
        });
        // $('body').on('click', '#windowContent1 a', (event) => {
        //     event.preventDefault();
        //     // alert('Test');
        //     alert(JSON.stringify(event));
        //     let link = "" + event.target.href;
        //     alert('Does not work up to now:' + link);
        //     let parts = link.split(',');
        //     // alert(parts[0]);
        //     cFCW('https://www.letztechance.org/index.html?q=srss&query=' + link, 410, 640, 10, 10);
        //     //window.nodeRequire("electron").shell.openExternal('https://www.letztechance.org/' + link);

        // });

    }

}