function printXSLT(divid, outXmlString) {
    console.log('printXSLT');
    try {
        divid = (divid !== undefined && divid != null && divid != '') ? divid : 'app_cnt';
        console.log('ID:' + divid);
        document.getElementById(divid).innerHTML = outXmlString;
    } catch (e) {
        alert(e);
        alert(e.stack);
    }
}