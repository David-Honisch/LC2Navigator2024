try {
    document.getElementById("app_cnt").innerHTML = "";
    document.getElementById("app_cnt").innerHTML = "";
    for (var v in installDirectories) {
        createDir(installDirectories[v]);
    }
    var opath = window.nodeRequire('path');
    var resDir = opath.join(__dirname, '../../resources/');
    var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
    var downloadDir = opath.join(__dirname, '../../');
    console.log(resDir);
    console.log(pluginDir);
    console.log(downloadDir);
    InstallModules(resDir);


    doDownload(downloadUrls, resDir);
    // execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'app_cnt');
	// execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'app_cnt');

    // doUnzip(downloadUrls, targetDir);
} catch (e) {
    alert(e.stack);
	console.error(e.stack);
}