/* <input type="submit" value="Import to SQLite" id="dbimport" onclick="export_db();" disabled="false"></input> */
alert('Debug');
$("#btnmenutobase64").on("click", function(e) {
    alert('Debug');
    e.preventDefault();
    e.stopPropagation();
    alert('BSASD.');
	var id = "#btnmenutobase64";
	if ($("#importfile").val() !== undefined){	
		getToBase('#importfile','#base64file');
	}
    else{	
		alert('Please select a file.');
	}
});
$("#menusaveall").on("click", function(e) {
    alert('Debug');
    e.preventDefault();
    e.stopPropagation();
    alert('Test');
	getToBase('#importfile','#menu_cnt');
});
$("#menurunserver").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    try {
        // alert('Debug');
        execCMD('.\\resources\\cmd\\graburls\\showservermenu.bat', 'outcnt');
        // alert('Debug');
    } catch (error) {
        alert(error);
        alert(error.stack);
    }
});
console.log('main.js done.');
getFullIndexList('#tableId', 'https://www.letztechance.org/webservices/getcontent.php', 'https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=');