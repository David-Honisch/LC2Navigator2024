console.log('main running...');
var XLSX;
// var $ = $;
// var electron;
// if (path === undefined) {
//     var path;
// }
var xlsxj;
// var fs;
var cDg;
var convert;
try {
    try {
        // $ = window.nodeRequire('jquery');
        electron = window.nodeRequire('electron').remote;
        // path = window.nodeRequire('path');
        // fs = window.nodeRequire('fs');
        XLSX = window.nodeRequire('xlsx');
    } catch (e) {
        eMsg(e);
    }
    try {
        convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
        xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
        XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
    } catch (e) {
        eMsg(e);
    }
    try {
        convert = XLSX;
        // XLSX = new XLSX();
    } catch (e) {
        eMsg(e);
    }

    var utils = new XLSXUtils(XLSX);
    /* <input type="submit" value="Import to SQLite" id="dbimport" onclick="export_db();" disabled="false"></input> */
    $("#xlsxport").on("click", function(e) {
        alert('Debug');
        e.preventDefault();
        e.stopPropagation();
        utils.export_all();
    });
    $("#csvxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        utils.export_csv();
    });
    $("#xmlxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        utils.export_xml();
    });
    $("#jsonxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        utils.export_json();
    });
    $("#btngraburls").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        // alert('Debug');
        utils.grab_urls();
    });
    $("#dbimport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        // alert('Debug');
        utils.export_db();
    });
    $("#wsxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        // alert('Debug');
        utils.export_ws();
    });
    $("#runserver").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        try {
            // alert('Debug');
            execCMD('.\\resources\\plugins\\graburls\\runserver.bat', 'outcnt');
            // alert('Debug');
        } catch (error) {
            alert(error);
            alert(error.stack);
        }
    });



    // var httprequest = new HttpRequest();
    // httprequest.getFullList();

    function eMsg(v) {
        alert(v);
        if (e.stack !== undefined) console.error(e.stack);
    }

    function XLSXUtils(XLSX) {
        // var $ = window.nodeRequire('jquery');
        // var electron = window.nodeRequire('electron').remote;
        // var path = window.nodeRequire('path');
        // var fs = window.nodeRequire('fs');
        // var convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
        // var xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
        // var XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
        // alert('SUX');

        this.prep = function(arr) {
            var out = [];
            for (var i = 0; i < arr.length; ++i) {
                if (!arr[i]) continue;
                if (Array.isArray(arr[i])) {
                    out[i] = arr[i];
                    continue
                };
                var o = new Array();
                Object.keys(arr[i]).forEach(function(k) {
                    o[+k] = arr[i][k]
                });
                out[i] = o;
            }
            return out;
        }



        this.export_all = function() {
            // alert('Debu22g');
            var XTENSION = "xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html".split("|")
            var HTMLCNT = document.getElementById('htmlcnt');
            var electron = window.nodeRequire('electron').remote;
            return function() {
                try {
                    // var wb = XLSX.utils.table_to_book(HTMLCNT);
                    var o = electron.dialog.showSaveDialog({
                        title: 'Save file as',
                        filters: [{
                            name: "json",
                            extensions: XTENSION
                        }]
                    });
                    eMsg(o);
                    if (o) {
                        try {
                            if (!cDg) return;
                            /* convert canvas-datagrid data to worksheet */
                            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                            /* build workbook */
                            var new_wb = XLSX.utils.book_new();
                            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                            /* write file and trigger a download */
                            XLSX.writeFile(new_wb, o, {
                                bookSST: true
                            });
                        } catch (e) {
                            eMsg(e);
                        }
                        electron.dialog.showMessageBox({
                            message: "Exported data to " + o,
                            buttons: ["OK"]
                        });
                    } else {
                        electron.dialog.showMessageBox({
                            message: "Export cancelled ",
                            buttons: ["OK"]
                        });
                    }
                } catch (e) {
                    eMsg(e);

                }
            };
        };
        // this.export_all();
        //CSV
        this.export_csv = function() {
            var HTMLCNT = document.getElementById('htmlcnt');
            var XTENSION = "csv|CSV|txt|TXT".split("|");
            var electron = window.nodeRequire('electron').remote;
            return function() {
                try {
                    var wb = XLSX.utils.table_to_book(HTMLCNT);
                    var o = electron.dialog.showSaveDialog({
                        title: 'Save file as',
                        filters: [{
                            name: "csv",
                            extensions: XTENSION
                        }]
                    });
                    eMsg(o);
                    if (o) {
                        try {
                            if (!cDg) return;
                            /* convert canvas-datagrid data to worksheet */
                            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                            /* build workbook */
                            var new_wb = XLSX.utils.book_new();
                            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                            /* write file and trigger a download */
                            XLSX.writeFile(new_wb, o + 'LetzteChance.Org.xlsx', {
                                bookSST: true
                            });
                            XLSX.writeFile(new_wb, o, {
                                bookSST: true
                            });
                        } catch (e) {
                            eMsg(e);
                        }
                        electron.dialog.showMessageBox({
                            message: "Exported data to " + o,
                            buttons: ["OK"]
                        });
                    } else {
                        electron.dialog.showMessageBox({
                            message: "Export cancelled ",
                            buttons: ["OK"]
                        });
                    }
                } catch (e) {
                    eMsg(e);
                }
            };

        };
        //XML
        this.export_xml = function() {
            var XTENSION = "xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html".split("|")
            var HTMLCNT = document.getElementById('htmlcnt');
            return function() {
                try {
                    // var wb = XLSX.utils.table_to_book(HTMLCNT);
                    var electron = window.nodeRequire('electron').remote;
                    var o = electron.dialog.showSaveDialog({
                        title: 'Save file as',
                        filters: [{
                            name: "xml",
                            extensions: XTENSION
                        }]
                    });
                    eMsg(o);
                    if (o) {
                        try {
                            if (!cDg) return;
                            /* convert canvas-datagrid data to worksheet */
                            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                            /* build workbook */
                            var new_wb = XLSX.utils.book_new();
                            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                            /* write file and trigger a download */
                            XLSX.writeFile(new_wb, o + 'LetzteChance.Org.xlsx', {
                                bookSST: true
                            });
                            XLSX.writeFile(new_wb, o, {
                                bookSST: true
                            });
                        } catch (e) {
                            eMsg(e);
                        }
                        electron.dialog.showMessageBox({
                            message: "Exported data to " + o,
                            buttons: ["OK"]
                        });
                    } else {
                        electron.dialog.showMessageBox({
                            message: "Export cancelled ",
                            buttons: ["OK"]
                        });
                    }
                } catch (e) {
                    eMsg(e);
                }
            };
        };
        // alert('TEST');
        //JSON
        this.export_json = function() {
            var HTMLCNT = document.getElementById('htmlcnt');
            var XTENSION = "json|JSON".split("|");
            var electron = window.nodeRequire('electron').remote;
            return function() {
                try {

                    var wb = XLSX.utils.table_to_book(HTMLCNT);
                    var o = electron.dialog.showSaveDialog({
                        title: 'Save file as',
                        filters: [{
                            name: "json",
                            extensions: XTENSION
                        }]
                    });
                    eMsg(o);
                    if (o) {
                        try {
                            var postFix = '-.LetzteChance.Org.xlsx';
                            // var fileName = o + postFix;
                            if (!cDg) return;
                            /* convert canvas-datagrid data to worksheet */
                            var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                            /* build workbook */
                            var new_wb = XLSX.utils.book_new();
                            XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                            /* write file and trigger a download */
                            XLSX.writeFile(new_wb, o + postFix, {
                                bookSST: true
                            });
                            // var workbook = XLSX.readFile(o + postFix);
                            var v = {};
                            new_wb.SheetNames.forEach(function(name) {
                                v[name] = XLSX.utils.sheet_to_json(new_wb.Sheets[name]);
                                fs.writeFileSync(o + name + ".json", JSON.stringify(v[name]), 'utf-8');
                            });
                        } catch (e) {
                            eMsg(e);
                        }
                        electron.dialog.showMessageBox({
                            message: "Exported data to " + o,
                            buttons: ["OK"]
                        });
                    } else {
                        electron.dialog.showMessageBox({
                            message: "Export cancelled ",
                            buttons: ["OK"]
                        });
                    }
                } catch (e) {
                    eMsg(e);
                }
            };
        };
        // alert('TEST');
        //DB
        this.export_db = function() {
            var XTENSION = "csv|CSV".split("|");
            var tableId = $('#tableId>option:selected').text();
            // return function() {
            try {
                // var wb = XLSX.utils.table_to_book(HTMLCNT);
                var electron = window.nodeRequire('electron').remote;
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "csv",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o, {
                            bookSST: true
                        });
                        execCMD('exec.bat .\\resources\\cmd\\dbimport.file.bat "' + o + '" ' + tableId + '', 'outcnt', true);
                        execCMD('exec.bat .\\resources\\cmd\\dbimport.bat "' + o + '" ' + tableId + '', 'outcnt', true);
                        document.getElementById('outcnt').innerHTML += '<h1>Import done.</h1>';
                        return true;

                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({
                        message: "Export cancelled ",
                        buttons: ["OK"]
                    });
                    return;
                }
            } catch (e) {
                eMsg(e);
            }
        };
        // alert('TEST2');
        //DB
        this.export_ws = function() {
            var XTENSION = "csv|CSV".split("|");
            var tableName = $('#tableId>option:selected').text();
            var tableId = $('#tableId>option:selected').val();
            try {
                // var wb = XLSX.utils.table_to_book(HTMLCNT);
                var electron = window.nodeRequire('electron').remote;
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "csv",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        if (!cDg) return;
                        if (!o) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o, {
                            bookSST: true
                        });
                        // execCMD('exec.bat .\\resources\\cmd\\wsimport.bat "' + o + '" "' + tableName + '" ' + tableId, 'outcnt', true);                    
                        // var singleFileUploadInput = document.querySelector('#singleFileUploadInput');
                        // singleFileUploadInput.val = o;
                        // var files = singleFileUploadInput.files;
                        // if (files.length === 0) {
                        //     document.getElementById('outcnt').innerHTML += "Please select a file";
                        // }
                        // uploadSingleFile(files[0]);
                        this.export_postdata(o, tableId);
                        document.getElementById('outcnt').innerHTML += '<h1>Import done.</h1>';
                        return true;

                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({
                        message: "Export cancelled ",
                        buttons: ["OK"]
                    });
                    return;
                }
            } catch (e) {
                eMsg(e);
            }
        };

        this.export_postdata = function(o, tableId) {
            const lineReader = window.nodeRequire('line-reader');

            lineReader.eachLine(o, function(line) {
                console.log(line);
                document.getElementById('outcnt').innerHTML += line + '<br>';
                // var ser = $("#insertForm").serialize();
                var ser = {
                    value1: tableId,
                    subject: line,
                    // body: '[url]' + line + '[/url]',
                    body: line,
                    ebody: line,
                };
                // console.log('POST:'+ser);
                // $('#rsTitle').prop('title', isUpdate ? 'Update:' : 'Post:' + JSON.stringify(ser));
                var url = 'http://localhost/cms/webservices/client.php?q=doInsert';
                $.ajax({
                    type: "POST",
                    url: url,
                    data: ser, // serializes the form's elements.
                    contentType: "application/x-www-form-urlencoded; charset=utf-8",
                    success: function(data) {
                        $('#outcnt').append(JSON.stringify(data));
                        $('#outcnt').append(url);

                    }
                });
            });
            // alert('File:' + o);
            // fs = window.nodeRequire('fs');
            // fs.readFile(o, 'utf8', function(err, data) {
            //     if (err) {
            //         return console.log(err);
            //     }
            //     console.log(data);
            //     var formData = new FormData();
            //     // formData.append('file', data, {
            //     //     filepath: o,
            //     //     contentType: 'text/plain',
            //     // });
            //     formData.append("file", o);

            //     var xhr = new XMLHttpRequest();
            //     xhr.open("POST", "http://localhost:8081/uploadFile");

            //     xhr.onload = function() {
            //         console.log(xhr.responseText);
            //         var response = JSON.parse(xhr.responseText);
            //         if (xhr.status == 200) {
            //             // document.getElementById('outcnt').style.display = "none";
            //             document.getElementById('outcnt').innerHTML += "<p>File Uploaded Successfully.</p><p>DownloadUrl : <a href='" + response.fileDownloadUri + "' target='_blank'>" + response.fileDownloadUri + "</a></p>";
            //             // singleFileUploadSuccess.innerHTML = "<p>File Uploaded Successfully.</p><p>DownloadUrl : <a href='" + response.fileDownloadUri + "' target='_blank'>" + response.fileDownloadUri + "</a></p>";
            //             // document.getElementById('outcnt').style.display = "block";
            //         } else {
            //             // document.getElementById('outcnt').style.display = "none";                    
            //             document.getElementById('outcnt').innerHTML += (response && response.message) || "Some Error Occurred";
            //             document.getElementById('outcnt').innerHTML += xhr.responseText;
            //         }
            //     }
            //     xhr.send(formData);
            // });

        }

    };
    // function doit(type, fn, dl) {
    //     var elt = document.getElementById('htmlout');
    //     var wb = XLSX.utils.table_to_book(elt, {
    //         sheet: "LetzteChance.Org"
    //     });
    //     return dl ?
    //         XLSX.write(wb, {
    //             bookType: type,
    //             bookSST: true,
    //             type: 'base64'
    //         }) :
    //         XLSX.writeFile(wb, fn || ('test.' + (type || 'xlsx')));
    // }
} catch (error) {
    alert(error);
}