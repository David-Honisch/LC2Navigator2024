select '<hr/><h2>Import lc2mongodb processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2mongodb;
drop table IF EXISTS lc2mongodb_main;
drop table IF EXISTS lc2mongodb_install;
drop table IF EXISTS lc2mongodb_help;
drop table IF EXISTS lc2mongodb_data;
drop table IF EXISTS lc2mongodb_info;
drop table IF EXISTS lc2mongodb_work;
drop table IF EXISTS lc2mongodb_procdata;
drop table IF EXISTS lc2mongodbtemp;
drop table IF EXISTS lc2mongodb_datatemp;
drop table IF EXISTS lc2mongodb_worktemp;
drop table IF EXISTS lc2mongodb_proc;
drop table IF EXISTS lc2mongodb_tests;
drop table IF EXISTS lc2mongodb_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2mongodb( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2mongodb_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2mongodb_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2mongodb_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2mongodb_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2mongodb_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2mongodb_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2mongodb_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2mongodb_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2mongodb_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2mongodbtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2mongodb_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2mongodb\\import\\import.csv lc2mongodbtemp
-- INSERT INTO lc2mongodb(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2mongodbtemp;
.import .\\resources\\plugins\\lc2mongodb\\import\\import.csv lc2mongodb
.import .\\resources\\plugins\\lc2mongodb\\import\\main.csv lc2mongodb_main
.import .\\resources\\plugins\\lc2mongodb\\import\\install.csv lc2mongodb_install
.import .\\resources\\plugins\\lc2mongodb\\import\\help.csv lc2mongodb_help
.import .\\resources\\plugins\\lc2mongodb\\import\\data.csv lc2mongodb_data
.import .\\resources\\plugins\\lc2mongodb\\import\\info.csv lc2mongodb_info
.import .\\resources\\plugins\\lc2mongodb\\import\\work.csv lc2mongodb_work
.import .\\resources\\plugins\\lc2mongodb\\import\\proc.csv lc2mongodb_proc
.import .\\resources\\plugins\\lc2mongodb\\import\\tests.csv lc2mongodb_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2mongodb\\import\\proc.csv' lc2mongodb_proctemp
-- .separator ";"
-- INSERT INTO lc2mongodb_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2mongodb_proctemp;
-- select 'lc2mongodb_work count:';
-- select count(*) from lc2mongodb_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2mongodb count:';
select count(*) from lc2mongodb;
select '<p>start data import to plugin tables</p>';
-- delete from lc2mongodb_datatemp;
--
select '<p>lc2mongodb count:';
select count(*) from lc2mongodb;
select 'lc2mongodb_data count:';
select count(*) from lc2mongodb_data;
select 'lc2mongodb_info count:';
select count(*) from lc2mongodb_info;

select 'lc2mongodb_procdata count:';
select count(*) from lc2mongodb_procdata;
select 'lc2mongodb_work count:';
select count(*) from lc2mongodb_work;
select 'lc2mongodb_proc count:';
select count(*) from lc2mongodb_proc;
select 'lc2mongodb_proctemp count:';
select count(*) from lc2mongodb_proctemp;

drop table IF EXISTS lc2mongodbtemp;
-- drop table IF EXISTS lc2mongodb_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2mongodb processes done.</h4>';
.exit