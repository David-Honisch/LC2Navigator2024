select '<hr/><h2>Import LC2DBCLI processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2DBCLI;
drop table IF EXISTS LC2DBCLI_main;
drop table IF EXISTS LC2DBCLI_install;
drop table IF EXISTS LC2DBCLI_help;
drop table IF EXISTS LC2DBCLI_data;
drop table IF EXISTS LC2DBCLI_info;
drop table IF EXISTS LC2DBCLI_work;
drop table IF EXISTS LC2DBCLI_procdata;
drop table IF EXISTS LC2DBCLItemp;
drop table IF EXISTS LC2DBCLI_datatemp;
drop table IF EXISTS LC2DBCLI_worktemp;
drop table IF EXISTS LC2DBCLI_proc;
drop table IF EXISTS LC2DBCLI_tests;
drop table IF EXISTS LC2DBCLI_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2DBCLI( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2DBCLI_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2DBCLI_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2DBCLItemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2DBCLI_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2DBCLI\\import\\import.csv LC2DBCLItemp
-- INSERT INTO LC2DBCLI(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DBCLItemp;
.import .\\resources\\plugins\\LC2DBCLI\\import\\import.csv LC2DBCLI
.import .\\resources\\plugins\\LC2DBCLI\\import\\main.csv LC2DBCLI_main
.import .\\resources\\plugins\\LC2DBCLI\\import\\install.csv LC2DBCLI_install
.import .\\resources\\plugins\\LC2DBCLI\\import\\help.csv LC2DBCLI_help
.import .\\resources\\plugins\\LC2DBCLI\\import\\data.csv LC2DBCLI_data
.import .\\resources\\plugins\\LC2DBCLI\\import\\info.csv LC2DBCLI_info
.import .\\resources\\plugins\\LC2DBCLI\\import\\work.csv LC2DBCLI_work
.import .\\resources\\plugins\\LC2DBCLI\\import\\proc.csv LC2DBCLI_proc
.import .\\resources\\plugins\\LC2DBCLI\\import\\tests.csv LC2DBCLI_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2DBCLI\\import\\proc.csv' LC2DBCLI_proctemp
-- .separator ";"
-- INSERT INTO LC2DBCLI_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2DBCLI_proctemp;
-- select 'LC2DBCLI_work count:';
-- select count(*) from LC2DBCLI_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2DBCLI count:';
select count(*) from LC2DBCLI;
select '<p>start data import to plugin tables</p>';
-- delete from LC2DBCLI_datatemp;
--
select '<p>LC2DBCLI count:';
select count(*) from LC2DBCLI;
select 'LC2DBCLI_data count:';
select count(*) from LC2DBCLI_data;
select 'LC2DBCLI_info count:';
select count(*) from LC2DBCLI_info;

select 'LC2DBCLI_procdata count:';
select count(*) from LC2DBCLI_procdata;
select 'LC2DBCLI_work count:';
select count(*) from LC2DBCLI_work;
select 'LC2DBCLI_proc count:';
select count(*) from LC2DBCLI_proc;
select 'LC2DBCLI_proctemp count:';
select count(*) from LC2DBCLI_proctemp;

drop table IF EXISTS LC2DBCLItemp;
-- drop table IF EXISTS LC2DBCLI_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2DBCLI processes done.</h4>';
.exit