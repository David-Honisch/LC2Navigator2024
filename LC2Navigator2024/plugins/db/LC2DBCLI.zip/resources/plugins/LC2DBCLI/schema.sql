select '<h2>Import processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2DBCLI;
drop table IF EXISTS LC2DBCLI_main;
drop table IF EXISTS LC2DBCLI_install;
drop table IF EXISTS LC2DBCLI_help;
drop table IF EXISTS LC2DBCLI_data;
drop table IF EXISTS LC2DBCLI_work;
drop table IF EXISTS LC2DBCLI_procdata;
drop table IF EXISTS LC2DBCLItemp;
drop table IF EXISTS LC2DBCLI_datatemp;
-- select '<p>create plugin tables</p>';
CREATE TABLE LC2DBCLI( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DBCLI_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE LC2DBCLI_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2DBCLItemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2DBCLI_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2DBCLI_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
-- .import .\\resources\\plugins\\LC2DBCLI\\import\\import.csv LC2DBCLItemp
-- INSERT INTO LC2DBCLI(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DBCLItemp;
.import .\\resources\\plugins\\LC2DBCLI\\import\\import.csv LC2DBCLI
.import .\\resources\\plugins\\LC2DBCLI\\import\\main.csv LC2DBCLI_main
.import .\\resources\\plugins\\LC2DBCLI\\import\\install.csv LC2DBCLI_install
.import .\\resources\\plugins\\LC2DBCLI\\import\\help.csv LC2DBCLI_help
.import .\\resources\\plugins\\LC2DBCLI\\import\\data.csv LC2DBCLI_data
.import .\\resources\\plugins\\LC2DBCLI\\import\\work.csv LC2DBCLI_work
--
-- eof insert work data
select 'LC2DBCLI count:';
select count(*) from LC2DBCLI;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\LC2DBCLI\\import\\menu.csv' LC2DBCLI_datatemp
-- .import '.\\resources\\plugins\\LC2DBCLI\\import\\menu.csv' LC2DBCLI_datatemp
-- INSERT INTO LC2DBCLI_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DBCLI_datatemp;
-- .import '.\\resources\\plugins\\LC2DBCLI\\import\\menu.csv' LC2DBCLI_data
-- delete from LC2DBCLI_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\LC2DBCLI\\import\\data.csv' LC2DBCLI_worktemp
-- INSERT INTO LC2DBCLI_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DBCLI_worktemp;
--
select 'LC2DBCLI_work count:';
select count(*) from LC2DBCLI_work;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2DBCLI\\import\\LC2DBCLIwork.csv' LC2DBCLI_datatemp
-- INSERT INTO LC2DBCLI_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DBCLI_datatemp;
--
select '<p>LC2DBCLI count:';
select count(*) from LC2DBCLI;
select 'LC2DBCLI_data count:';
select count(*) from LC2DBCLI_data;
select 'LC2DBCLI_procdata count:';
select count(*) from LC2DBCLI_procdata;
.separator ";"
drop table IF EXISTS LC2DBCLItemp;
-- select '<p>Import done</p>';
.exit