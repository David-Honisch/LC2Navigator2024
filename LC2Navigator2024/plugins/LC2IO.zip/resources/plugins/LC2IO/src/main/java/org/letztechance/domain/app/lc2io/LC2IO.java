package org.letztechance.domain.app.lc2io;

import java.io.File;
import java.util.Set;

import org.letztechance.domain.app.lc2io.io.LC2IOBase;
//import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@SpringBootApplication
//@RestController
public class LC2IO {
	
	private static final String SEP = System.getProperty("file.separator");

//	@RequestMapping("/")
//	public String home() {
//		return "Welcome to LC2IO";
//	}

	public static void main(String[] args) {
//		System.out.println("LETZTECHANCE.ORG");
//		SpringApplication.run(Application.class, args);
		LC2IOBase lC2IOBase = new LC2IOBase();
		String dirName = args[0];
		boolean isDir = new File(dirName).isDirectory();
		Set<String> dirs = lC2IOBase.listDirectories(dirName);
		dirs.forEach(s->System.out.println(dirName+SEP+s));
		Set<String> files = lC2IOBase.listFiles(dirName);
		files.forEach(s->System.out.println(dirName+SEP+s));
	}

}
