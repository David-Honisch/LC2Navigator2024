public class Test {
    public static void main(String[] args) {
        System.out.print("<h1>"+"Test"+"</h1>"); 
    }
}