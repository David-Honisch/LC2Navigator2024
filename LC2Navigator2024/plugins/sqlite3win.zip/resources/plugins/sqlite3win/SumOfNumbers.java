public class SumOfNumbers {
    public static void main(String[] args) {
        int len = args.length; // Length of the array args
        int sum = 0; // Variable to hold our result

        for (int i = 0; i < len; i++)
            sum += Integer.parseInt(args[i]); // Parsing each string item to Integer and add to sum

        System.out.print(sum); // Printing the result to standard console
    }
}