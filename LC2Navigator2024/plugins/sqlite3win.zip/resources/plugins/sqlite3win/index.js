function pluginINIT(pluginName) {
    const APPCFG = "application.config.json";
    try {
        var arg = getPluginArguments();
        console.log(arg);
        //
        var cfg = getAppConfig(APPCFG);
        var dlPath = cfg.api.baseurl;
        var resDir = path.join(__dirname, '../../');
        var localFileName = resDir + pluginName + "-news.json";
        get_Download_File(dlPath, cfg.api.api.read, localFileName, resDir, pluginTable);

        //
        // execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\work.csv", "pnavmenu", true, false);
        execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\proc.csv", "pnavmenu", true, false);
        //execCMD("call tasklist /FO CSV /NH> .\\resources\\plugins\\" + pluginName + "\\import\\work.csv", "pnavmenu");
        execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pluginName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pluginName + "\\\\schema.sql\"", "pschema", true, false);
        // execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pluginName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pluginName + "\\\\schemaimport.sql\"", "pnavmenu");
        execCMD("call resources\\cmd\\register_plugin.bat " + pluginName, "pregister", true, false);
        if (getConfirmation('Install requirements of ' + pluginName + ' now?')) { getOpenDialog('#dialog', '.\\resources\\plugins\\' + pluginName + '\\install.html', 'Install', { minWidth: 250, minHeight: 150, width: 400 }) };
        getXML(".\\resources\\plugins\\" + pluginName + "\\xml\\app.xml", ".\\resources\\plugins\\" + pluginName + "\\xml\\app.xslt", "pnav");
        $('#' + pluginName + '').append(getPluginButtons(pluginName));
        setTimeout(() => {
            try {

                getXSLTTranformation(pluginName + '_info', localFileName, '<h1>TEST<h1><xsl:value-of select="/root" /><xsl:for-each select="root"><xsl:value-of select="subject" /><xsl:value-of select="body" /></xsl:for-each>');
                //
                getExecPluginCMDList(pluginName, pluginTable, '#' + pluginName + '', false);
                execPluginCMDTableList(pluginName, pluginTable + "_main", '#' + pluginName + '_main', false);
                execPluginCMDTableList(pluginName, pluginTable + "_install", '#' + pluginName + '_install', false);
                execPluginCMDTableList(pluginName, pluginTable + "_help", '#' + pluginName + '_help', false);
                // console.log("reading requirements:");
                execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\plugins\\" + pluginName + "\\csv\\check.csv", "" + pluginName + "_install", true, false);
                // console.log("reading requirements done.");
                execCMD("call  resources\\app\\sqlite\\SQLite3.exe  \"resources\\" + pluginName + ".db\" \"select * from " + pluginTable + "_work\">\"resources\\plugins\\" + pluginName + "\\csv\\" + pluginName + "_data.csv\"", "pout", true, false);
                // console.log("calling form:");
                execCMD("call  \"resources\\plugins\\" + pluginName + "\\resources\\work\\" + pluginName + ".bat\"", "pform", true, false);
                // console.log("calling form done");
                var res = getSQLQuery("select * from " + pluginTable + "_work", "resources\\" + pluginName + ".db");
                showResourceList(res, pluginName, "");
                var res = getSQLQuery("select * from " + pluginTable + "_work", "resources\\" + pluginName + ".db");
                showResourceList(res, pluginName, "");

                // printDirectory('resources\\plugins\\' + pluginName + '\\', '' + pluginName + '_install', true);


                //setDragOver('inputKeyFile', pluginName + 'result');
                setTimeout(() => {
                    // var out = document.getElementById('result');
                    // console.log(out !== undefined ? "Yes" : "NO !!!");
                    loadExcelResFile(pluginName + 'result', "inputKeyFile");
                }, 4000);

            } catch (error) {
                $("" + out).append("<p class=\"alert\">" + error + "<p>");
                console.error(error);
                console.error(error.stack);
            }
        }, 3000);
    } catch (e) {
        alert(e.stack);
    }
}