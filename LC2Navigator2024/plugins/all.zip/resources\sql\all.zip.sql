PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
SELECT '<h1>IMPORTING PLUGINS...</h1>';
SELECT 'LC2Navigator 2024 - Register Plugins count:';
select count(*) from plugins;
SELECT '<h1>Update v.2.01.12.128 on 21.04.2024</h1>';
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1,'All Plugins Download v.2.01.12.128 - Update 21.04.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/'',''all.zip'')');
------------------------------------------------------
-- database container ----------------------------------------------
------------------------------------------------------
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2,'Assets Download v.2.01 stable - Update 10.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/'',''assets.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(3,'Assets Download v.2.01 stable - Update 10.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/'',''resources.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(10,'SQLITE Core Application Download v.0.1.2.0122 - Update 21.04.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/'',''sqlite3win.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(11,'LC2CRC32 Download v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/tools/'',''LC2CRC32.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(12,'LC2ShortCutCLI Download v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/tools/'',''LC2ShortCutCLI.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(13,'LC2RegistryWizard Download v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/tools/'',''LC2RegistryWizard.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(14,'LC2bat2exe Download (requires docker or podman) v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''LC2bat2exe.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(15,'LC2Clock Download v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/tools/'',''LC2Clock.zip'')');
--------------
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(15,'LC2JSVideoPlayer.zip Download v.2.0121 - Update 11.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/media/'',''LC2JSVideoPlayer.zip'')');
----------------------------
-- build tools (maven and ant)
SELECT '<h1>IMPORTING build plugins</h1>';
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(520,'apache-maven Download v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/build/'',''apache-maven.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(521,'apache-ant Download v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/build/'',''apache-ant.zip'')');


SELECT '<h1>IMPORTING database plugins</h1>';
------------------------------------------------------
-- database container ----------------------------------------------
------------------------------------------------------
SELECT '<h1>IMPORTING container part 2</h1>';
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(1000,'LC2DBCLI Download v.2.0121 - Update 09.02.2024 (requires OpenJDK(Java))','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/db/'',''LC2DBCLI.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(1001,'LC2Oracle23C Download (requires docker or podman) v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/db/oracle/'',''LC2Oracle23C.zip'')');
-- complete container, interpreter and database 
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(2000,'lc2dockerphpapache Download (requires docker or podman) v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''lc2dockerphpapache.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(2001,'lc2dockerphpapache php backend service Download (requires docker or podman) v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''lc2dockerphpapacheservice.zip'')');
-- complete container, interpreter and database 
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(2002,'LC2bat2exe Download (requires docker or podman) v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''LC2bat2exe.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(2003,'LC2IPFS Download (requires docker or podman) v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/web/'',''LC2IPFS.zip'')');
------------------------------------------------------
-- data ----------------------------------------------
------------------------------------------------------
SELECT '<h1>IMPORTING data plugins</h1>';
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(3000,'LC2CVEGrabber Download v.2.0121 - Update 12.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/data/'',''LC2CVEGrabber.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(3001,'LC2DEBanksUpdater Download v.2.0121 - Update 12.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/data/'',''LC2DEBanksUpdater.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(3002,'LC2Eurostat Download v.2.0121 - Update 12.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/data/'',''LC2Eurostat.zip'')');
------------------------------------------------------
-- core container ----------------------------------------------
------------------------------------------------------
SELECT '<h1>IMPORTING core container</h1>';
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(4000,'lc2dockerphpapache Download v.2.0121 - Update 15.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''lc2dockerphpapache.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(4001,'lc2dockerphpapacheservice Download v.2.0121 - Update 15.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''lc2dockerphpapacheservice.zip'')');
------------------------------------------------------
-- more container ----------------------------------------------
------------------------------------------------------
SELECT '<h1>IMPORTING container part 2</h1>';
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(4002,'LC2RotatingTorproxy Download v.2.0121 - Update 15.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''LC2RotatingTorproxy.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(4003,'LC2ApacheTC Download v.2.0121 - Update 15.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/container/'',''LC2ApacheTC.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(4004,'LC2UIBackend Download v.0.1.0122 - Update 15.04.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/java/'',''LC2UIBackend.zip'')');


INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(9000000,'Some Plugins doesn´t work up to now. Please update all plugins soon','alert(''Update all plugins. There might be some brandnew updates.'')');
SELECT 'SUCCESSFULLY IMPORTED.';
SELECT 'Registered Plugins count:';
select count(*) from plugins;
SELECT 'Plugins IMPORT done.';
SELECT '<h1>IMPORTING PLUGINS done.</h1>';
COMMIT;