PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
SELECT 'IMPORTING PLUGINS...';
SELECT 'LC2Navigator 2024 - Registered Plugins count:';
select count(*) from plugins;
--CREATE TABLE plugins ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1,'All Plugins Download v.2.01214 alpha - Update 09.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/'',''all.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(2,'SQLITE Core Application Download v.0.1.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/'',''sqlite3win.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(3,'LC2CRC32 Download v.2.0121 - Update 09.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/'',''LC2CRC32.zip'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(3,'LC2CRC32 Core Application Download v.0.1.2.0121 alpha - Update 08.02.2024','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/ /plugins/LC2CRC32.zip'',''LC2CRC32.zip'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2,'SQLITE Application Plugins Download v.2.012 alpha - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/ /plugins/sqlite3win.zip'',''sqlite3win.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(3,'LC2CRC32 Application Plugins Download v.2.012 alpha - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/ /plugins/LC2CRC32.zip'',''LC2CRC32.zip'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(2,'SQLite App and Application Download v.2.012 - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/sqlite3win.zip'',''sqlite3win.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(3,'LC2CRC32 Download v.2.012 - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2CRC32.zip'',''LC2CRC32.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(4,'LC2ShortCutCLI Download v.2.012 - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2ShortCutCLI.zip'',''LC2ShortCutCLI.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(5,'LC2IO Download v.2.012 - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2IO.zip'',''LC2IO.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(6,'apache-maven Download v.2.012 - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/apache-maven.zip'',''apache-maven.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(7,'apache-ant Download v.2.012 - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/apache-ant.zip'',''apache-ant.zip'')');


INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(21,'LC2CRC32 Download v.2.012 - Update 08.02.2024 - Several updates coming soon...','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Clock.zip'',''LC2Clock.zip'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2,'sqlite3win - download this required package. It includes applications like SQLITE 3 and required scripts - Update 02.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/sqlite3win.zip sqlite3win.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(3,'assets - download this required package. It includes applications like SQLITE 3 and required scripts - Update 02.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/assets.zip assets.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(4,'resources - download this required package. It includes applications like SQLITE 3 and required scripts - Update 02.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/resources.zip resources.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(10,'LC2CRC32 Plugin Downloader v.1.21  - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2CRC32.zip LC2CRC32.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(11,'lc2process Plugin Downloader v.1.21  - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2process.zip lc2process.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(12,'LC2ShortCutCLI Plugin Downloader v.1.21 - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2ShortCutCLI.zip LC2ShortCutCLI.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(15,'LC2Intro Downloader - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Intro.zip LC2Intro.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(13,'LC2IO Plugin Downloader v.0.1.22 - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2IO.zip LC2IO.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(14,'LC2Clock Plugin Downloader v.1.01a - Update 26.12.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Clock.zip LC2Clock.zip'', ''out'')');
-----------------------------------
build tools
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(30,'apache-ant Downloader 2.1 - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/apache-ant.zip apache-ant.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(31,'apache-maven 3.9x Downloader v.21.0 - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/apache-maven.zip apache-maven.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(32,'LC2Gradle Plugin Downloader v.1.01a - Update 14.01.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Gradle.zip LC2Gradle.zip'', ''out'')');


-----------------------------------
-- core
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(128,'LC2FileExplorer Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2FileExplorer.zip LC2FileExplorer.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(126,'LC2JXMLTransform Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2JXMLTransform.zip LC2JXMLTransform.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(100,'LC2JSVideoPlayer Downloader v.0.1.21 Alpha - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2JSVideoPlayer.zip LC2JSVideoPlayer.zip'', ''out'')');
-----------------------------------
-- database clients
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(201,'LC2DBCLI Plugin Downloader v.1.01a - Update 26.12.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2DBCLI.zip LC2DBCLI.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(202,'LC2Java.Starter Plugin Downloader v.1.1c Small Demo App - Update 01.04.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Java.Starter.zip LC2Java.Starter.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(203,'LC2GrabUrls Downloader v.1.01','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2GrabUrls.zip LC2GrabUrls.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(204,'LC2CMSBuild Plugin Downloader v.1.01a - Update 06.06.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2CMSBuild.zip LC2CMSBuild.zip'', ''out'')');
-----------------------------------
-- microsoft related
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(223,'LC2IRCClient Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2IRCClient.zip LC2IRCClient.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(224,'lc2ircs Plugin Downloader v.1.01a - Update 26.12.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2ircs.zip lc2ircs.zip'', ''out'')');
-----------------------------------
-- microsoft related
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(235,'LC2Microsoft.Toolkit Plugin Downloader v.1.01a- Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Microsoft.Toolkit.zip LC2Microsoft.Toolkit.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(236,'LC2WindowsSerialNo Plugin Downloader v.1.01a - Update 22.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2WindowsSerialNo.zip LC2WindowsSerialNo.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(237,'LC2RegistryWizard Plugin Downloader v.1.3 Final- Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2RegistryWizard.zip LC2RegistryWizard.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(338,'LC2bat2exe Downloader v.1.0 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2bat2exe.zip LC2bat2exe.zip'', ''out'')');
-----------------------------------
-- data related
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(301,'LC2Eurostat UI Plugin Downloader v.1.21a - Update 10.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Eurostat.zip LC2Eurostat.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(302,'LC2DEBanksUpdater Downloader v.1.2b Beta4 Update 01.01.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2DEBanksUpdater.zip LC2DEBanksUpdater.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(303,'LC2WebTorrent Downloader v.1.01 - Update 10.02.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2WebTorrent.zip LC2WebTorrent.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(304,'PhaserEditor_2D_Downloader Downloader v.1.02 - Update 16.02.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/PhaserEditor_2D_Downloader.zip PhaserEditor_2D_Downloader.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(305,'LC2KnownExploitedVulnerabilitiesCatalog Downloader v.1.01 - Update 10.02.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2KnownExploitedVulnerabilitiesCatalog.zip LC2KnownExploitedVulnerabilitiesCatalog.zip'', ''out'')');
-----------------------------------
-- language related
-----------------------------------
-----------------------------------
-- age language related
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(403,'LC2Age Plugin Downloader v.1.01a - Update 26.12.2022(Coming soon)','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Age.zip LC2Age.zip'', ''out'')');INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(119,'LC2RotatingTorproxy Plugin Downloader v.1.01a - Update 26.12.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2RotatingTorproxy.zip LC2RotatingTorproxy.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(305,'LC2Age Plugin Downloader v.1.01a - Update 26.12.2022(Coming soon)','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Age.zip LC2Age.zip'', ''out'')');
-----------------------------------
-- python language related
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(406,'LC2Python Plugin Downloader v.1.01a - Update 26.12.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Python.zip LC2Python.zip'', ''out'')');
-----------------------------------
php language related
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(407,'LC2PHP2Exe Plugin Downloader v.1.01a (Coming soon) - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2PHP2Exe.zip LC2PHP2Exe.zip'', ''out'')');
-----------------------------------
-- other
-----------------------------------
-----------------------------------
-- media
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(408,'LC2JSVideoPlayer Downloader v.0.1.2 - Update 27.02.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2JSVideoPlayer.zip LC2JSVideoPlayer.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(409,'LC2DiabloAutoSkill Plugin Downloader v.1.01a - Update 07.06.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2DiabloAutoSkill.zip LC2DiabloAutoSkill.zip'', ''out'')');
-----------------------------------
-- other
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(410,'LetsEncryptBoulder Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LetsEncryptBoulder.zip LetsEncryptBoulder.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(411,'LC2FortiNet (NEW !!) Downloader v.1.02 - Update 22.02.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2FortiNet.zip LC2FortiNet.zip'', ''out'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(412,'LC2WiFiDirectLegacyAPI Downloader v.0.1.2 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2WiFiDirectLegacyAPI.zip LC2WiFiDirectLegacyAPI.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(413,'LC2EncrypDecrypt Downloader v.1.0','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2EncrypDecrypt.zip LC2EncrypDecrypt.zip'', ''out'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(415,'LC2OpenXLA Downloader v.1.02b - Update 06.03.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2OpenXLA.zip LC2OpenXLA.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(416,'LC2IPFS Downloader v.1.0 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2IPFS.zip LC2IPFS.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(417,'LC2ProcessProxifier Plugin Downloader v.1.21a - Update 12.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2ProcessProxifier.zip LC2ProcessProxifier.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(418,'LC2YTDL Plugin Downloader v.1.21a - Update 09.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2YTDL.zip LC2YTDL.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(419,'LC2YTDL Tests Plugin Downloader v.1.21a - Update 09.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2YTDL_tests.zip LC2YTDL_tests.zip'', ''out'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(420,'LC2OpenSSL UI Plugin Downloader v.1.21a - Update 10.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2OpenSSL.zip LC2OpenSSL.zip'', ''out'')');


-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(421,'LC2AntiCrack Downloader v.1.00b - Update 09.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2AntiCrack.zip LC2AntiCrack.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(422,'LC2SteamWizard Plugin Downloader v.1.01a - Update 20.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2SteamWizard.zip LC2SteamWizard.zip'', ''out'')');


-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(424,'LC2OpenSSH Plugin Downloader v.1.01a - Update 22.07.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2OpenSSH.zip LC2OpenSSH.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(425,'LC2WatsonX Plugin Downloader v.1.01a - Update 22.07.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2WatsonX.zip LC2WatsonX.zip'', ''out'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(426,'lc2dockerdebianbuilder Downloader v.1.01','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2dockerdebianbuilder.zip lc2dockerdebianbuilder.zip'', ''out'')');



-----------------------------------
-- db docker
-----------------------------------
-----------------------------------
-- mongo db
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1001,'lc2mongodb Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2mongodb.zip lc2mongodb.zip'', ''out'')');INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(111,'LC2DockerJenkins Plugin Downloader v.1.01a- Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2DockerJenkins.zip LC2DockerJenkins.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1002,'lc2mongodb Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2mongodb.zip lc2mongodb.zip'', ''out'')');
-----------------------------------
-- mysql
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1003,'lc2mysqldocker Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2mysqldocker.zip lc2mysqldocker.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1004,'lc2sqlservercmd Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2sqlservercmd.zip lc2sqlservercmd.zip'', ''out'')');
-----------------------------------
-- postgres
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1005,'lc2postgresdocker Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2postgresdocker.zip lc2postgresdocker.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1006,'lc2postgresdocker Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2postgresdocker.zip lc2postgresdocker.zip'', ''out'')');
-----------------------------------
-- oracle
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1057,'LC2Oracle23C Downloader v.1.02b - Update 06.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Oracle23C.zip LC2Oracle23C.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1059,'LC2DockerOracle Docker Downloader v.1.01','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2DockerOracle.zip LC2DockerOracle.zip'', ''out'')');
-----------------------------------
-- core container docker server and othter instances
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1097,'lc2dockerphpapache Plugin Downloader v.1.01a - Update 11.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2dockerphpapache.zip lc2dockerphpapache.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1098,'lc2dockerphpapacheservice Plugin Downloader v.1.01a- Update 06.08.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2dockerphpapacheservice.zip lc2dockerphpapacheservice.zip'', ''out'')');
-----------------------------------
-- docker server and othter instances
-----------------------------------


-----------------------------------
-- docker server and othter instances
-----------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2112,'LC2Grafana Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Grafana.zip LC2Grafana.zip'', ''out'')');


-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2121,'LC2DockerSonarCube Plugin Downloader v.1.01a - Update 26.12.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2DockerSonarCube.zip LC2DockerSonarCube.zip'', ''out'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2123,'LC2ApacheDS Plugin Downloader v.1.01a- Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2ApacheDS.zip LC2ApacheDS.zip'', ''out'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2125,'LC2Lampp Plugin Downloader v.1.01a - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Lampp.zip LC2Lampp.zip'', ''out'')');


-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2131,'LC2Rancher Plugin Git Downloader v.1.01a Beta1','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2ApacheRancher.zip LC2ApacheRancher.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2140,'lc2kubernetes Downloader v.1.0','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/lc2kubernetes.zip lc2kubernetes.zip'', ''out'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2142,'LC2CVEGrabber Downloader v.1.0 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2CVEGrabber.zip LC2CVEGrabber.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2143,'LC2XboxSymLink Downloader v.1.0 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2XboxSymLink.zip LC2XboxSymLink.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2144,'LC2TTF Downloader v.1.0 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2TTF.zip LC2TTF.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2145,'LC2Rust Downloader v.1.22 - Update 26.12.2022','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Rust.zip LC2Rust.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2146,'LC2ApacheTC Downloader v.1.0 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2ApacheTC.zip LC2ApacheTC.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2147,'LC2SAPUI Docker Alpha Downloader v.1.0 - Update 01.04.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2SAPUI.zip LC2SAPUI.zip'', ''out'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2148,'LC2SoapUI Docker Downloader v.1.0','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2SoapUI.zip LC2SoapUI.zip'', ''out'')');


-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2151,'LC2DockerKeyCloak Downloader v.1.01','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2DockerKeyCloak.zip LC2DockerKeyCloak.zip'', ''out'')');


-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2155,'LC2OpenAI Downloader v.1.02b - Update 23.02.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2OpenAI.zip LC2OpenAI.zip'', ''out'')');


-- LC2ProcessProxifier
-- INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2168,'LC2Podman Plugin Downloader v.1.21a - Update 20.10.2023','execCMD(''.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/LC2Podman.zip LC2Podman.zip'', ''out'')');




INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(9000000,'Some Plugins doesn´t work up to now. Please update all plugins soon','alert(''Update all plugins. There might be some brandnew updates.'')');
SELECT 'SUCCESSFULLY IMPORTED.';
SELECT 'Registered Plugins count:';
select count(*) from plugins;
SELECT 'Plugins IMPORT done.';
COMMIT;